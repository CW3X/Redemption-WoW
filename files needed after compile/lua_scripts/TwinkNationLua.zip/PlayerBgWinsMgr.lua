--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Handles player BG win statistic gathering for players.
 * AUTHOR : sundays
 * UPDATED: 8th Nov 2016
--]]

local function OnBGEnd(event, bg, bgId, instanceId, winner)
  local name = bg:GetName();
  if winner == 67 then
   local playersInBG = GetPlayersInMap(bg:GetMapId(), instanceId, 1);
    for _, v in pairs(playersInBG) do
      if name == "Warsong Gulch" then
        v:CreditBattlegroundVictory(0, 1); -- WSG, 1 point
      elseif name == "Arathi Basin" then
        v:CreditBattlegroundVictory(1, 1); -- AB, 1 point
      end
    end
  else -- alliance 469
   local playersInBG = GetPlayersInMap(bg:GetMapId(), instanceId, 0);
    for _, v in pairs(playersInBG) do
      if name == "Warsong Gulch" then
        v:CreditBattlegroundVictory(0, 1); -- WSG, 1 point
      elseif name == "Arathi Basin" then
        v:CreditBattlegroundVictory(1, 1); -- AB, 1 point
      end
    end
  end
end

RegisterBGEvent(2, OnBGEnd); -- BG_EVENT_ON_END
