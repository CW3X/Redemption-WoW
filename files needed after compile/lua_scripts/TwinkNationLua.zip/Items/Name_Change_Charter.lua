--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Full Moon - transforms user into a worgen for 5min. 15 min cd.
 * AUTHOR : sundays
 * UPDATED: 28th October 2016
--]]

--[[
  1 - Human
  2 - Orc
  3 - Dwarf
  4 - Nightelf
  5 - Undead
  6 - Tauren
  7 - Gnome
  8 - Troll
--]]

-- Constants
local ENTRY_ITEM       = 74307;
local TEXTID_MAIN      = 60003;
local SPELL_STEALTH    =  1784;
local SPELL_SHADOWMELD = 20580;
local QUERY = "UPDATE `characters`.`characters` SET `at_login`= at_login + '1' WHERE `guid`='%d';";

local Item = {};

function ChangeName(player)
  if not player:IsInCombat() and not player:HasAura(SPELL_SHADOWMELD) and not player:HasAura(SPELL_STEALTH) and not player:InBattleground() then
    local GUIDLow = player:GetGUIDLow();
    player:RemoveItem(ENTRY_ITEM, 1); -- Remove item from inventory
    player:LogoutPlayer(true); -- Needs to be offline, otherwise it looks like at_login gets reset?
    CharDBExecute(string.format(QUERY, GUIDLow)); -- Can't be asynchronous, or Kick() cant guarantee the flag was saved.
    PrintError("Setting flag at_login to 1 for guid " .. GUIDLow);
  else
    player:SendBroadcastMessage("You cannot change your name while in combat, in a battleground or while stealthed.");
  end
end

function Item.OnGossipHello(event, player, object)
  player:GossipClearMenu();
  player:GossipMenuAddItem(10, "I wish to change my name.", 0, 1);
  player:GossipMenuAddItem(10, "Back", 0, 2);
  player:GossipSendMenu(TEXTID_MAIN, player, ENTRY_ITEM);
end

function Item.OnGossipSelect(event, player, object, sender, intid, code, menu_id)
  if intid == 1 then
    player:GossipComplete();
    ChangeName(player);
  elseif intid == 2 then
    player:GossipComplete();
  end
end

RegisterItemGossipEvent(ENTRY_ITEM, 1, Item.OnGossipHello);    -- GOSSIP_EVENT_ON_HELLO
RegisterPlayerGossipEvent(ENTRY_ITEM, 2, Item.OnGossipSelect); -- GOSSIP_EVENT_ON_SELECT
