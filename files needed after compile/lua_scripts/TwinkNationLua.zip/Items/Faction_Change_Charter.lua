--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Faction Change Charter - Allows players to change faction. Includes race change.
 * AUTHOR : sundays
 * UPDATED: 28th October 2016
--]]


-- Constants
local ENTRY_ITEM       = 74308;
local TEXTID_MAIN      = 60002;
local SPELL_SHADOWMELD = 20580;
local SPELL_STEALTH    =  1784;
local QUERY = "UPDATE `characters`.`characters` SET `race`='%d' WHERE `guid`='%d';";

local Item = {
  ClassChoices = {
    [1] = {2, 3, 4, 5, 6, 7, 8}, -- Human can switch to ...
    [2] = {1, 3, 4, 5, 6, 7, 8},
    [3] = {1, 2, 4, 5, 6, 7, 8},
    [4] = {1, 2, 3, 5, 6, 7, 8},
    [5] = {1, 2, 3, 4, 6, 7, 8},
    [6] = {1, 2, 3, 4, 5, 7, 8},
    [7] = {1, 2, 3, 4, 5, 6, 8},
    [8] = {1, 2, 3, 4, 5, 6, 7},
  };
};

local function RaceCanBeClass(race, class)
  local RaceClasses = {
    [1] = {1, 2, 4, 5, 8, 9},
    [2] = {1, 3, 4, 7, 9},
    [3] = {1, 2, 3, 4, 5},
    [4] = {1, 3, 4, 5, 11},
    [5] = {1, 4, 5, 8, 9},
    [6] = {1, 3, 7, 11},
    [7] = {1, 4, 8, 9},
    [8] = {1, 3, 4, 5, 7, 8};
  };

  for _, v in pairs(RaceClasses[race]) do
    if v == class then
      return true;
    end
  end
  return false;
end

local function GetRaceFromId(id)
  if id == 1 then
    return "Human";
  elseif id == 2 then
    return "Orc";
  elseif id == 3 then
    return "Dwarf";
  elseif id == 4 then
    return "Night Elf";
  elseif id == 5 then
    return "Undead";
  elseif id == 6 then
    return "Tauren";
  elseif id == 7 then
    return "Gnome";
  elseif id == 8 then
    return "Troll";
  end
end

local function ChangeRace(player, race)
  if not player:IsInCombat() and not player:HasAura(SPELL_SHADOWMELD) and not player:HasAura(SPELL_STEALTH) and not player:InBattleground() then
    local GUIDLow = player:GetGUIDLow();
    player:RemoveItem(ENTRY_ITEM, 1); -- Remove item from inventory
    player:LogoutPlayer(true); -- Needs to be offline.
    CharDBExecute(string.format(QUERY, race, GUIDLow));
    PrintError(string.format("Changing %d's race to %d.", GUIDLow, race));
  else
    player:SendBroadcastMessage("You cannot change your race while in combat, in a battleground or while stealthed.");
  end
end

function Item.OnGossipHello(event, player, object)
  local RaceId  = player:GetRace();
  local ClassId = player:GetClass();
  local Count   = 0;
  player:GossipClearMenu();
  for _, v in ipairs(Item.ClassChoices[RaceId]) do
    if RaceCanBeClass(v, ClassId) and v ~= RaceId then
      player:GossipMenuAddItem(10, "Change race to " .. GetRaceFromId(v), 0, v);
      Count = Count + 1;
    end
  end
  if Count == 0 then
    player:GossipMenuAddItem(10, "You are not eligible for a race change.", 0, 99);
  end
  player:GossipSendMenu(TEXTID_MAIN, player, ENTRY_ITEM);
end

function Item.OnGossipSelect(event, player, object, sender, intid, code, menu_id)
  if intid == 99 then
    player:GossipComplete();
  else
    player:GossipComplete();
    ChangeRace(player, intid);
  end
end

RegisterItemGossipEvent(ENTRY_ITEM, 1, Item.OnGossipHello);    -- GOSSIP_EVENT_ON_HELLO
RegisterPlayerGossipEvent(ENTRY_ITEM, 2, Item.OnGossipSelect); -- GOSSIP_EVENT_ON_SELECT
