--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Full Moon - transforms user into a worgen for 5min. 15 min cd.
 * AUTHOR : sundays
 * UPDATED: 29th October 2016
--]]

-- Constants
local ENTRY_MOON = 74305;
local SPELL_WOLF = 22660;

local Moon = {};

function Moon.OnUse(event, player, item, _)
  local Gender = player:GetGender();
  player:CastCustomSpell(player, SPELL_WOLF, true, nil, 0, 0, nil);
  if player:HasAura(SPELL_WOLF) then
    local GhostAura = player:GetAura(SPELL_WOLF);
    if GhostAura then
      GhostAura:SetDuration(300000); -- 5 minutes
    end
  end
end

 RegisterItemEvent(ENTRY_MOON, 2, Moon.OnUse); -- ITEM_EVENT_ON_USE
