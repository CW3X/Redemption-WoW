--[[
  * http://twinknation.org/
  * DESC   : Custom teleporter item for TwinkNation
  * AUTHOR : Sundays
  * NOTES  : See table "Rune" for instructions on how to add new locations.
  * UPDATED: 11th Nov 2016
--]]

-- CONSTANTS
local ENTRY_TELEPORT_RUNE = 74301;
local ENTRY_MENU_ID       = 74301;
local ENTRY_TEXT_MAIN     = 74301;
local ENTRY_TEXT_PVP      = 74302;
local ENTRY_TEXT_DUNGEON  = 74303;
local ENTRY_TEXT_RAID     = 74304;
local ENTRY_TEXT_REP      = 74305;
local SPELL_SHADOWMELD    = 20580;
local SPELL_STEALTH       =  1784;

local Rune = {
  Locations = {
    -- [intid] = {map, x, y, z, orientation}
    [1]  = {1, -2882.287, 1888.243, 52.454, 5.874}, -- Dream Bough (Home)
    [20] = {0, -12407.65, 223.2357, 1.5659, 5.626}, -- STV (PvP)
    [21] = {1, -1376.971,  -75.802, 160.52, 3.309}, -- Thunder Bluff (PvP)
    [30] = {0, -11223.72, 1632.446, 34.371, 6.265}, -- Deadmines (Dungeons)
    [31] = {0, -232.3081, 1511.534, 74.550, 2.504}, -- Shadowfang Keep
    [50] = {1,      6810, -2089.16, 624.94, 6.027}, -- Timbermaw Hold (Reputation)
  };
};

local function TeleportPlayer(player, intid)
  if not player:IsInCombat() and not player:InBattleground() and not player:GetAura(SPELL_STEALTH) and not player:GetAura(SPELL_SHADOWMELD) then
    player:Teleport(Rune.Locations[intid][1], Rune.Locations[intid][2], Rune.Locations[intid][3], Rune.Locations[intid][4], Rune.Locations[intid][5]);
  end
end

--[[
function Rune.OnUse(event, player, item, target)
  if not player:IsInCombat() and not player:InBattleground() and not player:GetAura(SPELL_STEALTH) and not player:GetAura(SPELL_STEALTH) then
    player:GossipClearMenu();
    player:GossipMenuAddItem(2, "Home", 0, 1);
    player:GossipMenuAddItem(2, "PvP", 0, 2);
    player:GossipMenuAddItem(2, "Dungeons", 0, 3);
    player:GossipMenuAddItem(2, "Raids", 0, 4);
    player:GossipMenuAddItem(2, "Reputation", 0, 5);
    player:GossipSendMenu(ENTRY_TEXT_MAIN, item);
  end
end
--]]

function Rune.OnGossipHello(event, player, object)
  if not player:IsInCombat() and not player:InBattleground() and not player:GetAura(SPELL_STEALTH) and not player:GetAura(SPELL_SHADOWMELD) then
    player:GossipClearMenu();
    player:GossipMenuAddItem(2, "Home", 0, 1);
    player:GossipMenuAddItem(2, "PvP", 0, 2);
    player:GossipMenuAddItem(2, "Dungeons", 0, 3);
    player:GossipMenuAddItem(2, "Raids", 0, 4);
    player:GossipMenuAddItem(2, "Reputation", 0, 5);
    player:GossipSendMenu(ENTRY_TEXT_MAIN, player, ENTRY_MENU_ID);
  end
end

function Rune.OnGossipSelect(event, player, object, sender, intid, code, menu_id)
  if intid == 1 then
    -- Home (Dream Bough)
    TeleportPlayer(player, intid);
    player:GossipComplete();
  -- SUBMENUS
  elseif intid == 2 then
    -- PvP (Submenu)
    player:GossipClearMenu();
    player:GossipMenuAddItem(2, "Stranglethorn Vale", 0, 20);
    player:GossipMenuAddItem(2, "Thunder Bluff", 0, 21);
    player:GossipMenuAddItem(4, "Back", 0, 109);
    player:GossipSendMenu(ENTRY_TEXT_PVP, player, ENTRY_MENU_ID);
  elseif intid == 3 then
    -- Dungeons (Submenu)
    player:GossipClearMenu();
    player:GossipMenuAddItem(2, "The Deadmines", 0, 30);
    player:GossipMenuAddItem(2, "Shadowfang Keep", 0, 31);
    player:GossipMenuAddItem(4, "Back", 0, 109);
    player:GossipSendMenu(ENTRY_TEXT_DUNGEON, player, ENTRY_MENU_ID);
  elseif intid == 4 then
    -- Raids (Submenu)
    -- Empty for now, so we'll just close the gossip (for now).
    -- ENTRY_TEXT_RAID
    player:GossipClearMenu();
    player:GossipMenuAddItem(4, "Back", 0, 109);
    player:GossipSendMenu(ENTRY_TEXT_RAID, player, ENTRY_MENU_ID);
  elseif intid == 5 then
    -- Reputation (Submenu)
    player:GossipClearMenu();
    player:GossipMenuAddItem(2, "Timbermaw Hold", 0, 50);
    player:GossipMenuAddItem(4, "Back", 0, 109);
    player:GossipSendMenu(ENTRY_TEXT_REP, player, ENTRY_MENU_ID);
  -- TELEPORTS
  elseif intid == 20 then
    -- STV
    TeleportPlayer(player, intid);
    player:GossipComplete();
  elseif intid == 21 then
    -- Thunder Bluff
    TeleportPlayer(player, intid);
    player:GossipComplete();
  elseif intid == 30 then
    -- The Deadmines
    TeleportPlayer(player, intid);
    player:GossipComplete();
  elseif intid == 31 then
    -- SFK
    TeleportPlayer(player, intid);
    player:GossipComplete();
  elseif intid == 50 then
    -- Timbermaw Hold
    TeleportPlayer(player, intid);
    player:GossipComplete();
  elseif intid == 109 then
    -- Main menu
    player:GossipClearMenu();
    player:GossipMenuAddItem(2, "Home", 0, 1);
    player:GossipMenuAddItem(2, "PvP", 0, 2);
    player:GossipMenuAddItem(2, "Dungeons", 0, 3);
    player:GossipMenuAddItem(2, "Raids", 0, 4);
    player:GossipMenuAddItem(2, "Reputation", 0, 5);
    player:GossipSendMenu(ENTRY_TEXT_MAIN, player, ENTRY_MENU_ID);
  end
end

-- RegisterItemEvent(ENTRY_TELEPORT_RUNE, 2, Rune.OnUse);                -- ITEM_EVENT_ON_USE
RegisterItemGossipEvent(ENTRY_TELEPORT_RUNE, 1, Rune.OnGossipHello);  -- GOSSIP_EVENT_ON_HELLO
-- RegisterItemGossipEvent(ENTRY_TELEPORT_RUNE, 2, Rune.OnGossipSelect); -- GOSSIP_EVENT_ON_SELECT
RegisterPlayerGossipEvent(ENTRY_MENU_ID, 2, Rune.OnGossipSelect)
