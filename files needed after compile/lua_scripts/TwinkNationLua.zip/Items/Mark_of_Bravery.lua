--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Mark of Bravery - Awards rep with pvp factions.
 * AUTHOR : sundays
 * UPDATED: 8th Nov 2016
--]]

-- Constants
local ENTRY_ITEM = 74328;
local REPUTATION_MIN_AMOUNT = 35;
local REPUTATION_MAX_AMOUNT = 65;

local FACTIONS = {
  [1] = {509, "League of Arathor"},   -- Ally AB
  [2] = {510, "Defilers"},            -- Horde AB
  [3] = {889, "Warsong Outriders"},   -- Horde WSG
  [4] = {890, "Silverwing Sentinels"} -- Ally WSG
};

local Item = {};

function Item.OnUse(event, player, item, _)
  local REPUTATION_AMOUNT = math.random(REPUTATION_MIN_AMOUNT, REPUTATION_MAX_AMOUNT);
  if player:IsAlliance() then
    local abRep  = player:GetReputation(FACTIONS[1][1]);
    local wsgRep = player:GetReputation(FACTIONS[4][1]);
    player:SetReputation(FACTIONS[1][1], abRep + REPUTATION_AMOUNT);
    player:SetReputation(FACTIONS[4][1], wsgRep + REPUTATION_AMOUNT);
    player:SendBroadcastMessage(string.format("You gain %d reputation with The %s and The %s.", REPUTATION_AMOUNT, FACTIONS[4][2], FACTIONS[1][2]));
  else
    local abRep  = player:GetReputation(FACTIONS[2][1]);
    local wsgRep = player:GetReputation(FACTIONS[3][1]);
    player:SetReputation(FACTIONS[2][1], abRep + REPUTATION_AMOUNT);
    player:SetReputation(FACTIONS[3][1], wsgRep + REPUTATION_AMOUNT);
    player:SendBroadcastMessage(string.format("You gain %d reputation with The %s and The %s.", REPUTATION_AMOUNT, FACTIONS[3][2], FACTIONS[2][2]));
  end
end

 RegisterItemEvent(ENTRY_ITEM, 2, Item.OnUse); -- ITEM_EVENT_ON_USE
