--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Pirate Hat - transforms user into a pirate for 5min. 15 min cd.
 * AUTHOR : sundays
 * UPDATED: 28th October 2016
--]]

-- Constants
local ENTRY_HAT    = 74304;
local SPELL_PIRATE = 24708; -- Pirate costume

local Hat = {};

function Hat.OnUse(event, player, item, _)
  player:CastSpell(player, SPELL_PIRATE, true);
  if player:HasAura(SPELL_PIRATE) then
    local PirateAura = player:GetAura(SPELL_PIRATE);
    if PirateAura then
      PirateAura:SetDuration(300000); -- 5 minutes
    end
  end
end

 RegisterItemEvent(ENTRY_HAT, 2, Hat.OnUse); -- ITEM_EVENT_ON_USE
