--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Venomous Jadecrawler - Feralas mob.
 * AUTHOR : sundays
 * UPDATED: 23rd Sept 2016
--]]

-- Constants
local ENTRY_SPIDER        = 90069;
local SPELL_DEADLY_POISON = 3583;
local SPELL_WITHERING     = 13884;

local Spider = {};

function Spider.WitheringPoison(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_WITHERING, true);
    local PoisonAura = Victim:GetAura(SPELL_WITHERING);
    if PoisonAura then
      PoisonAura:SetDuration(25000);
    end
  end
end

-- Main
function Spider.OnEnterCombat(event, creature, target)
  if math.random(1, 100) >= 90 then
    creature:CastSpell(target, SPELL_DEADLY_POISON, true);
    local PoisonAura = target:GetAura(SPELL_DEADLY_POISON);
    if PoisonAura then
      PoisonAura:SetDuration(60000);
    end
  end
  creature:RegisterEvent(Spider.WitheringPoison, 12000, 1);
end

function Spider.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Spider.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_SPIDER, 1, Spider.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_SPIDER, 2, Spider.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_SPIDER, 4, Spider.OnDied);        -- CREATURE_EVENT_ON_DIED
