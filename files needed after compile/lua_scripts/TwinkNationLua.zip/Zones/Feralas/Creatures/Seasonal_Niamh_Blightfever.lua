--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Niamh Blightfever - Hallow's End quest giver.
 * AUTHOR : sundays
 * UPDATED: 29th Oct 2016
--]]

-- Constants
local ENTRY_NIAMH     = 90085;
local ENTRY_SPIRIT    = 90083;
local TEXT_GOSSIP_1   = 60004;
local TEXT_GOSSIP_2   = 60005;
local QUEST_SUMM_BOSS = 90002;

local Niamh = {
  Strings = {
    -- Boss summoned.
    "Oh no! Watch out!",
    "Behind you!",
  };
};

function Niamh.OnHello(event, player, object)
  player:GossipClearMenu();
  player:GossipAddQuests(object);
  if math.random(1, 2) == 1 then
    player:GossipSendMenu(TEXT_GOSSIP_1, object);
  else
    player:GossipSendMenu(TEXT_GOSSIP_2, object);
  end
end

function Niamh.OnQuestAccept(event, player, creature, quest)
  if quest:GetId() == QUEST_SUMM_BOSS then
    local x, y, z    = creature:GetRelativePoint(10, 0);
    local RandomText = math.random(1, 2);
    local SummonedBoss = PerformIngameSpawn(1, ENTRY_SPIRIT, 1, 0, x, y, z, 0, false);
    SummonedBoss:SetRespawnDelay(696969);
    SummonedBoss:StartAttack(player);
    creature:SendUnitSay(Niamh.Strings[RandomText], 0);
  end
end

RegisterCreatureEvent(ENTRY_NIAMH, 31, Niamh.OnQuestAccept); -- CREATURE_EVENT_ON_QUEST_ACCEPT
RegisterCreatureGossipEvent(ENTRY_NIAMH, 1, Niamh.OnHello);  -- GOSSIP_EVENT_ON_HELLO