--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Spirit of Samhain - Hallow's End Feralas mob. Summoned by quest.
 * AUTHOR : sundays
 * UPDATED: 29th Oct 2016
--]]

-- Constants
local ENTRY_SPIRIT   = 90083;
local SPELL_CLEAVE   = 11609;
local QUEST_INVASION = 90002;
local CREDIT_QUEST   = 90085;

local Spirit = {
  Strings = {
    -- On combat
    "What a terrible mistake you've made, mortal.",
    "Hah, look at you -- you're only flesh and bones.",
    "I can't wait to pierce your flesh with this sword.",
  };
};

function Spirit.Cleave(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_CLEAVE, false);
  end
end

-- Main
function Spirit.OnEnterCombat(event, creature, target)
  local RandomText = math.random(1, 3);
  creature:SendUnitSay(Spirit.Strings[RandomText], 0);
  creature:RegisterEvent(Spirit.Cleave, 12000, 3);
end

function Spirit.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Spirit.OnDied(event, creature, killer)
  if killer:HasQuest(QUEST_INVASION) then
    if killer:IsInGroup() then
      local Group = killer:GetGroup();
      local GroupMembers = Group:GetMembers();
      for _, v in pairs(GroupMembers) do
        if v:HasQuest(QUEST_INVASION) and v:GetDistance(creature) <= 25 then
          v:KilledMonsterCredit(CREDIT_QUEST);
        end
      end
    else
      killer:KilledMonsterCredit(CREDIT_QUEST);
    end
  end
end

RegisterCreatureEvent(ENTRY_SPIRIT, 1, Spirit.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_SPIRIT, 2, Spirit.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_SPIRIT, 4, Spirit.OnDied);        -- CREATURE_EVENT_ON_DIED
