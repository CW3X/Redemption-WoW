--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Mangled Feralas Hoodlum - Hallow's End Feralas mob.
 * AUTHOR : sundays
 * UPDATED: 29th Oct 2016
--]]

-- Constants
local ENTRY_HOODLUM  = 90081;
local SPELL_KICK     = 15618; -- bp0: stun, bp1: damage
local QUEST_INVASION = 90001;
local CREDIT_QUEST   = 90084;

local Hoodlum = {};

function Hoodlum.Kick(event, delay, repeats, creature)
  if math.random(1, 100) >= 50 then
    local Victim = creature:GetVictim();
    if Victim then
      creature:CastSpell(Victim, SPELL_KICK, false);
    end
  end
end

-- Main
function Hoodlum.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Hoodlum.Kick, 2500, 1);
end

function Hoodlum.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Hoodlum.OnDied(event, creature, killer)
  if killer:HasQuest(QUEST_INVASION) then
    if killer:IsInGroup() then
      local Group = killer:GetGroup();
      local GroupMembers = Group:GetMembers();
      for _, v in pairs(GroupMembers) do
        if v:HasQuest(QUEST_INVASION) and v:GetDistance(creature) <= 25 then
          v:KilledMonsterCredit(CREDIT_QUEST);
        end
      end
    else
      killer:KilledMonsterCredit(CREDIT_QUEST);
    end
  end
end

RegisterCreatureEvent(ENTRY_HOODLUM, 1, Hoodlum.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_HOODLUM, 2, Hoodlum.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_HOODLUM, 4, Hoodlum.OnDied);        -- CREATURE_EVENT_ON_DIED
