--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Veiled Sea Murloc - Feralas mob.
 * AUTHOR : sundays
 * UPDATED: 23rd Sept 2016
--]]

-- Constants
local ENTRY_MURLOC        = 90070;
local SPELL_STAB = 15656;
local SPELL_POTION = 440; -- 141-180 health

local Murloc = {
  Strings = {
    "Aaaaaughibbrgubugbugrguburgle!",
    "Ggmmmlmrmrgmg!",
    "Mglrmglmglmgl.",
    "Mrgll mmmgrugllgle.",
    "The murloc makes a series of unintelligible noises.",
  };
};

function Murloc.Stab(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_STAB);
  end
end

function Murloc.CheckHealth(event, delay, repeats, creature)
  if creature:GetHealthPct() <= 50 then
    if math.random(1, 100) >= 50 then
     creature:CastSpell(creature, SPELL_POTION, true);
    end
    RemoveEventById(event);
  end
end

-- Main
function Murloc.OnEnterCombat(event, creature, target)
  local RandomInterval = math.random(7500, 12000);
  local RandomAttacks  = math.random(1, 4);
  if math.random(1, 100) >= 75 then
    local RandomText = math.random(1, 5);
    if RandomText == 5 then
      creature:SendUnitEmote(Murloc.Strings[5], nil, false);
    else
      creature:SendUnitSay(Murloc.Strings[RandomText], 0);
    end
  end
  creature:RegisterEvent(Murloc.Stab, RandomInterval, RandomAttacks);
  creature:RegisterEvent(Murloc.CheckHealth, 2000, 0);
end

function Murloc.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Murloc.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_MURLOC, 1, Murloc.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_MURLOC, 2, Murloc.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_MURLOC, 4, Murloc.OnDied);        -- CREATURE_EVENT_ON_DIED
