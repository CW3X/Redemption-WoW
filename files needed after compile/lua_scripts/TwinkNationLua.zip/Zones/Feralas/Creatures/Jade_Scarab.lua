--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Jade Scarab - Feralas mob.
 * AUTHOR : sundays
 * UPDATED: 23rd Sept 2016
--]]

-- Constants
local ENTRY_SCARAB = 90073;
local SPELL_BITE   = 7938;
local SPELL_TENDON = 3604; -- tendon rip

local Scarab = {};

function Scarab.Bite(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_BITE);
  end
end

function Scarab.TendonRip(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim and math.random(1, 100) >= 15 then
    creature:CastSpell(Victim, SPELL_TENDON);
  end
end

-- Main
function Scarab.OnEnterCombat(event, creature, target)
  local RandomAttacks = math.random(1, 2);
  creature:RegisterEvent(Scarab.Bite, 6000, RandomAttacks);
  creature:RegisterEvent(Scarab.TendonRip, 8000, 1);
end

function Scarab.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Scarab.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_SCARAB, 1, Scarab.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_SCARAB, 2, Scarab.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_SCARAB, 4, Scarab.OnDied);        -- CREATURE_EVENT_ON_DIED
