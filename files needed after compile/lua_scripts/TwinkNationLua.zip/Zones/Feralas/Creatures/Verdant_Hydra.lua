--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Verdant Hydra - Feralas mob.
 * AUTHOR : sundays
 * UPDATED: 23rd Sept 2016
--]]

-- Constants
local ENTRY_HYDRA  = 90071;
local SPELL_STRIKE = 14261;
local SPELL_SUNDER = 7386;

local Hydra = {};

function Hydra.Strike(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_STRIKE);
  end
end

function Hydra.Sunder(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_SUNDER);
  end
end

-- Main
function Hydra.OnEnterCombat(event, creature, target)
  local RandomAttacks  = math.random(1, 5);
  local RandomInterval = math.random(7500, 11000);
  creature:RegisterEvent(Hydra.Strike, RandomInterval, 0);
  creature:RegisterEvent(Hydra.Sunder, 5000, RandomAttacks);
end

function Hydra.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Hydra.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_HYDRA, 1, Hydra.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_HYDRA, 2, Hydra.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_HYDRA, 4, Hydra.OnDied);        -- CREATURE_EVENT_ON_DIED
