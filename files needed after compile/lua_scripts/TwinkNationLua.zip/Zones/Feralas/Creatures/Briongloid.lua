--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Briongloid, the Dream Keeper - World Boss
 * AUTHOR : sundays
 * UPDATED: 7th November 2016
--]]

-- Constants
local ENTRY_BOSS        = 90067;
local SPELL_BROOD_POWER = 22289; -- Green, 6s stun
local SPELL_CLEAVE      =  8255; -- 32% attack speed reduction
local SPELL_CHARM       = 25806; -- Creature of Nightmare
local SPELL_CYCLONE     =  8609; -- Enrage visual
local SPELL_STRIKE      =  2973; -- Used by charmed players.

local Boss = {
  Charmed = {},
  LastTarget,
  Strings = {
    -- Charm player emote
    "Briongloid has control over %s.",
    -- Charm player
    "Join me, %s.",
    "Stand by my side, %s. The Dreamweaver won't be disturbed.",
    "Join us, %s. The Dreamweaver calls, her sanctuary shall not be defiled.",
    -- Enrage
    "All things must come to an end."
  };
};

local function Suicide(event, _, _, player)
  player:Kill(player, true);
end

local function RemoveExistingCharms(t)
  local new_t = {};            -- create a new table
  local i, v = next(t, nil);   -- i is an index of t, v = t[i]
  while i do
    new_t[i] = v;
    i, v = next(t, i);         -- get next index
  end
  for i, v in pairs(new_t) do
    local Player = GetPlayerByGUID(i);
	Player:MoveClear(true);
	Player:SetPlayerLock(false);
    RemoveEventById(v);
    PrintError(string.format("[BOSS] Removed event %d from player guid %d.", v, i));
  end
end

local function RemoveCharm(event, delay, repeats, player)
  player:AttackStop();
  player:MoveClear(true);
  player:SetPlayerLock(false);
  RemoveEventById(event);
end

local function CharmedAttack(event, delay, repeats, player)
  if player:IsCharmed() then
    local Victim = player:GetVictim();
    if Victim then
      player:CastSpell(Victim, SPELL_STRIKE, true);
    end
  else
    RemoveEventById(event);
  end
end

function Boss.Charm(event, delay, repeats, creature)
  local Target  = creature:GetAITarget(1, true, 1, 100); -- Top aggro (1 offset, therefore not tank), player only, 100yd
  local Target2 = creature:GetAITarget(0, true, 0, 100); -- Target to attack.
  local RandomText = math.random(2, 4);
  if Target then
    local TargetGUID = Target:GetGUIDLow();
    creature:CastSpell(Target, SPELL_CHARM, true);
    local CharmAura = Target:GetAura(SPELL_CHARM);
    if not CharmAura then
      return;
    end
    CharmAura:SetDuration(10000);
    Target:SetPlayerLock(true);
    if Target == Target2 then
      -- Prevent attacking self.
      local Victim = creature:GetVictim();
      Target:Attack(Victim, true);
      Target:MoveFollow(Victim);
      creature:SendUnitEmote(string.format(Boss.Strings[1], Target:GetName()), nil, true);
      Boss.Charmed[TargetGUID] = Target:RegisterEvent(RemoveCharm, 10000, 1);
	    Target:RegisterEvent(CharmedAttack, 2000, 4);
    else
      Target:Attack(Target2, true);
      Target:MoveFollow(Target2);
      creature:SendUnitEmote(string.format(Boss.Strings[1], Target:GetName()), nil, true);
      Boss.Charmed[TargetGUID] = Target:RegisterEvent(RemoveCharm, 10000, 1);
	    Target:RegisterEvent(CharmedAttack, 2000, 4);
    end
    creature:SendUnitYell(string.format(Boss.Strings[RandomText], Target:GetName()), 0);
  end
end

function Boss.Stun(event, delay, repeats, creature)
  local Target     = creature:GetAITarget(0, true, 0, 100);
  if Target then
    local TargetGUID = Target:GetGUIDLow();
    if Target and Target:GetGUIDLow() ~= Boss.LastTarget then
      creature:CastSpell(Target, SPELL_BROOD_POWER, true);
      Boss.LastTarget = TargetGUID;
    end
  end
end

function Boss.Cleave(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_CLEAVE);
  end
end

function Boss.Enrage(event, delay, repeats, creature)
  local Targets = creature:GetAITargets(); -- All Targets
  for _, v in pairs(Targets) do
    v:CastSpell(v, SPELL_CYCLONE, true);
    v:RegisterEvent(Suicide, 2000, 1);
	RemoveExistingCharms(Boss.Charmed);
  end
  creature:SendUnitYell(Boss.Strings[5], 0);
end

-- Main
function Boss.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Boss.Cleave, 18500, 0);
  creature:RegisterEvent(Boss.Charm, 20000, 0);
  creature:RegisterEvent(Boss.Enrage, 450000, 1); -- 450s: 7.5 minutes (450000)
  creature:RegisterEvent(Boss.Stun, 10000, 0);
end

function Boss.OnLeaveCombat(event, creature)
  RemoveExistingCharms(Boss.Charmed);
  creature:RemoveEvents();
end

function Boss.OnDied(event, creature, killer)
  RemoveExistingCharms(Boss.Charmed);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_BOSS, 1, Boss.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_BOSS, 2, Boss.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_BOSS, 4, Boss.OnDied);        -- CREATURE_EVENT_ON_DIED
