--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Feralas Nomad - Hallow's End Feralas mob.
 * AUTHOR : sundays
 * UPDATED: 29th Oct 2016
--]]

-- Constants
local ENTRY_NOMAD    = 90079;
local SPELL_REND     = 16509;
local QUEST_INVASION = 90001;
local CREDIT_QUEST   = 90084;

local Nomad = {};

function Nomad.Rend(event, delay, repeats, creature)
  if math.random(1, 100) >= 50 then
    local Victim = creature:GetVictim();
    if Victim then
      creature:CastSpell(Victim, SPELL_REND, false);
    end
  end
end

-- Main
function Nomad.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Nomad.Rend, 2500, 1);
end

function Nomad.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Nomad.OnDied(event, creature, killer)
  if killer:HasQuest(QUEST_INVASION) then
    if killer:IsInGroup() then
      local Group = killer:GetGroup();
      local GroupMembers = Group:GetMembers();
      for _, v in pairs(GroupMembers) do
        if v:HasQuest(QUEST_INVASION) and v:GetDistance(creature) <= 25 then
          v:KilledMonsterCredit(CREDIT_QUEST);
        end
      end
    else
      killer:KilledMonsterCredit(CREDIT_QUEST);
    end
  end
end

RegisterCreatureEvent(ENTRY_NOMAD, 1, Nomad.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_NOMAD, 2, Nomad.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_NOMAD, 4, Nomad.OnDied);        -- CREATURE_EVENT_ON_DIED
