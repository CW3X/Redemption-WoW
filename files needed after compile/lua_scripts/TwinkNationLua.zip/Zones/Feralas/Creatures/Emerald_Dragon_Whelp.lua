--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Emerald Dragon Whelp - Feralas mob.
 * AUTHOR : sundays
 * UPDATED: 23rd Sept 2016
--]]

-- Constants
local ENTRY_WHELP  = 90072;
local SPELL_FIREBALL = 145;

local Whelp = {};

function Whelp.Fireball(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    local RandomDamage = math.random(34, 63);
    creature:CastCustomSpell(Victim, SPELL_FIREBALL, false, RandomDamage, nil, nil, nil, 0); -- bp0: School damage, bp1: Periodic damage
  end
end

-- Main
function Whelp.OnEnterCombat(event, creature, target)
  local RandomAttacks  = math.random(2, 6);
  local RandomInterval = math.random(3500, 5500);
  creature:RegisterEvent(Whelp.Fireball, RandomInterval, RandomAttacks);
end

function Whelp.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Whelp.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_WHELP, 1, Whelp.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_WHELP, 2, Whelp.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_WHELP, 4, Whelp.OnDied);        -- CREATURE_EVENT_ON_DIED
