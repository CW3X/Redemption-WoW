--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Risen Feralas Invader - Hallow's End Feralas mob.
 * AUTHOR : sundays
 * UPDATED: 29th Oct 2016
--]]

-- Constants
local ENTRY_INVADER  = 90082;
local SPELL_BACKHAND =  6253;
local QUEST_INVASION = 90001;
local CREDIT_QUEST   = 90084;

local Invader = {};

function Invader.Backhand(event, delay, repeats, creature)
  if math.random(1, 100) >= 50 then
    local Victim = creature:GetVictim();
    if Victim then
      creature:CastSpell(Victim, SPELL_BACKHAND, false);
    end
    RemoveEventById(event); -- Can only happen once.
  end
end

-- Main
function Invader.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Invader.Backhand, 2500, 2);
end

function Invader.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Invader.OnDied(event, creature, killer)
  if killer:HasQuest(QUEST_INVASION) then
    if killer:IsInGroup() then
      local Group = killer:GetGroup();
      local GroupMembers = Group:GetMembers();
      for _, v in pairs(GroupMembers) do
        if v:HasQuest(QUEST_INVASION) and v:GetDistance(creature) <= 25 then
          v:KilledMonsterCredit(CREDIT_QUEST);
        end
      end
    else
      killer:KilledMonsterCredit(CREDIT_QUEST);
    end
  end
end

RegisterCreatureEvent(ENTRY_INVADER, 1, Invader.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_INVADER, 2, Invader.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_INVADER, 4, Invader.OnDied);        -- CREATURE_EVENT_ON_DIED
