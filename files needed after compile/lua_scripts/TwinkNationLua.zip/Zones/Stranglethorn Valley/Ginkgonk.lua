--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Gink'gonk - World Boss
 * AUTHOR : sundays
 * UPDATED: 23rd Sept 2016
--]]

-- CONSTANTS
local ENTRY_BOSS      = 90068;
local SPELL_ENRAGE    = 28798; -- Wipes the raid
local SPELL_WOUND     = 17230; -- Infected wound.
local SPELL_KNOCKAWAY = 18813;
local SPELL_KNOCKOUT  = 17307;

local Boss = {
  Strings = {
    -- On target kill.
    "The scent of blood angers Gink'gonk. He regains some of his strength.",
  };
};

function Boss.Infect(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_WOUND, false);
    local WoundAura = Victim:GetAura(SPELL_WOUND);
    if WoundAura then
      WoundAura:SetDuration(30000);
    end
  end
end

function Boss.Knockback(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    local BonusDamage  = math.random(30, 70);
    local KnockBackPwr = math.random(125, 225);
    creature:CastCustomSpell(Victim, SPELL_KNOCKAWAY, false, BonusDamage, KnockBackPwr, nil, nil, 0);
  end
end

function Boss.Knockout(event, delay, repeats, creature)
   local Target = creature:GetAITarget(0, true, 0, 20);
  if Target then
    creature:CastSpell(Target, SPELL_KNOCKOUT, true);
  end
end

function Boss.Enrage(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_ENRAGE, true);
end

-- Main
function Boss.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Boss.Enrage, 450000, 1); -- 450s: 7.5 minutes (450000)
  creature:RegisterEvent(Boss.Infect, 24000, 0);
  creature:RegisterEvent(Boss.Knockback, 10000, 0);
  creature:RegisterEvent(Boss.Knockout, 12000, 0);
end

function Boss.OnTargetDied(event, creature, victim)
  if victim:GetTypeId() == 4 then -- Player
    local HealAmount = creature:GetMaxHealth() * 0.1;
    creature:DealHeal(creature, 5189, HealAmount, false);
    creature:SendUnitEmote(Boss.Strings[1], nil, true);
  end
end

function Boss.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Boss.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_BOSS, 1, Boss.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_BOSS, 2, Boss.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_BOSS, 3, Boss.OnTargetDied); -- CREATURE_EVENT_ON_TARGET_DIED
RegisterCreatureEvent(ENTRY_BOSS, 4, Boss.OnDied);        -- CREATURE_EVENT_ON_DIED
