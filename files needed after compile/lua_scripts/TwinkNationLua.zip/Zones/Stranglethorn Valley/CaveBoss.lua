--[[
  * DATE   : 25th Sept 2016
  * AUTHOR : sundays
  * DESC   : STV Boss - Summoned by quest. Includes little prelude/dialogue thing.
--]]

local ENTRY_JOE_ARBINGTON = 90035;
local ENTRY_ZULJIAN       = 90036;
local ENTRY_QUEST         = 90000;
local ENTRY_TIGER1        = 90037;
local ENTRY_TIGER2        = 90038;
local SPELL_ENRAGE        =  8599;
local SPELL_SHRINK        =  7289; -- -6 stam & str
local SPELL_BLOODLUST     =  6742; -- 30% attack speed
local SPELL_WHIRLWIND     = 28335;
local SPELL_HEMORRHAGE    = 17348; -- increased damage by up to 8
local SPELL_TRIP          =   101; -- 3s stun
local SPELL_DRINK_POTION  =  4042; -- 800-900 heal potion
local SPELL_VISUAL_SLEEP  =  6606;
local SPELL_VISUAL_ROCK   = 23065; -- Throw rock
local FACTION_MONSTER     =    14;
local FACTION_FRIENDLY    =    35;

local Arbington = {
  Strings = {
    -- On complete
    "You asked for it, %s... just watch.",
    "Sure, %s. Watch this.",
    -- WP 1
    "Time to wake up, little troll.",
    -- On hit
    "Zuljian no like dis! Where am I?",
    -- WP 2
    "It's your problem now.",
  },
  Waypoints = {
    [1] = {-13206.37, -579.91, 12.77, 3.56},
    [2] = {-13185.55, -565.84, 12.11, 0.58};
  },
  Count = 0;
};

function Arbington.Increment(event, delay, repeats, creature)
  Arbington.Count = Arbington.Count + 1;
  local i = Arbington.Count;
  if i == 1 then
    creature:MoveTo(0, Arbington.Waypoints[1][1], Arbington.Waypoints[1][2], Arbington.Waypoints[1][3], true);
  elseif i == 6 then
    creature:SendUnitSay(Arbington.Strings[3], 0);
  elseif i == 8 then
    local Troll = creature:GetNearestCreature(533, ENTRY_ZULJIAN, 0, 1); -- alive
    creature:CastSpell(Troll, SPELL_VISUAL_ROCK, false);
  elseif i == 10 then
    creature:SendUnitSay(Arbington.Strings[5], 0);
  elseif i == 11 then
    creature:SetWalk(false);
    creature:MoveTo(0, Arbington.Waypoints[2][1], Arbington.Waypoints[2][2], Arbington.Waypoints[2][3], true);
    creature:DespawnOrUnsummon(2300);
    local Troll = creature:GetNearestCreature(533, ENTRY_ZULJIAN, 0, 1); -- alive
    Troll:SetFaction(FACTION_MONSTER);
    creature:RemoveEventById(event);
  end
end

function Arbington.OnQuestReward(event, player, creature, quest, opt)
  if quest:GetId() == ENTRY_QUEST then
    local randomText = math.random(1, 2);
    local playerName = player:GetName();
    creature:SendUnitSay(string.format(Arbington.Strings[randomText], playerName), 0);
    local Zuljian = PerformIngameSpawn(1, ENTRY_ZULJIAN, 0, 0, -13225, -579, 4.65, 5.3, false, 7200000, 1); -- Despawn in 2 hours (7200 sec)
    Zuljian:SetRespawnDelay(696969); -- Just in case
    Zuljian:SetFaction(FACTION_FRIENDLY);
    creature:SetNPCFlags(0); -- Disable gossip & quest
    Arbington.Count = 0;
    creature:SetWalk(true);
    creature:RegisterEvent(Arbington.Increment, 1000, 0);
  end
end

RegisterCreatureEvent(ENTRY_JOE_ARBINGTON, 34, Arbington.OnQuestReward);

-- Zuljian the Captive
local Zuljian = {
  Strings = {
    -- Drink potion
    "Da voodoo human give me dem potions for a reason!",
    "I like dis potions witch doctor give me!",
    "Potions! Very nice!",
    -- Shrink
    "Tiny %s is best kind of %s!",
    "Haha! %s is now tiny!",
    -- Whirlwind
    "Now you be annoyin' me!",
    "Run! Run!",
    "I like it when dey run!",
    -- Summon tigers
    "Zuljian blows a whistle.",
  };
};

function Zuljian.Hemorrhage(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_HEMORRHAGE, true);
end

function Zuljian.Shrink(event, delay, repeats, creature)
  local Target     = creature:GetAITarget(0, true, 0, 35);
  local TargetRace = Target:GetRaceAsString();
  local randomText = math.random(4, 5);
  creature:SendUnitSay(string.format(Zuljian.Strings[randomText], TargetRace), 0);
  creature:CastSpell(Target, SPELL_SHRINK, true);
end

function Zuljian.Whirlwind(event, delay, repeats, creature)
  local randomText = math.random(6, 8);
  creature:SendUnitSay(Zuljian.Strings[randomText], 0);
  creature:CastSpell(creature, SPELL_WHIRLWIND, false);
end

function Zuljian.Trip(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_TRIP, true);
end

function Zuljian.Potion(event, delay, repeats, creature)
  local HealthPct = creature:GetHealthPct();
  if HealthPct <= 50 then
    local randomText = math.random(1, 3);
    creature:SendUnitSay(Zuljian.Strings[randomText], 0);
    creature:CastSpell(creature, SPELL_DRINK_POTION, true);
    creature:RemoveEventById(event);
  end
end

function Zuljian.Tigers(event, delay, repeats, creature)
  local HealthPct = creature:GetHealthPct();
  if HealthPct <= 40 then
    local Victim = creature:GetVictim();
    creature:SendUnitEmote(Zuljian.Strings[9], nil, true);
    local x1, y1, z1 = creature:GetRelativePoint(2, 90 * math.pi / 180);
    local x2, y2, z2 = creature:GetRelativePoint(2, 270 * math.pi / 180);
    local creatureO  = creature:GetO();
    local Tiger1 = PerformIngameSpawn(1, ENTRY_TIGER1, 0, 0, x1, y1, z1, creatureO, false, 0, 1);
    local Tiger2 = PerformIngameSpawn(1, ENTRY_TIGER2, 0, 0, x2, y2, z2, creatureO, false, 0, 1);
    Tiger1:AttackStart(Victim);
    Tiger2:AttackStart(Victim);
    Tiger1:SetRespawnDelay(696969);
    Tiger2:SetRespawnDelay(696969); -- fuck you too, mangos
    creature:RemoveEventById(event);
  end
end

-- Main
function Zuljian.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Zuljian.Hemorrhage, 12000, 0);
  creature:RegisterEvent(Zuljian.Shrink, 16000, 5);
  creature:RegisterEvent(Zuljian.Whirlwind, 12000, 0);
  creature:RegisterEvent(Zuljian.Trip, 20000, 4);
  creature:RegisterEvent(Zuljian.Potion, 3000, 0);
  creature:RegisterEvent(Zuljian.Tigers, 3500, 0);
end

function Zuljian.OnLeaveCombat(event, creature)
  local Tiger1 = creature:GetNearestCreature(533, ENTRY_TIGER1, 0, 1);
  local Tiger2 = creature:GetNearestCreature(533, ENTRY_TIGER2, 0, 1);
  if Tiger1 then Tiger1:DespawnOrUnsummon(0) end
  if Tiger2 then Tiger2:DespawnOrUnsummon(0) end
  creature:RemoveEvents();
end

function Zuljian.OnDied(event, creature)
  local nearestArbington = creature:GetNearestCreature(533, ENTRY_JOE_ARBINGTON, 0, 0);
  if not nearestArbington:IsAlive() then
    nearestArbington:Respawn();
  end
  creature:RemoveEvents();
end

function Zuljian.OnHitBySpell(event, creature, caster, spellid)
  if caster:GetEntry() == ENTRY_JOE_ARBINGTON and spellid == SPELL_VISUAL_ROCK then
    creature:SendUnitYell(Arbington.Strings[4], 0);
    if creature:HasAura(SPELL_VISUAL_SLEEP) then
      creature:RemoveAura(SPELL_VISUAL_SLEEP);
    end
  end
end

function Zuljian.OnReset(event, creature)
  creature:CastSpell(creature, SPELL_VISUAL_SLEEP, true);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_ZULJIAN,  1, Zuljian.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_ZULJIAN,  2, Zuljian.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_ZULJIAN,  4, Zuljian.OnDied);        -- CREATURE_EVENT_ON_DIED
RegisterCreatureEvent(ENTRY_ZULJIAN, 14, Zuljian.OnHitBySpell);  -- CREATURE_EVENT_ON_HIT_BY_SPELL
RegisterCreatureEvent(ENTRY_ZULJIAN, 23, Zuljian.OnReset);       -- CREATURE_EVENT_ON_RESET

-- Tiger 1
local Tazdi = {};

function Tazdi.OnDied(event, creature, killer)
  local Troll = creature:GetNearestCreature(533, ENTRY_ZULJIAN, 0, 1);
  if not Troll:HasAura(SPELL_ENRAGE) then
    Troll:CastSpell(Troll, SPELL_ENRAGE, true);
  end
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_TIGER1, 4, Tazdi.OnDied);

-- Tiger 2
local Zidaie = {};

function Zidaie.OnDied(event, creature, killer)
  local Troll = creature:GetNearestCreature(533, ENTRY_ZULJIAN, 0, 1);
  if not Troll:HasAura(SPELL_ENRAGE) then
    Troll:CastSpell(Troll, SPELL_ENRAGE, true);
  end
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_TIGER2, 4, Zidaie.OnDied);
