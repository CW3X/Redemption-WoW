--[[
  * http://twinknation.org/
  * DESC   : Starts a FFA PvP battle in Thunder Bluff if X players are present
  * AUTHOR : Sundays
  * UPDATED: 6th Nov 2016
--]]

-- CONSTANTS
local FACTION_SENTINELS = 890;
local FACTION_WARSONG   = 889;
local QUEST_TB          = 90005;
local CREDIT_QUEST_TB   = 90088;

local ThunderBluffEvent = {
  Strings = {
    "%s has killed %d opponents and becomes victorious in the battle for Thunder Bluff.",
    "The next battle can begin in %d minutes.",
    "The battle for Thunder Bluff finishes with no winner.",
    "You cannot join or create groups while in the battle for Thunder Bluff.",
    "You have been awarded %d gold for winning the battle for Thunder Bluff.",
    "You have been awarded %d gold for participating in the battle for Thunder Bluff.",
    "The battle for Thunder Bluff has begun. You have 20 minutes to reach 5 kills.",
  },
  Rewards = {
    Winner = 250000, -- Default: 250000 (25 gold)
    Loser  =  30000, -- Default: 30000  (3 gold) <- AWARDED PER KILL
  },
  MapId             = 1,
  ZoneId            = 1638,
  MinPlayersToStart = 5,
  MinKillsToWin     = 5,
  MaxLength         = 60, -- 60 minutes(?) apparently 10 = 5 minutes so should be 30 mins [looks like it's 20 mins]
  PlayerBattleContribution = {},
  EventWinner = nil,
  IsRunning = false,
  LastBattleTime = 0,
  ReputationReward = 5, -- per kill
  StopBattleId = nil;
};

local function ResetBattle()
  ThunderBluffEvent.IsRunning = false;
  ThunderBluffEvent.PlayerBattleContribution = {};
  ThunderBluffEvent.EventWinner = nil;
  RemoveEventById(ThunderBluffEvent.StopBattleId);
end

local function HandleReward()
  for pGuid, pKills in pairs(ThunderBluffEvent.PlayerBattleContribution) do
    PrintInfo("Rewarding GUID for Thunder Bluff event: ", pGuid);
    local PlayerObject = GetPlayerByGUID(pGuid);
    if PlayerObject then
      if pGuid ~= ThunderBluffEvent.EventWinner then
        -- Runner-ups
        local PlayerContrib = pKills;
        if PlayerContrib > 0 then
          if PlayerObject:HasQuest(90016) then -- TB tutorial
            PlayerObject:CompleteQuest(90016);
          end
          PlayerObject:ModifyMoney(PlayerContrib * ThunderBluffEvent.Rewards.Loser);
          PlayerObject:SendBroadcastMessage(string.format(ThunderBluffEvent.Strings[6], (PlayerContrib * ThunderBluffEvent.Rewards.Loser) / 10000));
        end
      else
        -- Winner
        PlayerObject:ModifyMoney(ThunderBluffEvent.Rewards.Winner);
        PlayerObject:SendBroadcastMessage(string.format(ThunderBluffEvent.Strings[5], ThunderBluffEvent.Rewards.Winner / 10000));
        SendWorldMessage("[EVENT] " .. string.format(ThunderBluffEvent.Strings[1], PlayerObject:GetName(), ThunderBluffEvent.MinKillsToWin));
        PlayerObject:CreditBattlegroundVictory(2, 1); -- TB, 1 point
        if PlayerObject:HasQuest(90016) then -- TB tutorial
          PlayerObject:CompleteQuest(90016);
        end
      end
    end
  end
  SendWorldMessage("[EVENT] " .. string.format(ThunderBluffEvent.Strings[2], 10));
end

local function DisbandGroup(group)
  local groupMembers = group:GetMembers();
  for _, v in pairs(groupMembers) do
    local memberGUID = v:GetGUIDLow();
    local playerObj  = GetPlayerByGUID(memberGUID);
    if group:IsMember(memberGUID) then
      group:RemoveMember(memberGUID, 2);
      v:SendBroadcastMessage(ThunderBluffEvent.Strings[4]);
    end
  end
end

-- Main
function ThunderBluffEvent.OnEnterArea(event, player, newZone, newArea)
  local count = 0;
  if newZone == ThunderBluffEvent.ZoneId and player:GetMapId() == ThunderBluffEvent.MapId then
    if ThunderBluffEvent.IsRunning then
      -- EVENT RUNNING
      -- Disband player groups.
      if player:IsInGroup() then
        DisbandGroup(player:GetGroup());
      end
    else
      -- EVENT NOT RUNNING
      local curTime = os.time();
      -- Check if another battle can occur yet.
      if ThunderBluffEvent.LastBattleTime == 0 or curTime - ThunderBluffEvent.LastBattleTime >= 600 then -- 10 mins
        local playersInRange = player:GetPlayersInRange(533, 0, 1);
        -- Check all IPs against existing players to make sure we don't have multiboxers...
        for _, v in pairs(playersInRange) do
          if v:GetPlayerIP() ~= player:GetPlayerIP() then
            count = count + 1;
          end
        end

        if (count + 1) >= ThunderBluffEvent.MinPlayersToStart then
          ThunderBluffEvent.IsRunning = true;
          SendWorldMessage("[EVENT] " .. ThunderBluffEvent.Strings[7]);
          ThunderBluffEvent.StopBattleId = CreateLuaEvent(ThunderBluffEvent.StopBattle, ThunderBluffEvent.MaxLength * 60 * 1000, 1);
        end
      end
    end
  end
end

function ThunderBluffEvent.OnPvPKill(event, killer, killed)
  if killer:GetMapId() == ThunderBluffEvent.MapId and killer:GetZoneId() == ThunderBluffEvent.ZoneId and ThunderBluffEvent.IsRunning and killer:GetTypeId() == 4 and killer ~= killed then
    local killerGUID = killer:GetGUIDLow();
    -- Reputation
    if killer:IsAlliance() then
      local repAmnt = killer:GetReputation(FACTION_SENTINELS);
      killer:SetReputation(FACTION_SENTINELS, repAmnt + 5);
    else
      local repAmnt = killer:GetReputation(FACTION_WARSONG);
      killer:SetReputation(FACTION_WARSONG, repAmnt + 5);
    end

    -- Quest credit
    if killer:HasQuest(QUEST_TB) then
      killer:KilledMonsterCredit(CREDIT_QUEST_TB);
    end

    -- Disband groups
    if killer:IsInGroup() then
      DisbandGroup(killer:GetGroup());
    end
    if killed:IsInGroup() then
      DisbandGroup(killed:GetGroup());
    end

    if ThunderBluffEvent.PlayerBattleContribution[killerGUID] == nil then
      ThunderBluffEvent.PlayerBattleContribution[killerGUID] = 1;
    elseif ThunderBluffEvent.PlayerBattleContribution[killerGUID] == (ThunderBluffEvent.MinKillsToWin - 1) then
      -- Winner
      ThunderBluffEvent.PlayerBattleContribution[killerGUID] = 5;
      ThunderBluffEvent.EventWinner = killerGUID;
      HandleReward();
      ThunderBluffEvent.LastBattleTime = os.time();
      ResetBattle();
    else
      ThunderBluffEvent.PlayerBattleContribution[killerGUID] = ThunderBluffEvent.PlayerBattleContribution[killerGUID] + 1;
    end
  end
end

function ThunderBluffEvent.OnCreateGroup(event, group, leaderGuid, groupType)
  local PlayerObject = GetPlayerByGUID(leaderGuid);
  if PlayerObject:GetZoneId() == ThunderBluffEvent.ZoneId and ThunderBluffEvent.IsRunning then
    DisbandGroup(group);
  end
end

function ThunderBluffEvent.StopBattle()
  HandleReward();
  ThunderBluffEvent.LastBattleTime = os.time();
  ResetBattle();
  SendWorldMessage(ThunderBluffEvent.Strings[3]);
end

RegisterPlayerEvent( 6, ThunderBluffEvent.OnPvPKill);
RegisterPlayerEvent(27, ThunderBluffEvent.OnEnterArea);
RegisterGroupEvent(6, ThunderBluffEvent.OnCreateGroup); -- GROUP_EVENT_ON_CREATE
