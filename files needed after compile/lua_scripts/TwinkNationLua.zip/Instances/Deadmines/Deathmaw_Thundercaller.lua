--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Deathmaw Thundercaller - Trash mob for Deadmines' "Mast Room".
 * AUTHOR : sundays
 * UPDATED: 19th Sept 2016
--]]

-- Constants
local ENTRY_THUNDERCALLER   = 90013;
local SPELL_STATIC_CHARGE   =  3742;
local SPELL_STORMSTRIKE     = 17364;
local SPELL_CHAIN_LIGHTNING = 16921;

local Thundercaller = {};

function Thundercaller.Stormstrike(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_STORMSTRIKE, true);
end

function Thundercaller.ChainLightning(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_CHAIN_LIGHTNING, true);
end

-- Main
function Thundercaller.OnEnterCombat(event, creature, target)
  creature:CastSpell(creature, SPELL_STATIC_CHARGE, true);
  creature:RegisterEvent(Thundercaller.Stormstrike, 10000, 0);
  creature:RegisterEvent(Thundercaller.ChainLightning, 5500, 0);
end

function Thundercaller.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Thundercaller.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_THUNDERCALLER, 1, Thundercaller.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_THUNDERCALLER, 2, Thundercaller.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_THUNDERCALLER, 4, Thundercaller.OnDied);        -- CREATURE_EVENT_ON_DIED
