--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Fel Sentry - Deadmines trash mob in "The Foundry".
 * AUTHOR : sundays
 * UPDATED: 18th Sept 2016
--]]

-- Constants
local ENTRY_WARLOCK  = 90004;
local ENTRY_CRYSTAL  = 90020;
local SPELL_IMMOLATE = 11668; -- 200damage, 97 per sec
local SPELL_CURSE    =  5884; -- -19% chance to hit
local SPELL_BOLT     = 17509; -- Used on Lesser Power Crystals

local Warlock = {
  Strings = {
    -- On combat
    "Stupid %s, you think you can stop the master?",
    "Yes, master. The %s will die.",
    "I see a vision. Horrible things happen to you in it, %s.",
    "Yes, my master. I will kill %s.",
    -- Power Crystal
    "Where's that crystal? I need its power!",
    "I can feel my power draining! I need to find a crystal.",
    "Gah! Where's the crystal? I'm feeling dizzy!",
    "Argh! I need the crystal's power! I'm growing feeble!";
  };
};

function Warlock.Immolate(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_IMMOLATE);
end

function Warlock.Curse(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_CURSE, true);
end

function Warlock.CheckHealth(event, delay, repeats, creature)
  local healthPct = creature:GetHealthPct();
  if healthPct <= 50 then
    local crystal = creature:GetNearestCreature(40, ENTRY_CRYSTAL, 0, 1);
    if crystal and creature:IsWithinLoS(crystal) and creature:GetDistance(crystal) <= 40 then
      local randomMessage = math.random(5, 8);
      creature:SendUnitSay(Warlock.Strings[randomMessage], 0);
      creature:CastSpell(crystal, SPELL_BOLT);
    end
    creature:RemoveEventById(event);
  end
end

-- Main
function Warlock.OnEnterCombat(event, creature, target)
  if math.random(1, 100) >= 80 then
    local randomMessage = math.random(1, 4);
    if randomMessage < 4 then
      local targetRaceAsString = target:GetRaceAsString(0);
      if targetRaceAsString then
        creature:SendUnitSay(string.format(Warlock.Strings[randomMessage], targetRaceAsString), 0);
      end
    elseif randomMessage == 4 then
      local pronouns = {"him", "her", "it"}; -- Lua tables start at 1, but GetGender can return 0, so we add one.
      creature:SendUnitSay(string.format(Warlock.Strings[randomMessage], pronouns[target:GetGender() + 1]), 0);
    end
  end
  creature:RegisterEvent(Warlock.Immolate, 6000, 3);
  creature:RegisterEvent(Warlock.Curse, 3500, 1);
  creature:RegisterEvent(Warlock.CheckHealth, 2000, 0);
end

function Warlock.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Warlock.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_WARLOCK, 1, Warlock.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_WARLOCK, 2, Warlock.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_WARLOCK, 4, Warlock.OnDied);        -- CREATURE_EVENT_ON_DIED
