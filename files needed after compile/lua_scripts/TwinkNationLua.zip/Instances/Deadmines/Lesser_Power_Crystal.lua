--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Lesser Power Crystal - Used by Deathmaw Warlocks to replenish health.
 * AUTHOR : sundays
 * UPDATED: 18th Sept 2016
--]]

-- Constants
local ENTRY_CRYSTAL   = 90020;
local ENTRY_WARLOCK   = 90004;
local SPELL_BOLT      = 17509; -- Shadowbolt, for crystal
local SPELL_HEAL      =  5185; -- Dummy spell
local SPELL_EXPLOSION = 12710; -- Visual

local Crystal = {
  Strings = {
    "The crystal shatters. Rays of light emerge from within, healing %s.",
    "The crystal breaks in two. A torrent of magic flows out. %s feels a bit better now.",
    "The crystal smashes. A glimmer comes from within. Magic flows out, healing %s.",
    "Rays of light emanate from the now broken crystal. %s looks just like new now!",
    "%s looks a bit better after having been hit by the magic emerging from the shattered crystal.",
    "An outpouring of magic hits %s, healing %s.",
    "As the crystal shatters in pieces, a beam of magic shoots out towards %s, healing %s.",
    "%s watches as %s wounds heal when the magic released from the crystal touches %s.";
  };
};

-- Main
function Crystal.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Crystal.OnDied(event, creature, killer)
  local maxHealth      = killer:GetMaxHealth();
  local healMultiplier = (math.random(10, 15) / 100);
  local healValue      = maxHealth * healMultiplier;
  local randomMessage  = math.random(1, 8);
  local killerName     = killer:GetName();
  local pronouns       = {"him", "her", "it"};
  if randomMessage <= 5 then
    creature:SendUnitEmote(string.format(Crystal.Strings[randomMessage], killerName), nil, false);
  elseif randomMessage == 6 or randomMessage == 7 then
    local killerGender = killer:GetGender();
    creature:SendUnitEmote(string.format(Crystal.Strings[randomMessage], killerName, pronouns[killerGender + 1]), nil, false);
  else
    local killerGender = killer:GetGender();
    creature:SendUnitEmote(string.format(Crystal.Strings[randomMessage], killerName, pronouns[killerGender + 1], pronouns[killerGender + 1]), nil, false);
  end
  if killer:GetEntry() == ENTRY_WARLOCK then
    killer:DealHeal(killer, SPELL_HEAL, healValue * 2, false);
  else
    killer:DealHeal(killer, SPELL_HEAL, healValue, false);
  end
  creature:RemoveEvents();
end

function Crystal.OnHitBySpell(event, creature, caster, spellid)
  if spellid == SPELL_BOLT and caster:GetEntry() == ENTRY_WARLOCK then
    local DamageAmount = creature:GetMaxHealth();
    caster:DealDamage(creature, DamageAmount);
  end
end

-- RegisterCreatureEvent(ENTRY_CRYSTAL,  1, Crystal.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_CRYSTAL,  2, Crystal.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_CRYSTAL,  4, Crystal.OnDied);        -- CREATURE_EVENT_ON_DIED
RegisterCreatureEvent(ENTRY_CRYSTAL, 14, Crystal.OnHitBySpell);  -- CREATURE_EVENT_ON_HIT_BY_SPELL
