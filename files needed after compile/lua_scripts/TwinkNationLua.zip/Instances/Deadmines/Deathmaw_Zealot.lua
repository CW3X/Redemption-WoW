--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Deathmaw Cultist - Deadmines trash mob.
 * AUTHOR : sundays
 * UPDATED: 17th Sept 2016
--]]

-- Constants
local ENTRY_ZEALOT = 90001;
local SPELL_KICK   =  8646;
local SPELL_CLEAVE = 18819; -- Weapon damage + 30, affects max 3 targets.

local Zealot = {
  Strings = {
  };
};

function Zealot.SnapKick(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if math.random(1, 100) >= 40 then
    creature:CastSpell(Victim, SPELL_KICK);
  end
end

function Zealot.Cleave(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_CLEAVE);
end

-- Main
function Zealot.OnEnterCombat(event, creature)
  creature:RegisterEvent(Zealot.SnapKick, 5000, 2);
  creature:RegisterEvent(Zealot.Cleave, 5500, 0);
end

function Zealot.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Zealot.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_ZEALOT, 1, Zealot.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_ZEALOT, 2, Zealot.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_ZEALOT, 4, Zealot.OnDied);        -- CREATURE_EVENT_ON_DIED
