--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Deathmaw -- Deadmines last boss
 * AUTHOR : sundays
 * UPDATED: 22nd Sept 2016
--]]

local BossTimers = require("../BossTimerMgr");

-- Constants
local ENTRY_DEATHMAW          = 90024;
local ENTRY_WARRIOR           = 90025;
local ENTRY_PALADIN           = 90026;
local ENTRY_HUNTER            = 90027;
local ENTRY_ROGUE             = 90028;
local ENTRY_PRIEST            = 90029;
local ENTRY_SHAMAN            = 90030;
local ENTRY_MAGE              = 90031;
local ENTRY_WARLOCK           = 90032;
local ENTRY_DRUID             = 90033;
local SPELL_SHADOW_VOLLEY     =  9081; -- Shadow Bolt Volley
local SPELL_CORRUPTION        =  7648; -- 324dmg over 18s
local SPELL_SUMMONED_ENRAGE   = 24318; -- 50 attack, 60% speed
local SPELL_QUICKENING        = 23723; -- Gift of Deathmaw Caster positive effect spell
local SPELL_FRENZY            = 28371; -- Gift of Deathmaw Melee positive spell effect
local SPELL_SHADOW_VISUAL     = 15473; -- Visual, cast on class-based adds.
local SPELL_WARR_MORTAL       = 27580; -- Warrior mortal strike 50% reduced heal
local SPELL_WARR_THUNDER      =  8732; -- Warrior thunderclap
local SPELL_PALA_RETRI        = 10301; -- Paladin retribution aura 20 damage
local SPELL_PALA_CONSECRATION = 20924; -- 48 damage per sec (384 dmg)
local SPELL_HUNT_NET          =  6533; -- 10 sec immobilised
local SPELL_HUNT_VOLLEY       = 14295;
local SPELL_ROGUE_CRIPPLING   = 11201; -- 70% slow
local SPELL_ROGUE_DEADLY      = 11469; -- 26 damage per stack, 5 stacks, 12 sec
local SPELL_PRIEST_PAIN       =  2767; -- 61 every 3 (366 dmg)
local SPELL_PRIEST_SHIELD     = 10899; -- 600 damage absorption
local SPELL_SHAMAN_FLAME      = 10447; -- Flame shock (150 + 150 over 12sec)
local SPELL_SHAMAN_CHAIN      = 15305;
local SPELL_MAGE_ARCANE_BLAST =  8439; -- Arcane exposion
local SPELL_MAGE_FROST_NOVA   =  6131;
local SPELL_WARLOCK_IMPOTENCE = 22371; -- -26 magic damage dealt
local SPELL_WARLOCK_BOLT      =  1088; -- shadow bolt
local SPELL_DRUID_MOONFIRE    =  8927;
local SPELL_DRUID_BEAR_FORM   =  9634;
local SPELL_DRUID_BASH        =  8983; -- 3 sec
local SPELL_DRUID_REJUVENATE  =  3627; -- 304 healed

local Deathmaw = {
  Strings = {
    -- Boss emotes
    "Deathmaw sends a minion to %s.",
    "Deathmaw bestows a gift unto %s.",
    -- Announce class summon
    "This is your worst nightmare, %s.",
    "I see your inner fear, %s.",
    "This is your worst nightmare, %s? Pitiful.",
    "These visions don't lie, %s. Your will falters. You will join us.",
    "Stare into the abyss, %s.",
    "Your will falters, %s.",
    "You hesitate at the sight of a mere figment of your imagination, %s?",
    "Your inner hell before your eyes, %s.",
    -- Announce gift of deathmaw
    "Look at the power I could grant you, %s. Can you resist the temptation?",
    "Join me, %s. Together, we shall rule the minds of the feeble.",
    "Watch as I grant you immense power, %s. Imagine how much more I could give you.",
    "This is only the beginning, %s. Power like this could be yours, if only you joined me.",
    "Feel the power, %s. All this, and more, could be yours.",
    "Dominion over the weak. Join me, %s. I shall grant you unimaginable power.",
    -- 30% Health
    "This cannot be! Help me, minions!",
  },
  Classes = {
    -- Class value is index. (ChrClasses.dbc). From SharedDefines.h
    [1]  = ENTRY_WARRIOR,
    [2]  = ENTRY_PALADIN,
    [3]  = ENTRY_HUNTER,
    [4]  = ENTRY_ROGUE,
    [5]  = ENTRY_PRIEST,
    -- [6]  = "CLASS_DEATH_KNIGHT", -- not listed. only in patch >= 3.0
    [7]  = ENTRY_SHAMAN,
    [8]  = ENTRY_MAGE,
    [9]  = ENTRY_WARLOCK,
    -- [10] = "CLASS_UNK2", -- unused
    [11] = ENTRY_DRUID,
  },
};

local function ResetEncounter(creature)
  for _, v in pairs(Deathmaw.Classes) do
    local summonedCreatures = creature:GetCreaturesInRange(533, v, 0, 0);
    for _, val in pairs(summonedCreatures) do
      val:DespawnOrUnsummon();
    end
  end
end

function Deathmaw.CheckHealth(event, delay, repeats, creature)
  local HealthPct = creature:GetHealthPct();
  if HealthPct <= 30 then
    local x1, y1, z1 = creature:GetRelativePoint(math.random(3, 6), (math.random(math.pi / 12, math.pi * 2)));
    -- local x2, y2, z2 = creature:GetRelativePoint(math.random(3, 7), (math.random(math.pi / 12, math.pi * 2)));
    local o       = creature:GetO();
    local id      = creature:GetInstanceId();
    local Victim  = creature:GetVictim();
    local randomSpawn    = math.random(1, 9);
    local PossibleSpawns = {ENTRY_WARRIOR, ENTRY_PALADIN, ENTRY_HUNTER, ENTRY_ROGUE, ENTRY_PRIEST, ENTRY_SHAMAN, ENTRY_MAGE, ENTRY_WARLOCK, ENTRY_DRUID};
    local summonedCreature1 = PerformIngameSpawn(1, PossibleSpawns[randomSpawn], 36, id, x1, y1, z1, o);
    -- local summonedCreature2 = PerformIngameSpawn(1, PossibleSpawns[randomSpawn], 36, id, x2, y2, z2, o);
    summonedCreature1:SetRespawnDelay(696969);
    -- summonedCreature2:SetRespawnDelay(696969);
    summonedCreature1:CastSpell(summonedCreature1, SPELL_SHADOW_VISUAL, true);
    -- summonedCreature2:CastSpell(summonedCreature1, SPELL_SHADOW_VISUAL, true);
    summonedCreature1:CastSpell(summonedCreature1, SPELL_SUMMONED_ENRAGE, true);
    -- summonedCreature2:CastSpell(summonedCreature1, SPELL_SUMMONED_ENRAGE, true);
    summonedCreature1:SetScale(1.5);
    -- summonedCreature2:SetScale(1.5);
    summonedCreature1:AttackStart(Victim);
    -- summonedCreature2:AttackStart(Victim);
    creature:SendUnitSay(Deathmaw.Strings[17], 0);
    creature:RemoveEventById(event);
  end
end

function Deathmaw.ShadowBoltVolley(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_SHADOW_VOLLEY, true);
end

function Deathmaw.Corruption(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0, 50);
  creature:CastSpell(Target, SPELL_CORRUPTION, true);
end

function Deathmaw.Gift(event, delay, repeats, creature)
  local Target        = creature:GetAITarget(0, true, 0, 50); -- Random, playeronly, random, 50yd
  local TargetName    = Target:GetName();
  local TargetClass   = Target:GetClass();
  local RandomMessage = math.random(11, 16);
  if TargetClass == 1 or 
  TargetClass == 2 or
  TargetClass == 3 or
  TargetClass == 4 or
  TargetClass == 11 then
    Target:CastSpell(Target, SPELL_FRENZY, true);
    local FrenzyAura = Target:GetAura(SPELL_FRENZY);
    FrenzyAura:SetDuration(6000);
  elseif TargetClass == 5 or
  TargetClass == 7 or
  TargetClass == 8 or
  TargetClass == 9 then
    Target:CastSpell(Target, SPELL_QUICKENING, true);
    local QuickeningAura = Target:GetAura(SPELL_QUICKENING);
    QuickeningAura:SetDuration(6000);
  end
  creature:SendUnitSay(string.format(Deathmaw.Strings[RandomMessage], TargetName), 0);
  creature:SendUnitEmote(string.format(Deathmaw.Strings[2], TargetName), nil, true);
end

function Deathmaw.SummonAdd(event, delay, repeats, creature)
  local id          = creature:GetInstanceId();
  local RandomText  = math.random(3, 10);
  local Target      = creature:GetAITarget(0, true, 0, 50);
  local TargetName  = Target:GetName();
  local TargetClass = Target:GetClass();
  local TargetO     = Target:GetO();
  local TargetClassStr = Target:GetClassAsString();
  local summonX, summonY, summonZ = Target:GetRelativePoint(math.random(2, 5), math.random(math.pi / 12, math.pi * 2));
  local summonedCreature = PerformIngameSpawn(1, Deathmaw.Classes[TargetClass], 36, id, summonX, summonY, summonZ, TargetO);
  summonedCreature:SetRespawnDelay(696969);
  summonedCreature:CastSpell(summonedCreature, SPELL_SHADOW_VISUAL, true);
  summonedCreature:AttackStart(Target);
  -- Boss emote
  creature:SendUnitEmote(string.format(Deathmaw.Strings[1], TargetName), nil, true);
  creature:SendUnitSay(string.format(Deathmaw.Strings[RandomText], TargetClassStr), 0);
end

-- Main
function Deathmaw.OnEnterCombat(event, creature, target)
  local InstanceId = creature:GetInstanceId();
  creature:RegisterEvent(Deathmaw.Gift, 15000, 0);
  creature:RegisterEvent(Deathmaw.SummonAdd, 25000, 0);
  creature:RegisterEvent(Deathmaw.Corruption, 12000, 0);
  creature:RegisterEvent(Deathmaw.ShadowBoltVolley, 5000, 0);
  creature:RegisterEvent(Deathmaw.CheckHealth, 2000, 0);
  BossTimers.BossStarted(InstanceId, creature:GetName(), target:GetGroup(), os.time(), creature:GetGUIDLow());
end

function Deathmaw.OnLeaveCombat(event, creature)
  local InstanceId = creature:GetInstanceId();
  ResetEncounter(creature);
  BossTimers.DeleteTimer(InstanceId, creature:GetGUIDLow());
  creature:RemoveEvents();
end

function Deathmaw.OnDied(event, creature, killer)
  local InstanceId = creature:GetInstanceId();
  BossTimers.BossEnded(InstanceId, creature:GetMapId(), creature:GetName(), killer:GetGroup(), os.time(), creature:GetGUIDLow());
  creature:RemoveEvents();
end


RegisterCreatureEvent(ENTRY_DEATHMAW, 1, Deathmaw.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_DEATHMAW, 2, Deathmaw.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_DEATHMAW, 4, Deathmaw.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Doomed Warrior
local Doomed_Warrior = {
  Strings = {
    "I'll tear them apart!",
    "Weak fools!",
    "Do you fear me yet, fools?",
    "I'll shred the meat off your bones.",
    "We shall drink from your skull, heathen.",
    "Don't resist the master's will!",
  };
};

-- Abilities
function Doomed_Warrior.Mortal(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_WARR_MORTAL, true);
end

function Doomed_Warrior.Thunderclap(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_WARR_THUNDER, true);
end

-- Main
function Doomed_Warrior.OnEnterCombat(event, creature, target)
  local RandomInterval = math.random(6000, 12000);
  local RandomMessage  = math.random(1, #Doomed_Warrior.Strings);
  creature:SendUnitSay(Doomed_Warrior.Strings[RandomMessage], 0);
  creature:RegisterEvent(Doomed_Warrior.Mortal, RandomInterval, 0);
  creature:RegisterEvent(Doomed_Warrior.Thunderclap, 5000, 2);
end

function Doomed_Warrior.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Doomed_Warrior.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon(1000);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_WARRIOR, 1, Doomed_Warrior.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_WARRIOR, 2, Doomed_Warrior.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_WARRIOR, 4, Doomed_Warrior.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Doomed Paladin
local Doomed_Paladin = {
  Strings = {
    "The light won't save you now!",
    "I see only darkness before me.",
    "My will won't falter. I've already succumbed to the master.",
    "The light abandoned us.",
    "The light failed us all. The abyss stares back.",
    "Doubt yourself, young Paladin. Free yourself from these bounds.",
  };
};

-- Abilities
function Doomed_Paladin.Consecration(event, delay, repeats, creature)
  if (repeats % 5) == 2 then
    creature:CastSpell(creature, SPELL_PALA_CONSECRATION, true);
  end
end

-- Main
function Doomed_Paladin.OnEnterCombat(event, creature, target)
  local RandomMessage = math.random(1, #Doomed_Paladin.Strings);
  creature:SendUnitSay(Doomed_Paladin.Strings[RandomMessage], 0);
  creature:CastSpell(creature, SPELL_PALA_RETRI, true);
  creature:RegisterEvent(Doomed_Paladin.Consecration, 2000, 7);
end

function Doomed_Paladin.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Doomed_Paladin.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon(1000);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_PALADIN, 1, Doomed_Paladin.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_PALADIN, 2, Doomed_Paladin.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_PALADIN, 4, Doomed_Paladin.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Doomed Hunter
local Doomed_Hunter = {
  Strings = {
    "Nobody can save you, Hunter.",
    "We all have a price.",
    "We all wither away eventually.",
    "The power is intoxicating.",
    "Your heads will adorn my walls.",
    "I'll make trophies out of you all.",
  };
};

-- Abilities
function Doomed_Hunter.Net(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0, 20);
  creature:CastSpell(Target, SPELL_HUNT_NET, true);
end

function Doomed_Hunter.Volley(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0, 30);
  local Tx, Ty, Tz = Target:GetLocation();
  creature:CastSpellAoF(Tx, Ty, Tz, SPELL_HUNT_VOLLEY, true);
end

-- Main
function Doomed_Hunter.OnEnterCombat(event, creature, target)
  local RandomMessage = math.random(1, #Doomed_Hunter.Strings);
  creature:SendUnitSay(Doomed_Hunter.Strings[RandomMessage], 0);
  creature:RegisterEvent(Doomed_Hunter.Net, 5000, 3);
  creature:RegisterEvent(Doomed_Hunter.Volley, 12000, 0);
  creature:CastSpell(target, SPELL_HUNT_VOLLEY, true);
end

function Doomed_Hunter.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Doomed_Hunter.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon(1000);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_HUNTER, 1, Doomed_Hunter.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_HUNTER, 2, Doomed_Hunter.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_HUNTER, 4, Doomed_Hunter.OnDied);        -- CREATURE_EVENT_ON_DIED


-- Doomed Rogue
local Doomed_Rogue = {
  Strings = {
    "Let's play a little game.",
    "One wrong move, and there's a slit in your throat.",
    "What comes around, goes around, Rogue.",
    "Silly little rats.",
    "Stare into the abyss. Let it envelop you.",
  };
};

-- Abilities
function Doomed_Rogue.Crippling(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_ROGUE_CRIPPLING, false);
end

function Doomed_Rogue.Deadly(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_ROGUE_DEADLY, false);
end

-- Main
function Doomed_Rogue.OnEnterCombat(event, creature, target)
  local RandomInterval = math.random(7500, 11000);
  local RandomMessage  = math.random(1, #Doomed_Rogue.Strings);
  creature:SendUnitSay(Doomed_Rogue.Strings[RandomMessage], 0);
  creature:RegisterEvent(Doomed_Rogue.Deadly, 3000, 0);
  creature:RegisterEvent(Doomed_Rogue.Crippling, RandomInterval, 2);
end

function Doomed_Rogue.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Doomed_Rogue.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon(1000);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_ROGUE, 1, Doomed_Rogue.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_ROGUE, 2, Doomed_Rogue.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_ROGUE, 4, Doomed_Rogue.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Doomed Priest
local Doomed_Priest = {
  Strings = {
    "The light faded a long time ago.",
    "There's nobody to save you here.",
    "The light can't mend your broken will.",
    "What are you waiting for? Join us.",
    "Stare into the abyss, Priest.",
    "Darkness encompasses the light, Priest.",
  };
};

-- Abilities
function Doomed_Priest.Shield(event, delay, repeats, creature)
  local creaturesInRange = creature:GetCreaturesInRange(25, 0, 0, 1);
  local EligibleTargets  = {};
  for _, v in pairs(creaturesInRange) do
    if v:GetEntry() == ENTRY_WARRIOR or
    v:GetEntry() == ENTRY_PALADIN or
    v:GetEntry() == ENTRY_WARLOCK or
    v:GetEntry() == ENTRY_HUNTER or
    v:GetEntry() == ENTRY_SHAMAN or
    v:GetEntry() == ENTRY_ROGUE or
    v:GetEntry() == ENTRY_MAGE or
    v:GetEntry() == ENTRY_DRUID then
      table.insert(EligibleTargets, v);
    end
  end
  for _, v in pairs(EligibleTargets) do
    if v:IsAlive() and creature:IsWithinLoS(v) then
      creature:CastSpell(v, SPELL_PRIEST_SHIELD, true);
      return;
    end
  end
  creature:CastSpell(creature, SPELL_PRIEST_SHIELD); -- Only happens if no eligble targets are found.
end

function Doomed_Priest.Pain(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_PRIEST_PAIN);
end

-- Main
function Doomed_Priest.OnEnterCombat(event, creature, target)
  local RandomInterval = math.random(9500, 11000);
  local RandomMessage  = math.random(1, #Doomed_Priest.Strings);
  creature:SendUnitSay(Doomed_Priest.Strings[RandomMessage], 0);
  creature:RegisterEvent(Doomed_Priest.Pain, 9000, 5);
  creature:RegisterEvent(Doomed_Priest.Shield, RandomInterval, 0);
  creature:CastSpell(creature, SPELL_PRIEST_SHIELD);
end

function Doomed_Priest.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Doomed_Priest.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon(1000);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_PRIEST, 1, Doomed_Priest.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_PRIEST, 2, Doomed_Priest.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_PRIEST, 4, Doomed_Priest.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Doomed Shaman
local Doomed_Shaman = {
  Strings = {
    "The ancestors have stopped talking, Shaman. Deathmaw takes over us now.",
    "The Ancestors' Call has long been gone, Shaman. It's a figment of your weak imagination.",
    "Stop playing with those wooden toys, Shaman. We can give you incredible power.",
    "What a fool you've been. The elements are nothing in comparison to Deathmaw's power.",
    "The elements? Darkness is ubiquitous. Stop worshipping those fake idols.",
    "Pitiful. Join us and unlock your true potential.",
  };
};

-- Abilities
function Doomed_Shaman.Chain(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_SHAMAN_CHAIN);
end

function Doomed_Shaman.Flameshock(event, delay, repeats, creature)
  local Victim = creature:GetAITarget(0, true, 0, 25);
  if Victim then
    creature:CastSpell(Victim, SPELL_SHAMAN_FLAME, true);
  end
end

-- Main
function Doomed_Shaman.OnEnterCombat(event, creature, target)
  local RandomMessage = math.random(1, #Doomed_Shaman.Strings);
  creature:SendUnitSay(Doomed_Shaman.Strings[RandomMessage], 0);
  creature:RegisterEvent(Doomed_Shaman.Chain, 4000, 0);
  creature:RegisterEvent(Doomed_Shaman.Flameshock, 7000, 0);
end

function Doomed_Shaman.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Doomed_Shaman.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon(1000);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_SHAMAN, 1, Doomed_Shaman.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_SHAMAN, 2, Doomed_Shaman.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_SHAMAN, 4, Doomed_Shaman.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Doomed Mage
local Doomed_Mage = {
  Strings = {
    "Dabbling in the arcane arts, Mage? Let me show you what REAL magic looks like.",
    "Still playing with fireballs, Mage? Cute.",
    "And now, for a display of REAL magic.",
    "Stare into the abyss. Join us, and you'll be granted more power than you could possibly wish for.",
    "Submissive heathens. Surrender your minds to Deathmaw!",
    "How silly. Think your magic can stand up to mine?",
  };
};

function Doomed_Mage.SwitchTarget(event, delay, repetas, creature)
  local playersInRange = creature:GetPlayersInRange(10, 1, 1);
  if #playersInRange > 1 then
    local RandomNewTarget = math.random(1, #playersInRange);
    creature:Attack(playersInRange[RandomNewTarget]);
  end
end

-- Abilities
function Doomed_Mage.ArcaneExplosion(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_MAGE_ARCANE_BLAST, false);
end

function Doomed_Mage.FrostNova(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_MAGE_FROST_NOVA, false);
end

-- Main
function Doomed_Mage.OnEnterCombat(event, creature, target)
  local RandomMessage = math.random(1, #Doomed_Mage.Strings);
  creature:SendUnitSay(Doomed_Mage.Strings[RandomMessage], 0);
  creature:RegisterEvent(Doomed_Mage.ArcaneExplosion, 3500, 0);
  creature:RegisterEvent(Doomed_Mage.FrostNova, 7000, 2);
  creature:RegisterEvent(Doomed_Mage.SwitchTarget, 5000, 0);
end

function Doomed_Mage.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Doomed_Mage.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon(1000);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_MAGE, 1, Doomed_Mage.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_MAGE, 2, Doomed_Mage.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_MAGE, 4, Doomed_Mage.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Doomed Warlock
local Doomed_Warlock = {
  Strings = {
    "Surrender your mind to Deathmaw.",
    "Stare into the mouth of the abyss. This world will end.",
    "This world will end. There's no escape.",
    "Surrender now, and reap the rewards.",
    "We all have our price, Warlock. Surrender control, and we'll find yours.",
    "Still summoning measly creatures, Warlock? We could give you control over the most powerful demons in Azeroth.",
  };
};

-- Abilities
function Doomed_Warlock.Curse(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0, 25);
  if Target then
    creature:CastSpell(Target, SPELL_WARLOCK_IMPOTENCE, true);
  end
end

function Doomed_Warlock.ShadowBolt(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_WARLOCK_BOLT);
end

-- Main
function Doomed_Warlock.OnEnterCombat(event, creature, target)
  local RandomMessage = math.random(1, #Doomed_Warlock.Strings);
  creature:SendUnitSay(Doomed_Warlock.Strings[RandomMessage], 0);
  creature:RegisterEvent(Doomed_Warlock.Curse, 2500, 2);
  creature:RegisterEvent(Doomed_Warlock.ShadowBolt, 4500, 0);
end

function Doomed_Warlock.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Doomed_Warlock.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon(1000);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_WARLOCK, 1, Doomed_Warlock.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_WARLOCK, 2, Doomed_Warlock.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_WARLOCK, 4, Doomed_Warlock.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Doomed Druid
local Doomed_Druid = {
  Strings = {
    "We're all at fault for this, Druid.",
    "We brought destruction to the peaceful world of Azeroth, Druid.",
    "If peace is your objective, Druid, then surrender all hope.",
    "Abandon hope. Certain things can't be changed.",
    "The World Tree will fall, and then so will Azeroth.",
    "The blame for the corruption of our world will fall on you.",
    "It's too late to save the world. Join us and be a survivor.",
    "Nature can adapt, and so must you -- join us, Druid.",
  };
};

-- Abilities
function Doomed_Druid.Rejuvenation(event, delay, repeats, creature)
  local creaturesInRange = creature:GetCreaturesInRange(30, 0, 0, 1);
  local EligibleTargets  = {};
  for _, v in pairs(creaturesInRange) do
    if v:GetEntry() == ENTRY_WARRIOR or
    v:GetEntry() == ENTRY_PALADIN or
    v:GetEntry() == ENTRY_WARLOCK or
    v:GetEntry() == ENTRY_HUNTER or
    v:GetEntry() == ENTRY_SHAMAN or
    v:GetEntry() == ENTRY_PRIEST or
    v:GetEntry() == ENTRY_ROGUE or
    v:GetEntry() == ENTRY_MAGE then
      table.insert(EligibleTargets, v);
    end
  end
  for _, v in pairs(EligibleTargets) do
    if v:IsAlive() and creature:IsWithinLoS(v) then
      creature:CastSpell(v, SPELL_DRUID_REJUVENATE, true);
      return;
    end
  end
  creature:CastSpell(creature, SPELL_DRUID_REJUVENATE); -- Only happens if no eligble targets are found.
end

function Doomed_Druid.Bash(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_DRUID_BASH, true);
end

function Doomed_Druid.Moonfire(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0, 30);
  if Target then
    creature:CastSpell(Target, SPELL_DRUID_MOONFIRE, true);
  end
end

function Doomed_Druid.Shapeshift(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(creature, SPELL_DRUID_BEAR_FORM, true);
  creature:CastSpell(creature, SPELL_DRUID_REJUVENATE, true);
  creature:RegisterEvent(Doomed_Druid.Bash, 7000, 5);
  creature:CastSpell(Victim, SPELL_DRUID_BASH, true);
end

-- Main
function Doomed_Druid.OnEnterCombat(event, creature, target)
  local RandomMessage = math.random(1, #Doomed_Druid.Strings);
  creature:SendUnitSay(Doomed_Druid.Strings[RandomMessage], 0);
  creature:RegisterEvent(Doomed_Druid.Moonfire, 3500, 0);
  creature:RegisterEvent(Doomed_Druid.Shapeshift, 5000, 1);
  creature:RegisterEvent(Doomed_Druid.Rejuvenation, 10000, 0);
end

function Doomed_Druid.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Doomed_Druid.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon(1000);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_DRUID, 1, Doomed_Druid.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_DRUID, 2, Doomed_Druid.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_DRUID, 4, Doomed_Druid.OnDied);        -- CREATURE_EVENT_ON_DIED
