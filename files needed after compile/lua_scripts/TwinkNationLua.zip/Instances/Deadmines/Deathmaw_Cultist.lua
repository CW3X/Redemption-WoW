--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Deathmaw Cultist - Deadmines trash mob.
 * AUTHOR : sundays
 * UPDATED: 17th Sept 2016
--]]

-- Constants
local ENTRY_CULTIST     = 90000;
local SPELL_SHADOW_BOLT = 13480;
local SPELL_POISON      =  7992;

local Cultist = {
  Strings = {
    "You'll make a nice sacrifice, %s.",
    "Stupid %s, you think you can stop us?",
    "I can't wait to see you bleed.",
    "Stare into the abyss! Surrender control!",
    "I do the master's bidding.",
    "Your wish is my command, master. I'll make them suffer.",
    "My death is insignificant, %s. You too will soon wither away and die.", -- OnDied
    "Master, have I failed you?"; -- OnDied
  };
};

function Cultist.Shadowbolt(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  -- 85%, 76%, 67%, 64%, 61% chance to use spell.
  if math.random(1, math.ceil((100 / repeats))) >= math.ceil((40 / repeats) - repeats) then
    creature:CastSpell(Victim, SPELL_SHADOW_BOLT);
  end
end

function Cultist.Poison(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if not Victim:GetAura(7992) then
    creature:CastSpell(Victim, SPELL_POISON, true);
  end
end

-- Main bindings
function Cultist.OnEnterCombat(event, creature, target)
  if math.random(1, 100) >= 65 then
    local randomMessage = math.random(1, #Cultist.Strings - 2); -- Don't include death messages.
    if randomMessage == 1 or randomMessage == 2 then
      local targetRace = target:GetRaceAsString(0); -- enUS
      creature:SendUnitSay(string.format(Cultist.Strings[randomMessage], targetRace), 0);
    else
      creature:SendUnitSay(Cultist.Strings[randomMessage], 0);
    end
  end
  
  creature:RegisterEvent(Cultist.Shadowbolt, 3000, 5);
  creature:RegisterEvent(Cultist.Poison, 1000, 1);
end

function Cultist.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Cultist.OnDied(event, creature, killer)
  if math.random(1, 100) >= 90 then
    local randomMessage = math.random(1, 2);
    if randomMessage == 1 then
      local killerRace = killer:GetRaceAsString(0);
      if killerRace then
        creature:SendUnitSay(string.format(Cultist.Strings[7], killerRace), 0);
      end
    else
      creature:SendUnitSay(Cultist.Strings[8], 0);
    end
  end
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_CULTIST, 1, Cultist.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_CULTIST, 2, Cultist.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_CULTIST, 4, Cultist.OnDied);        -- CREATURE_EVENT_ON_DIED
