--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Deathmaw Enforcer - Deadmines trash mob.
 * AUTHOR : sundays
 * UPDATED: 17th Sept 2016
--]]

-- Constants
local ENTRY_ENFORCER    = 90002;
local SPELL_DISARM      =  6713;
local SPELL_SHIELD_SLAM = 23922;

local Enforcer = {
};

function Enforcer.Disarm(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if math.random(1, 100) >= 75 then
    creature:CastSpell(Victim, SPELL_DISARM);
  end
  creature:RemoveEventById(event);
end

function Enforcer.ShieldSlam(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if math.random(1, 100) >= 65 then
    creature:CastSpell(Victim, SPELL_SHIELD_SLAM);
  end
end

-- Main
function Enforcer.OnEnterCombat(event, creature)
  creature:RegisterEvent(Enforcer.Disarm, 5000, 1);
  creature:RegisterEvent(Enforcer.ShieldSlam, 4500, 0);
end

function Enforcer.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Enforcer.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_ENFORCER, 1, Enforcer.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_ENFORCER, 2, Enforcer.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_ENFORCER, 4, Enforcer.OnDied);        -- CREATURE_EVENT_ON_DIED
