--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Dripping Ooze - Trash mob (Deadmines)
 * AUTHOR : sundays
 * UPDATED: 22nd Sept 2016
--]]

-- Constants
local ENTRY_OOZE = 90017;
local SPELL_ACID = 19463; -- -10% armour

local Ooze = {
  Strings = {
    "Acid splashes %s. %s %s loses %d durability.",
    "Acid hits %s. %s %s loses %d durability.",
    "A splash of acid hits %s. %s %s loses %d durability.",
  },
  -- List of item positions eligible for durability loss.
  PossibleItems = {
    0, 1, 2, 3, 4, 6, 7, 8, 9, 15, 16, 17;
  };
};

local function EmoteDurabilityLoss(creature, killer, itemName, durabilityLoss)
  local KillerName   = killer:GetName();
  local KillerGender = killer:GetGender();
  local Pronouns     = {"His", "Her", "Its"};
  local RandomText   = math.random(1, 3);
  creature:SendUnitEmote(string.format(Ooze.Strings[RandomText], KillerName, Pronouns[KillerGender + 1], itemName, durabilityLoss), nil, false);
end

function Ooze.Acid(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_ACID);
end

-- Main
function Ooze.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Ooze.Acid, 7000, 0);
end

function Ooze.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Ooze.OnDied(event, creature, killer)
  if killer:GetTypeId() == 4 then -- 4 = TYPEID_PLAYER
    if math.random(1, 100) >= 70 then
      local RandomItemPos = math.random(1, #Ooze.PossibleItems);
      local RandomItem    = killer:GetItemByPos(255, RandomItemPos);
      local RandomDurLoss = math.random(1, 3);
      if RandomItem then
        local ItemName = RandomItem:GetName();
        killer:DurabilityPointsLoss(RandomItem, RandomDurLoss);
        EmoteDurabilityLoss(creature, killer, ItemName, RandomDurLoss);
      else
        -- Try their weapon
        local killerWeapon = killer:GetItemByPos(255, 15);
        if killerWeapon then
          local ItemName = killerWeapon:GetName();
          killer:DurabilityPointsLoss(killerWeapon, RandomDurLoss);
          EmoteDurabilityLoss(creature, killer, ItemName, RandomDurLoss);
        else
          return;
        end
      end
    end
  end
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_OOZE, 1, Ooze.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_OOZE, 2, Ooze.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_OOZE, 4, Ooze.OnDied);        -- CREATURE_EVENT_ON_DIED
