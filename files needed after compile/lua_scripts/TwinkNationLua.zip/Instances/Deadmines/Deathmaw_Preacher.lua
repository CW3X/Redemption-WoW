--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Deathmaw Preacher - Trash mob (Deadmines)
 * AUTHOR : sundays
 * UPDATED: 24th Sept 2016
--]]

-- Constants
local ENTRY_PREACHER    = 90005;
local ENTRY_CULTIST     = 90000;
local ENTRY_ZEALOT      = 90001;
local ENTRY_ENFORCER    = 90002;
local ENTRY_BRAINWASHED = 90003; -- brainwashed cultist
local ENTRY_WARLOCK     = 90003;
local ENTRY_HELLFIEND   = 90006;
local ENTRY_WHELP       = 90010; -- fel-corrupted whelp
local ENTRY_CRACKLING   = 90012; -- crackling elemental
local ENTRY_THUNDERCALL = 90013; -- deathmaw thundercaller
local SPELL_LESSER_HEAL =  2052;
local SPELL_HOLY_NOVA   = 15430;

local Preacher = {
  Strings = {
    "Surrender control!",
    "Fall to your knees and worship!",
    "The end is nigh!",
    "Deathmaw consumes all!",
    "The feeble-minded will be overcome.",
    "Fools. You will soon serve Deathmaw. Your minds are weak.",
  },
  -- Friends to heal.
  PossibleTargets = {
    ENTRY_CULTIST,  ENTRY_ZEALOT,
    ENTRY_ENFORCER, ENTRY_BRAINWASHED,
    ENTRY_WARLOCK,  ENTRY_HELLFIEND,
    ENTRY_WHELP,    ENTRY_CRACKLING,
    ENTRY_PREACHER, ENTRY_THUNDERCALL;
  };
};

function Preacher.HolyNova(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_HOLY_NOVA);
end

function Preacher.LesserHeal(event, delay, repeats, creature)
  local creaturesInRange = creature:GetCreaturesInRange(35, 0, 0, 1);
  for _, v in pairs(creaturesInRange) do
    for _, vID in pairs(Preacher.PossibleTargets) do
      if v:GetEntry() == vID and v:IsInCombat() and v:GetHealthPct() <= 90 then
        creature:CastSpell(v, SPELL_LESSER_HEAL);
      end
    end
  end
end

-- Main
function Preacher.OnEnterCombat(event, creature, target)
  local randomText = math.random(1, 6);
  if math.random(1, 100) >= 75 then
    creature:SendUnitSay(Preacher.Strings[randomText], 0);
  end
  creature:RegisterEvent(Preacher.LesserHeal, 2500, 0);
  creature:RegisterEvent(Preacher.HolyNova,   8000, 0);
end

function Preacher.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Preacher.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_PREACHER, 1, Preacher.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_PREACHER, 2, Preacher.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_PREACHER, 4, Preacher.OnDied);        -- CREATURE_EVENT_ON_DIED
