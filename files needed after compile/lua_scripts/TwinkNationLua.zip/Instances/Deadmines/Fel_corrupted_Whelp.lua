--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Fel-corrupted Whelp - Trash mob (Deadmines)
 * AUTHOR : sundays
 * UPDATED: 24th Sept 2016
--]]

-- Constants
local ENTRY_WHELP     = 90010;
local SPELL_CLAW      =  3009;
local SPELL_WITHER    =  5337; -- Wither Strike (-50% attack speed)
local SPELL_HAMSTRING =  9080; -- 70% movement speed

local Whelp = {};

function Whelp.Claw(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_CLAW);
end

function Whelp.WitherStrike(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_WITHER);
end

function Whelp.Hamstring(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_HAMSTRING);
end

-- Main
function Whelp.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Whelp.Claw, 6000, 0);
  creature:RegisterEvent(Whelp.WitherStrike, 8000, 1);
  if math.random(1, 100) >= 70 then
    creature:RegisterEvent(Whelp.Hamstring, 7000, 1);
  end
end

function Whelp.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Whelp.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_WHELP, 1, Whelp.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_WHELP, 2, Whelp.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_WHELP, 4, Whelp.OnDied);        -- CREATURE_EVENT_ON_DIED
