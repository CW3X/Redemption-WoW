--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Xodhal the Eradicator - Deadmines boss #1
 * AUTHOR : sundays
 * UPDATED: 16th Sept 2016
--]]

local BossTimers = require("../BossTimerMgr");

-- Constants
local ENTRY_XODHAL       = 90007;
local ENTRY_SERVANT      = 90008;
local ENTRY_FACTORY_DOOR = 13965;
local SPELL_CHARGE       = 26561;
local SPELL_ENRAGE       =  8599; -- 30% attack speed, 18 dmg, 2min
local SPELL_WEAKNESS     = 11980; -- -9 physical damage
local SPELL_KNOCKBACK    = 10101;
local SPELL_MAGIC_SHIELD = 24021; -- Magic immunity, 8 sec
local SCALE_DEFAULT      =   1.5;

-- Xodhal the Eradicator
local Xodhal = {
  Strings = {
    "The culling of the weak begins with you. You will all beg for precious death when I'll be flaying you alive!", -- Combat
    "Those whose minds have been cleansed will be spared. Feast your eyes on the master's creation!",               -- Phase 1
    "Xodhal swells with demonic fury and releases a terrifying roar.";                                              -- Phase 2, emote
  },
  Spawns = {
    [1] = {-194.87, -451.16, 54.46, 1.59},
    [2] = {-189.34, -450.36, 54.55, 1.78};
  };
};

local function UnlockDoor(creature)
  local FactoryDoor = creature:GetNearestGameObject(533, ENTRY_FACTORY_DOOR, 0);
  if FactoryDoor then
    FactoryDoor:SetGoState(0);
  end
end

local function UnsummonServants(creature)
  local servants = creature:GetCreaturesInRange(533, ENTRY_SERVANT, 0, 0);
  local next     = next;
  if next(servants) then
    for _, v in pairs(servants) do
      v:DespawnOrUnsummon();
    end
  end
end

function Xodhal.ShieldEvent(event, delay, repeats, creature)
  local next = next; -- Apparently more efficient.
  local creaturesInRange = creature:GetCreaturesInRange(533, ENTRY_SERVANT, 2, 1);
  if next(creaturesInRange) then
    creature:CastSpell(creature, SPELL_MAGIC_SHIELD);
  else
    creature:RemoveEventById(event); -- Remove ShieldEvent hook.
  end
end

function Xodhal.EnrageCheck(event, delay, repeats, creature)
  local health = creature:GetHealthPct();
  if health <= 35 then
    local id = creature:GetInstanceId();
    creature:SetScale(1.75);
    creature:SendUnitEmote(Xodhal.Strings[3], nil, true);
    creature:CastSpell(creature, SPELL_ENRAGE);
    creature:RemoveEventById(event);   -- Remove EnrageCheck hook.
  end
end

function Xodhal.SummonCheck(event, delay, repeats, creature)
  local health = creature:GetHealthPct();
  if health <= 50 then
    local id = creature:GetInstanceId();
    creature:SendUnitYell(Xodhal.Strings[2], 0);
    local servant1 = PerformIngameSpawn(1, ENTRY_SERVANT, 36, id, Xodhal.Spawns[1][1], Xodhal.Spawns[1][2], Xodhal.Spawns[1][3], Xodhal.Spawns[1][4], false, 0, 1);
    local servant2 = PerformIngameSpawn(1, ENTRY_SERVANT, 36, id, Xodhal.Spawns[2][1], Xodhal.Spawns[2][2], Xodhal.Spawns[2][3], Xodhal.Spawns[2][4], false, 0, 1);
    servant1:SetRespawnDelay(696969); -- fuck mangos
    servant2:SetRespawnDelay(696969); -- fuck mangos
    creature:CastSpell(creature, SPELL_MAGIC_SHIELD);
    creature:RegisterEvent(Xodhal.ShieldEvent, 5000, 0);
    creature:RemoveEventById(event);   -- Remove SummonCheck hook
  end
end

function Xodhal.Knockback(event, delay, repeats, creature)
  if math.random(1, 100) >= 60 then
    local Victim = creature:GetVictim();
    creature:CastSpell(Victim, SPELL_KNOCKBACK);
  end
end

function Xodhal.Charge(event, delay, repeats, creature)
  local players = creature:GetPlayersInRange(30, 1, 1); -- 25yd, hostile, alive
  if #players > 1 then
    local randomTarget = math.random(1, #players);
    if players[randomTarget] == creature:GetVictim() then
      if randomTarget > 1 then
        creature:CastSpell(players[randomTarget - 1], SPELL_CHARGE, true);
      else
        creature:CastSpell(players[randomTarget + 1], SPELL_CHARGE, true);
      end
    else
      creature:CastSpell(players[randomTarget], SPELL_CHARGE, true);
    end
  end
end

-- Main events
function Xodhal.OnEnterCombat(event, creature, target)
  local InstanceId = creature:GetInstanceId();
  creature:SendUnitYell(Xodhal.Strings[1], 0);
  creature:RegisterEvent(Xodhal.Knockback,   4500, 0);
  creature:RegisterEvent(Xodhal.Charge,      7000, 0);
  creature:RegisterEvent(Xodhal.EnrageCheck, 2500, 0);
  creature:RegisterEvent(Xodhal.SummonCheck, 2500, 0);
  BossTimers.BossStarted(InstanceId, creature:GetName(), target:GetGroup(), os.time(), creature:GetGUIDLow());
end

function Xodhal.OnLeaveCombat(event, creature)
  local InstanceId = creature:GetInstanceId();
  BossTimers.DeleteTimer(InstanceId, creature:GetGUIDLow());
  creature:SetScale(SCALE_DEFAULT);
  UnsummonServants(creature);
  creature:RemoveEvents();
end

function Xodhal.OnDied(event, creature, killer)
  -- Update instance data.
  local InstanceId  = creature:GetInstanceId();
  BossTimers.BossEnded(InstanceId, creature:GetMapId(), creature:GetName(), killer:GetGroup(), os.time(), creature:GetGUIDLow());
  creature:SetScale(SCALE_DEFAULT);
  UnsummonServants(creature);
  UnlockDoor(creature);
  creature:RemoveEvents();
end

function Xodhal.OnReset(event, creature)
  creature:SetScale(SCALE_DEFAULT);
  UnsummonServants(creature);
  creature:RemoveEvents();
end

-- Server events
RegisterCreatureEvent(ENTRY_XODHAL,  1, Xodhal.OnEnterCombat) -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_XODHAL,  2, Xodhal.OnLeaveCombat) -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_XODHAL,  4, Xodhal.OnDied);
RegisterCreatureEvent(ENTRY_XODHAL, 23, Xodhal.OnReset);      -- CREATURE_EVENT_ON_RESET

-- Servant of Xodhal
local Servant = {
  Strings = {
    "Xodhal give me strength!",
    "Submissive dogs! We shall inherit Azeroth!",
    "Fall to your knees and beg for mercy! Stare into the maw of the abyss.",
    "Surrender your control like we have -- give in to the master's will!",
    "I feel the power coursing through my veins!";
  };
};

function Servant.OnEnterCombat(event, creature, target)
  if math.random(1, 100) >= 55 then
    creature:SendUnitSay(Servant.Strings[math.random(1, #Servant.Strings)], 0);
  end
end

function Servant.OnDied(event, creature, killer)
  local servants = creature:GetCreaturesInRange(533, ENTRY_SERVANT, 0, 1); -- alive
  local next     = next;
  if not next(servants) then
    local boss = creature:GetNearestCreature(533, ENTRY_XODHAL, 0, 1);
    if boss then
      boss:RemoveAura(SPELL_MAGIC_SHIELD);
    end
  end
  creature:DespawnOrUnsummon(2500);
  creature:RemoveEvents();
end

function Servant.OnSpawn(event, creature)
  local nearestPlayer = creature:GetNearestPlayer(533, 1, 1);
  if nearestPlayer then
    creature:Attack(nearestPlayer);
  end
end

RegisterCreatureEvent(ENTRY_SERVANT, 1, Servant.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_SERVANT, 4, Servant.OnDied);        -- CREATURE_EVENT_ON_DIED
RegisterCreatureEvent(ENTRY_SERVANT, 5, Servant.OnSpawn);       -- CREATURE_EVENT_ON_SPAWN
