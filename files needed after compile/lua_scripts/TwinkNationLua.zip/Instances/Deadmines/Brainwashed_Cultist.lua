--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Brainwashed Cultist - Deadmines trash mob.
 * AUTHOR : sundays
 * UPDATED: 17th Sept 2016
--]]

-- Constants
local ENTRY_BRAINWASHED_CULTIST = 90003;
local SPELL_FRENZY              = 19812;
local SPELL_FEAR                = 12096;

local Cultist = {
  Strings = {
    -- Frenzy
    "I can hear the voices! They won't stop!",
    "You will never separate me from the master!",
    "I do the master's bidding.",
    "The master's will is my command.",
    "The voices urge me!",
    "The screams of anguish are music to my ears.",
    -- Fear
    "Brainwashed Cultist screams in terror.",
    "Brainwashed Cultist runs in fear.",
    "Brainwashed Cultist lets out a blood-curdling scream and flees.",
    "Brainwashed Cultist lets out a horrendous scream and runs.",
    "Brainwashed Cultist flees in terror.";
  };
};

function Cultist.Frenzy(event, delay, repeats, creature)
  local healthPct = creature:GetHealthPct();
  if healthPct <= 50 then
    local randomMessage = math.random(1, 6);
    creature:CastSpell(creature, SPELL_FRENZY, true);
    creature:SendUnitSay(Cultist.Strings[randomMessage], 0);
    creature:RegisterEvent(Cultist.Fear, 6000, 1);
    creature:RemoveEventById(event);
  end
end

function Cultist.Fear(event, delay, repeats, creature)
  local randomMessage = math.random(7, 11);
  creature:SendUnitEmote(Cultist.Strings[randomMessage], nil, false);
  creature:CastSpell(creature, SPELL_FEAR, true);
  creature:RemoveEventById(event);
end

-- Main
function Cultist.OnEnterCombat(event, creature)
  creature:RegisterEvent(Cultist.Frenzy, 1000, 0);
end

function Cultist.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Cultist.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_BRAINWASHED_CULTIST, 1, Cultist.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_BRAINWASHED_CULTIST, 2, Cultist.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_BRAINWASHED_CULTIST, 4, Cultist.OnDied);        -- CREATURE_EVENT_ON_DIED
