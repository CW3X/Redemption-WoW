--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Crackling Elemental - Deadmines trash mob
 * AUTHOR : sundays
 * UPDATED: 18th Sept 2016
--]]

-- Constants
local ENTRY_ELEMENTAL   = 90012;
local SPELL_THUNDERCLAP =  8078;

local Elemental = {};

function Elemental.Thunderclap(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_THUNDERCLAP, true);
end

-- Main
function Elemental.OnEnterCombat(event, creature)
  local randomInterval = math.random(5500, 9000);
  local randomMaxCasts = math.random(2, 5);
  creature:RegisterEvent(Elemental.Thunderclap, randomInterval, randomMaxCasts);
end

function Elemental.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Elemental.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_ELEMENTAL,  1, Elemental.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_ELEMENTAL,  2, Elemental.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_ELEMENTAL,  4, Elemental.OnDied);        -- CREATURE_EVENT_ON_DIED
