--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Deathmaw Hellfiend - Trash mob (Deadmines)
 * AUTHOR : sundays
 * UPDATED: 22nd Sept 2016
--]]

-- Constants
local ENTRY_HELLFIEND      = 90006;
local SPELL_WIDOW_BITE     = 26226;
local SPELL_FESTERING_BITE = 16460;

local Hellfiend = {};

function Hellfiend.FesteringBite(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if not Victim:HasAura(SPELL_FESTERING_BITE) then
    creature:CastSpell(Victim, SPELL_FESTERING_BITE, true);
    local FesteringAura = Victim:GetAura(SPELL_FESTERING_BITE);
    FesteringAura:SetDuration(50000); -- 50s
  end
end

function Hellfiend.WidowBite(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_WIDOW_BITE, true);
end

-- Main
function Hellfiend.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Hellfiend.FesteringBite, 7000, 2);
  creature:RegisterEvent(Hellfiend.WidowBite, 5000, 0);
end

function Hellfiend.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Hellfiend.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_HELLFIEND, 1, Hellfiend.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_HELLFIEND, 2, Hellfiend.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_HELLFIEND, 4, Hellfiend.OnDied);        -- CREATURE_EVENT_ON_DIED
