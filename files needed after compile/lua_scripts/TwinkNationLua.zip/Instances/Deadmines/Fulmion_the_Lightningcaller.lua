--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Fulmion the Lightningcaller - Deadmines boss #2
 * AUTHOR : sundays
 * UPDATED: 18th Sept 2016
--]]

local BossTimers = require("../BossTimerMgr");

-- Constants
local ENTRY_LIGHTNINGCALLER  = 90011;
local ENTRY_LIGHTNING_ROD    = 90009;
local ENTRY_BOSS_DOOR        = 17153;
local ENTRY_FAKE_DOOR        = 500000;
local ENTRY_TRIGGER_DOOR1    = 90014;
local ENTRY_TRIGGER_DOOR2    = 90015;
local SPELL_ROD_LIGHTNING    = 22355; -- Used on lightning rods
local SPELL_LIGHTNING_SHIELD = 10432;
local SPELL_LIGHTNING_BOLT   = 13527; -- Normal attack
local SPELL_QUICKENING       = 23723;
local SPELL_TOTEM_LIGHTNING  = 16921; -- Used by lightning rods
local SPELL_SPAWN_ANIMATION  = 24240; -- Red lightning. On rod spawn.

local Fulmion = {
  Strings = {
    -- Enter combat
    "We've worked too hard for this. You won't undo years of work.",
    "The master won't be happy!",
    "Forever damned be all of you! You'll ruin EVERYTHING!",
    -- Phase 1
    "This will be a SHOCK to you all, hah! Meet my prisoners.",
    -- Phase 2
    "Lightning flows through these veins. I can feel the power.",
    "Fulmion becomes infused with power!", -- Boss emote
    -- Death
    "Lightning is departing from my body! No! I'm losing my power!",
    -- LoS from rod
    "There's no escape!",
    "Lightning CAN strike twice, friend.",
    "Running away, are we?",
    "There's no hiding from lightning!",
  },
  Spawns = {
    -- x, y, z, o
    [1] = {-289.72, -492.84, 49.92, 4.70},
    [2] = {-289.72, -525.38, 49.67, 1.55},
    [3] = {-281.73, -512.75, 49.33, 3.17},
    [4] = {-295.10, -512.75, 49.18, 6.21},
    [5] = {-262.713, -482.360, 49.435, -0.0174}, -- Door Trigger 1
    [6] = {-290.294, -536.960, 49.435, 1.5533}; -- Door Trigger 2
  };
};

local Instance = {
  Var = {};
};

local function OpenDoor(creature)
  local doorTrigger1  = creature:GetNearestCreature(533, ENTRY_TRIGGER_DOOR1, 0, 0);
  local doorTrigger2  = creature:GetNearestCreature(533, ENTRY_TRIGGER_DOOR2, 0, 0);
  if doorTrigger1 then
    local fakeDoor = doorTrigger1:GetNearestGameObject(533, ENTRY_FAKE_DOOR, 0);
    fakeDoor:Despawn();
  end
  if doorTrigger2 then
    local fakeDoor = doorTrigger2:GetNearestGameObject(533, ENTRY_FAKE_DOOR, 0);
    fakeDoor:Despawn();
  end
end

local function ResetRods(creature)
  local rods = creature:GetCreaturesInRange(533, ENTRY_LIGHTNING_ROD, 0, 0);
  for _, v in pairs(rods) do
    v:SetRespawnDelay(696969); -- fuck mangos
    v:DespawnOrUnsummon();
  end
end

local function SpawnRods(creature)
  local id  = creature:GetInstanceId();
  for i = 1, 4 do
    local rod = PerformIngameSpawn(1, ENTRY_LIGHTNING_ROD, 36, id, Fulmion.Spawns[i][1], Fulmion.Spawns[i][2], Fulmion.Spawns[i][3], Fulmion.Spawns[i][4], false, 0, 1);
    rod:CastSpell(rod, SPELL_SPAWN_ANIMATION, true);
    rod:SetInCombatWithZone();
  end
end

function Fulmion.LightningShield(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_LIGHTNING_SHIELD, true);
end

-- Used during Phase 2
function Fulmion.FastLightningBolt(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_LIGHTNING_BOLT, true);
end

-- Used during Phase 2
function Fulmion.FastLightningRod(event, delay, repeats, creature)
  local rods = creature:GetCreaturesInRange(100, ENTRY_LIGHTNING_ROD, 2, 1); -- 30yd, rod, friendly, alive
  local next = next;
  if next(rods) then
    local randomRod = math.random(1, #rods);
    local Victim    = creature:GetVictim();
    if Victim and not Victim:IsWithinLoS(rods[randomRod]) then
      local nearestRod = creature:GetNearestCreature(533, ENTRY_LIGHTNING_ROD, 0, 1);
      if not Victim:IsWithinLoS(nearestRod) then
        local randomText = math.random(8, 11);
        local x1, y1, z1 = creature:GetRelativePoint(1, (90 * math.pi / 180));
        local x2, y2, z2 = creature:GetRelativePoint(1, (270 * math.pi / 180));
        local orient     = Victim:GetO();
        local newRod1 = PerformIngameSpawn(1, ENTRY_LIGHTNING_ROD, 36, id, x1, y1, z1, o, false, 0, 1);
        local newRod2 = PerformIngameSpawn(1, ENTRY_LIGHTNING_ROD, 36, id, x2, y2, z2, o, false, 0, 1);
        newRod1:CastSpell(newRod1, SPELL_SPAWN_ANIMATION, true);
        newRod2:CastSpell(newRod2, SPELL_SPAWN_ANIMATION, true);
        creature:SendUnitSay(Fulmion.Strings[randomText], 0);
        creature:CastSpell(newRod1, SPELL_ROD_LIGHTNING, true);
      else
        creature:CastSpell(nearestRod, SPELL_ROD_LIGHTNING, true);
      end
    else
      creature:CastSpell(rods[randomRod], SPELL_ROD_LIGHTNING, true);
    end
  else
    -- Rods dead or out of range
    local playersInrange = creature:GetPlayersInRange(30, 1, 1); -- 30yd, hostile, alive
    if next(playersInrange) then
      local randomPlayer = math.random(1, #playersInrange);
      creature:CastSpell(playersInrange[randomPlayer], SPELL_ROD_LIGHTNING, false);
    end
  end
end

function Fulmion.LightningRod(event, delay, repeats, creature)
  local id = creature:GetInstanceId();
  if Instance[id].Var.Phase == 1 then
    local rods = creature:GetCreaturesInRange(100, ENTRY_LIGHTNING_ROD, 2, 1); -- 30yd, rod, friendly, alive
    local next = next; -- More efficient (allegedly)
    if next(rods) then
      local randomRod = math.random(1, #rods);
      local Victim    = creature:GetVictim();
      if not Victim:IsWithinLoS(rods[randomRod]) then
        local nearestRod = creature:GetNearestCreature(533, ENTRY_LIGHTNING_ROD, 0, 1);
        if not Victim:IsWithinLoS(nearestRod) then
          local randomText = math.random(8, 11);
          local x1, y1, z1 = Victim:GetRelativePoint(2, (90 * math.pi / 180));
          local x2, y2, z2 = Victim:GetRelativePoint(2, (270 * math.pi / 180));
          local orient     = Victim:GetO();
          local newRod1 = PerformIngameSpawn(1, ENTRY_LIGHTNING_ROD, 36, id, x1, y1, z1, orient, false, 0, 1);
          local newRod2 = PerformIngameSpawn(1, ENTRY_LIGHTNING_ROD, 36, id, x2, y2, z2, orient, false, 0, 1);
          newRod1:CastSpell(newRod1, SPELL_SPAWN_ANIMATION, true);
          newRod2:CastSpell(newRod2, SPELL_SPAWN_ANIMATION, true);
          creature:SendUnitSay(Fulmion.Strings[randomText], 0);
          creature:CastSpell(newRod1, SPELL_ROD_LIGHTNING, true);
        else
          creature:CastSpell(nearestRod, SPELL_ROD_LIGHTNING, true);
        end
      else
        creature:CastSpell(rods[randomRod], SPELL_ROD_LIGHTNING, true);
      end
    else
      -- Rods dead or out of range
      local playersInrange = creature:GetPlayersInRange(30, 1, 1); -- 30yd, hostile, alive
      local randomPlayer   = math.random(1, #playersInrange);
      creature:CastSpell(playersInrange[randomPlayer], SPELL_ROD_LIGHTNING, false);
    end
  elseif Instance[id].Var.Phase == 2 then
    creature:RegisterEvent(Fulmion.FastLightningRod, 4000, 0);
    creature:RemoveEventById(event);
  end
end

function Fulmion.LightningBolt(event, delay, repeats, creature)
  local id = creature:GetInstanceId();
  if Instance[id].Var.Phase == 2 then
    creature:RegisterEvent(Fulmion.FastLightningBolt, 2500, 0);
    creature:RemoveEventById(event);
  else
    local Victim = creature:GetVictim();
    creature:CastSpell(Victim, SPELL_LIGHTNING_BOLT, true);
  end
end

function Fulmion.CheckHealth(event, delay, repeats, creature)
  local healthPct = creature:GetHealthPct();
  local id        = creature:GetInstanceId();
  if healthPct <= 90 and healthPct > 40 and Instance[id].Var.Phase < 1 then
    -- Phase 1
    creature:RegisterEvent(Fulmion.LightningRod, 4000, 0);
    creature:SendUnitSay(Fulmion.Strings[4], 0);
    Instance[id].Var.Phase = 1;
    SpawnRods(creature);
  elseif healthPct < 40 and Instance[id].Var.Phase < 2 then
    -- Phase 2
    creature:SendUnitSay(Fulmion.Strings[5], 0);
    creature:SendUnitEmote(Fulmion.Strings[6], nil, true);
    Instance[id].Var.Phase = 2;
    creature:RemoveEventById(event); -- We don't need to check boss health every sec any longer.
  end
end

function Fulmion.CheckTarget(event, delay, repeats, creature)
  -- Prevent Fulmion from attacking the Lightning Rods
  local Victim = creature:GetVictim();
  if Victim and Victim:GetEntry() == ENTRY_LIGHTNING_ROD then
    -- End boss fight
    creature:Respawn();
    ResetRods(creature);
    creature:RemoveEvents();
  end
end

-- Main
function Fulmion.OnEnterCombat(event, creature, target)
  local randomMessage = math.random(1, 3);
  local TargetGroup   = target:GetGroup();
  local id = creature:GetInstanceId(); 
  Instance[id] = Instance[id] or {Var = {}};
  Instance[id].Var.Phase = 0;
  creature:SendUnitSay(Fulmion.Strings[randomMessage], 0);
  creature:RegisterEvent(Fulmion.LightningShield, 10000, 5);
  creature:RegisterEvent(Fulmion.LightningBolt,    6000, 0);
  creature:RegisterEvent(Fulmion.CheckHealth,      1000, 0);
  creature:RegisterEvent(Fulmion.CheckTarget,      3000, 0);
  -- Lock the doors
  PerformIngameSpawn(2, ENTRY_FAKE_DOOR, 36, id, Fulmion.Spawns[5][1], Fulmion.Spawns[5][2], Fulmion.Spawns[5][3], Fulmion.Spawns[5][4]);
  PerformIngameSpawn(2, ENTRY_FAKE_DOOR, 36, id, Fulmion.Spawns[6][1], Fulmion.Spawns[6][2], Fulmion.Spawns[6][3], Fulmion.Spawns[6][4]);
  BossTimers.BossStarted(id, creature:GetName(), target:GetGroup(), os.time(), creature:GetGUIDLow());
end

function Fulmion.OnLeaveCombat(event, creature)
  local id = creature:GetInstanceId();
  Instance[id] = Instance[id] or {Var = {}};
  Instance[id].Var.Phase = 0;
  BossTimers.DeleteTimer(id, creature:GetGUIDLow());
  ResetRods(creature);
  OpenDoor(creature);
  creature:RemoveEvents();
end

function Fulmion.OnDied(event, creature, killer)
  -- Update instance data.
  local id = creature:GetInstanceId();
  BossTimers.BossEnded(id, creature:GetMapId(), creature:GetName(), killer:GetGroup(), os.time(), creature:GetGUIDLow());
  creature:SendUnitYell(Fulmion.Strings[7], 0);
  Instance[id].Var.Phase = 0;
  ResetRods(creature);
  OpenDoor(creature);
  creature:RemoveEvents();
end

--[[
function Fulmion.OnReset(event, creature)
  local id = creature:GetInstanceId();
  Instance[id] = Instance[id] or {Var = {}};
  Instance[id].Var.Phase = 0;
  ResetRods(creature);
  OpenDoor(creature);
  creature:RemoveEvents();
end
--]]

RegisterCreatureEvent(ENTRY_LIGHTNINGCALLER,  1, Fulmion.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_LIGHTNINGCALLER,  2, Fulmion.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_LIGHTNINGCALLER,  4, Fulmion.OnDied);        -- CREATURE_EVENT_ON_DIED
-- RegisterCreatureEvent(ENTRY_LIGHTNINGCALLER, 23, Fulmion.OnReset);       -- CREATURE_EVENT_ON_RESET

-- Lightning Rod
local Totem = {};

function Totem.SpreadLightning(event, creature, caster, spellid)
  local next = next;
  if spellid == SPELL_ROD_LIGHTNING then
    local playersInrange = creature:GetPlayersInRange(100, 1, 1); -- 30yd, hostile, alive
     if next(playersInrange) then
       local randomPlayer = math.random(1, #playersInrange);
       creature:CastSpell(playersInrange[randomPlayer], SPELL_TOTEM_LIGHTNING, true);
       if math.random(1, 100) >= 55 then
        local rods = creature:GetCreaturesInRange(100, ENTRY_LIGHTNING_ROD, 2, 1); -- 30yd, rod, friendly, alive
        local next = next;
        if next(rods) then
          local randomRod = math.random(1, #rods);
          creature:CastSpell(rods[randomRod], SPELL_ROD_LIGHTNING, true);
        end
      end
    end
  end
end

-- Main
function Totem.OnEnterCombat(event, creature)
end

function Totem.OnLeaveCombat(event, creature, target)
end

function Totem.OnDied(event, creature, killer)
  creature:DespawnOrUnsummon();
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_LIGHTNING_ROD,  1, Totem.OnEnterCombat);  -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_LIGHTNING_ROD,  2, Totem.OnLeaveCombat);  -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_LIGHTNING_ROD,  4, Totem.OnDied);         -- CREATURE_EVENT_ON_DIED
RegisterCreatureEvent(ENTRY_LIGHTNING_ROD, 14, Totem.SpreadLightning) -- CREATURE_EVENT_ON_HIT_BY_SPELL
