--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Drok Gerek and Enslaved Fel Aberration boss fight for Deadmines -- boss #3
 * AUTHOR : sundays
 * UPDATED: 1st Oct 2016
--]]

local BossTimers = require("../BossTimerMgr");

-- Constants
local ENTRY_DROK_GEREK      = 90019;
local ENTRY_FEL_ABERRATION  = 90016;
local ENTRY_FEL_SENTRY      = 90023;
local ENTRY_TRIGGER_DOOR1   = 90021; -- Upstairs
local ENTRY_TRIGGER_DOOR2   = 90022; -- Downstairs
local ENTRY_LOCKED_DOOR     = 500000;
local FACTION_FRIENDLY      =    35;
local FACTION_ENEMY         =    14;
local TEXTID_DROK_GEREK     = 60000;
local SPELL_VISUAL_TELEPORT = 26638;
local SPELL_FLAMESTRIKE     = 22275;
local SPELL_PYROBLAST       = 12522;
local SPELL_FLAME_BUFFET    = 22713; -- 20 extra fire dmg, max 5 stack
-- local SPELL_BURNING_WISH = 18789; -- 15% extra fire damage (POSITIVE BUFF)
-- local SPELL_FLAMEBLADE   =  7808; -- 14 fire damage per attack (POSITIVE BUFF)
local SCALE_DEFAULT         =   4.5; -- Default scale for Fel Aberration

-- Drok Gerek
local Drok = {
  Strings = {
    "I like it. More misguided heroes. Let me introduce you to my little friend.",
  },
  Spawns = {
    -- x, y, z, o
    [1]  = {-219.243, -550.007, 19.307, 5.206}, -- Drok Gerek spawn
    [2]  = {-168.514, -579.861, 19.316, 3.124}, -- Upstairs door
    [3]  = {-242.965, -578.561, 51.137, 3.124}, -- Downstairs door
    [4]  = {-220.245, -585.234, 20.976, 3.293}, -- Fel Sentry 1
    [5]  = {-220.125, -573.230, 20.976, 2.699}, -- Fel Sentry 2
    [6]  = {-211.776, -564.792, 20.976, 1.973}, -- Fel Sentry 3
    [7]  = {-199.587, -564.808, 20.976, 1.202}, -- Fel Sentry 4
    [8]  = {-191.331, -573.345, 20.976, 0.497}, -- Fel Sentry 5
    [9]  = {-209.344, -594.338, 20.976, 1.405}, -- Fel Sentry 6
    [10] = {-197.898, -590.795, 20.976, 2.167}, -- Fel Sentry 7
  };
};

local function UnlockDoors(creature)
  local doorTrigger1 = creature:GetNearestCreature(533, ENTRY_TRIGGER_DOOR1, 0, 0);
  local doorTrigger2 = creature:GetNearestCreature(533, ENTRY_TRIGGER_DOOR2, 0, 0);
  if doorTrigger1 then
    local fakeDoor = doorTrigger1:GetNearestGameObject(533, ENTRY_LOCKED_DOOR, 0);
    if fakeDoor then
      fakeDoor:Despawn();
    end
  end
  if doorTrigger2 then
    local fakeDoor = doorTrigger2:GetNearestGameObject(533, ENTRY_LOCKED_DOOR, 0);
    if fakeDoor then
      fakeDoor:Despawn();
    end
  end
end

local function ResetEvent(creature)
  local id = creature:GetInstanceId();
  if not creature:GetNearestCreature(533, ENTRY_DROK_GEREK, 0, 1) then
    local DrokCreature = PerformIngameSpawn(1, ENTRY_DROK_GEREK, 36, id, Drok.Spawns[1][1], Drok.Spawns[1][2], Drok.Spawns[1][3], Drok.Spawns[1][4], false, 0, 1);
    DrokCreature:SetNPCFlags(1); -- Enable gossip
  end
  UnlockDoors(creature);
  creature:SetScale(SCALE_DEFAULT);
  creature:SetFaction(FACTION_FRIENDLY);
  -- Despawn Fel Sentries
  local FelSentries = creature:GetCreaturesInRange(533, ENTRY_FEL_SENTRY, 0, 0);
  for _, v in pairs(FelSentries) do
    v:SetRespawnDelay(696969);
    v:DespawnOrUnsummon();
  end
end

function Drok.TeleportAway(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_VISUAL_TELEPORT, true);
  creature:SetRespawnDelay(696969);
  creature:DespawnOrUnsummon(1500);
end

function Drok.OnHello(event, player, object)
  player:GossipClearMenu();
  player:GossipMenuAddItem(0, "Looks like it's all gone to your head, Drok. Maybe we should put an end to your senseless babbling.", 2, 1);
  player:GossipSendMenu(TEXTID_DROK_GEREK, object);
end

function Drok.OnSelect(event, player, object, sender, intid, code, menu_id)
  local id = object:GetInstanceId();
  if intid == 1 then
    player:GossipComplete();
    object:SetNPCFlags(0); -- Disable gossip
    object:SendUnitSay(Drok.Strings[1], 0);
    object:RegisterEvent(Drok.TeleportAway, 1500, 1);
    -- Lock the doors
    PerformIngameSpawn(2, ENTRY_LOCKED_DOOR, 36, id, Drok.Spawns[2][1], Drok.Spawns[2][2], Drok.Spawns[2][3], Drok.Spawns[2][4]); -- Upstairs
    PerformIngameSpawn(2, ENTRY_LOCKED_DOOR, 36, id, Drok.Spawns[3][1], Drok.Spawns[3][2], Drok.Spawns[3][3], Drok.Spawns[3][4]); -- Downstairs
    -- Fel Aberration
    local FelCreature = object:GetNearestCreature(533, ENTRY_FEL_ABERRATION, 0, 0);
    FelCreature:SetFaction(FACTION_ENEMY);
    FelCreature:AttackStart(player);
  end
end

RegisterCreatureGossipEvent(ENTRY_DROK_GEREK, 1, Drok.OnHello);  -- GOSSIP_EVENT_ON_HELLO
RegisterCreatureGossipEvent(ENTRY_DROK_GEREK, 2, Drok.OnSelect); -- GOSSIP_EVENT_ON_SELECT

-- Enslaved Fel Aberration
local Fel = {
  Strings = {
    -- On enter combat (BOSS EMOTES)
    "A desultory heat overcomes you.",
    "You feel an incoming wave of heat.",
    "A terrible heat wave hits you.",
    -- Superheated
    "Can you feel the heat?",
    "It's about to get a lot hotter.",
    "What a terrible fate.",
    "I hope you can stand the heat.",
    "Toasty.",
    "The has just begun.",
    "I like my %s well-cooked.",
    "Roast %s? My favourite.",
    -- Phase 2 (30% health)
    "The flame... it's dying.",
    "Once kindled, the flame does not die out easily.",
    "You can't blow out this flame. I'll extinguish you all!"
  };
};

local Instance = {Var = {}};

function Fel.Flamestrike(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_FLAMESTRIKE, true);
end

function Fel.FlameBuffet(event, delay, repeats, creature)
  local id     = creature:GetInstanceId();
  Instance[id].Var.Stacks = Instance[id].Var.Stacks + 1;
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_FLAME_BUFFET, true);
end

function Fel.Superheated(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  local id     = creature:GetInstanceId();
  if Instance[id].Var.Stacks >= 5 then
    local randomMessage = math.random(4, 11);
    if randomMessage <= 9 then
      creature:SendUnitSay(Fel.Strings[randomMessage], 0);
    else
      local VictimRace = Victim:GetRaceAsString();
      creature:SendUnitSay(string.format(Fel.Strings[randomMessage], VictimRace), 0);
    end
    creature:CastSpell(Victim, SPELL_PYROBLAST, true);
    Instance[id].Var.Stacks = 0;
  end
end

function Fel.CheckHealth(event, delay, repeats, creature)
  local healthPct   = creature:GetHealthPct();
  local scaleFactor = healthPct / 100;
  if healthPct >= 45 then
    creature:SetScale(SCALE_DEFAULT * scaleFactor);
  else
    local id            = creature:GetInstanceId();
    local randomMessage = math.random(12, 14);
    creature:SetScale(1.5);
    creature:SendUnitYell(Fel.Strings[randomMessage], 0);
    for i = 4, 10, 1 do
      local FelSentry = PerformIngameSpawn(1, ENTRY_FEL_SENTRY, 36, id, Drok.Spawns[i][1], Drok.Spawns[i][2], Drok.Spawns[i][3], Drok.Spawns[i][4], false, 0, 1);
      FelSentry:SetRespawnDelay(696969);
    end
    creature:RemoveEventById(event);
  end
end

-- Main
function Fel.OnEnterCombat(event, creature, target)
  local id     = creature:GetInstanceId();
  Instance[id] = Instance[id] or {Var = {}};
  Instance[id].Var.Stacks = 0;
  local randomMessage = math.random(1, 3);
  creature:SendUnitEmote(Fel.Strings[randomMessage], nil, true);
  creature:RegisterEvent(Fel.Flamestrike, 9000, 0);
  creature:RegisterEvent(Fel.FlameBuffet, 5000, 0);
  creature:RegisterEvent(Fel.CheckHealth, 1500, 0);
  creature:RegisterEvent(Fel.Superheated, 2000, 0);
  BossTimers.BossStarted(id, creature:GetName(), target:GetGroup(), os.time(), creature:GetGUIDLow());
end

function Fel.OnLeaveCombat(event, creature)
  local id = creature:GetInstanceId();
  BossTimers.DeleteTimer(id, creature:GetGUIDLow());
  Instance[id] = Instance[id] or {Var = {}};
  Instance[id].Var.Stacks = 0;
  ResetEvent(creature);
  creature:RemoveEvents();
end

function Fel.OnDied(event, creature, killer)
  local id = creature:GetInstanceId();
  -- Update instance data.
  BossTimers.BossEnded(id, creature:GetMapId(), creature:GetName(), killer:GetGroup(), os.time(), creature:GetGUIDLow());
  Instance[id] = Instance[id] or {Var = {}};
  Instance[id].Var.Stacks = 0;
  UnlockDoors(creature);
  creature:RemoveEvents();
end

--[[
function Fel.OnReset(event, creature)
  if creature:IsAlive() then
    ResetEvent(creature);
  end
  creature:RemoveEvents();
end
--]]

function Fel.OnSpawn(event, creature)
  ResetEvent(creature);
end

RegisterCreatureEvent(ENTRY_FEL_ABERRATION,  1, Fel.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_FEL_ABERRATION,  2, Fel.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_FEL_ABERRATION,  4, Fel.OnDied);        -- CREATURE_EVENT_ON_DIED
-- RegisterCreatureEvent(ENTRY_FEL_ABERRATION, 23, Fel.OnReset);       -- CREATURE_EVENT_ON_RESET
RegisterCreatureEvent(ENTRY_FEL_ABERRATION, 5, Fel.OnSpawn);
