--[[
  TwinkNation 2016 http://twinknation.org/
  DESC    : Minor Fel Sentry - Deadmines Boss Add for Drok Gerek encounter.
  AUTHOR  : sundays
  UPDATED : 24th Sept 2016
--]]

-- Constants
local ENTRY_FEL_SENTRY      = 90023;
local SPELL_FIREBALL_VOLLEY = 11988;

local Sentry = {};

function Sentry.FireballVolley(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_FIREBALL_VOLLEY);
end

function Sentry.CheckLoS(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    if not creature:IsWithinLoS(Victim) then
      creature:ClearThreatList();
      creature:ClearInCombat();
      creature:RemoveEvents();
    end
  else
    creature:ClearThreatList();
    creature:ClearInCombat();
    creature:RemoveEvents();
  end
end

-- Main
function Sentry.OnEnterCombat(event, creature, target)
  local randomInterval = math.random(5000, 8500);
  creature:RegisterEvent(Sentry.FireballVolley, randomInterval, 0);
  creature:RegisterEvent(Sentry.CheckLoS, 5000, 0);
  if math.random(1, 100) >= 50 then
    creature:CastSpell(target, SPELL_FIREBALL_VOLLEY);
  end
end

function Sentry.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Sentry.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_FEL_SENTRY, 1, Sentry.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_FEL_SENTRY, 2, Sentry.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_FEL_SENTRY, 4, Sentry.OnDied);        -- CREATURE_EVENT_ON_DIED
