--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Fel Sentry - Deadmines trash mob in "The Foundry".
 * AUTHOR : sundays
 * UPDATED: 21st Sept 2016
--]]

-- Constants
local ENTRY_FEL_SENTRY      = 90018;
local SPELL_FIRE_NOVA       =  8503; -- 10yd, 200dmg
local SPELL_FIREBALL_VOLLEY = 22425;

local Sentry = {};

function Sentry.FireNova(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_FIRE_NOVA, true);
end

function Sentry.FireballVolley(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_FIREBALL_VOLLEY);
end

function Sentry.CheckLoS(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if not creature:IsWithinLoS(Victim) then
    creature:ClearThreatList();
    creature:ClearInCombat();
    creature:RemoveEvents();
  end
end

-- Main
function Sentry.OnEnterCombat(event, creature)
  creature:RegisterEvent(Sentry.FireNova, 6000, 2);
  creature:RegisterEvent(Sentry.FireballVolley, 3500, 0);
  creature:RegisterEvent(Sentry.CheckLoS, 5000, 0);
end

function Sentry.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Sentry.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_FEL_SENTRY, 1, Sentry.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_FEL_SENTRY, 2, Sentry.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_FEL_SENTRY, 4, Sentry.OnDied);        -- CREATURE_EVENT_ON_DIED
