--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Deathmaw Alchemist - Trash mob (Deadmines)
 * AUTHOR : sundays
 * UPDATED: 24th Sept 2016
--]]

-- Constants
local ENTRY_ALCHEMIST    = 90034;
local SPELL_CONE_OF_COLD =   120;
local SPELL_FRENZY       =  8699; -- 35% speed 100dmg over 20s
local SPELL_HEAL_POTION  =  4042; -- 700 to 900hp
local SPELL_FROST_NOVA   =  6131;
local SPELL_FIREBALL     =  3140;
-- Random effects on death
local SPELL_INVISIBILITY =    66; -- Lesser invisibility
local SPELL_POWER_SHIElD =  6066; -- Power word: Shield 381 damage
local SPELL_SPRINT       =  2983;
local SPELL_FOUL_CHILL   =  6873; -- 50 extra frost damage
local SPELL_PROTECTION   =  1138; -- 10 shadow & frost resist
local SPELL_FEAR_WARD    =  6346;
local SPELL_BLIND_LIGHT  = 23733; -- blinding light bonus speed cast/melee
local SPELL_STALVAN      =  3105; -- -5 all stats curse
local SPELL_THORNS       =   782; -- thorns rank 2
local SPELL_WATER_BREATH =  7178; -- water breathing

local Alchemist = {
  Strings = {
    "A mysterious elixir falls to the ground and shatters, splashing %s.",
    "%s gets splashed by Deathmaw Alchemist's potion.",
    "A glowing bottle falls to the ground and breaks. Liquid splashes %s.",
    "A bottle falls out of Deathmaw Alchemist's hand. It breaks and splashes %s with an unknown substance.",
    "Deathmaw Alchemist falls to the ground. An elixir shatters and splashes %s.",
    "Deathmaw Alchemist chugs a potion and becomes enraged!",
    "Deathmaw Alchemist drinks a healing potion.",
    "Deathmaw Alchemist drinks a potion and gains new abilities.",
  },
  -- ID, Duration (ms)
  SpellEffects = {
    {SPELL_INVISIBILITY, 20000},
    {SPELL_POWER_SHIElD, 20000},
    {SPELL_SPRINT,        8000},
    {SPELL_FOUL_CHILL,   30000},
    {SPELL_PROTECTION,   30000},
    {SPELL_FEAR_WARD,    20000},
    {SPELL_BLIND_LIGHT,  20000},
    {SPELL_STALVAN,      40000},
    {SPELL_THORNS,       50000},
    {SPELL_WATER_BREATH, 50000};
  };
};

function Alchemist.CheckHealth(event, delay, repeats, creature)
  if creature:GetHealthPct() <= 65 then
    local randomMagic = math.random(1, 3);
    if randomMagic == 1 then
      creature:SendUnitEmote(Alchemist.Strings[6], nil, false);
      creature:CastSpell(creature, SPELL_FRENZY, true);
    elseif randomMagic == 2 then
      creature:SendUnitEmote(Alchemist.Strings[7], nil, false);
      creature:CastSpell(creature, SPELL_HEAL_POTION, true);
    else
      local RandomNewAbility = math.random(1, 2);
      if RandomNewAbility == 1 then
        local Victim = creature:GetVictim();
        if Victim then
          creature:CastSpell(Victim, SPELL_FIREBALL);
        end
      else
        creature:CastSpell(creature, SPELL_FROST_NOVA);
      end
      creature:SendUnitEmote(Alchemist.Strings[8], nil, false);
    end
    creature:RemoveEventById(event);
  end
end

function Alchemist.ConeOfCold(event, delay, repeats, creature)
  if math.random(1, 100) >= 65 then
    creature:CastSpell(creature, SPELL_CONE_OF_COLD);
  end
end

-- Main
function Alchemist.OnEnterCombat(event, creature, target)
  local randomMaxCasts = math.random(1, 4);
  creature:RegisterEvent(Alchemist.ConeOfCold, 9000, randomMaxCasts);
  creature:RegisterEvent(Alchemist.CheckHealth, 2000, 0);
end

function Alchemist.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Alchemist.OnDied(event, creature, killer)
  if math.random(1, 100) >= 50 then
    local randomText        = math.random(1, 5);
    local randomEffectIndex = math.random(1, 10);
    local effectId       = Alchemist.SpellEffects[randomEffectIndex][1];
    local effectDuration = Alchemist.SpellEffects[randomEffectIndex][2];
    local killerName     = killer:GetName();
    creature:SendUnitEmote(string.format(Alchemist.Strings[randomText], killerName), nil, false);
    killer:CastSpell(killer, effectId, true);
    local effectAura = killer:GetAura(effectId);
    effectAura:SetDuration(effectDuration);
  end
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_ALCHEMIST, 1, Alchemist.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_ALCHEMIST, 2, Alchemist.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_ALCHEMIST, 4, Alchemist.OnDied);        -- CREATURE_EVENT_ON_DIED
