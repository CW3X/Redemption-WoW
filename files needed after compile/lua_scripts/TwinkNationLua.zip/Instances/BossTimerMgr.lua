--[[
  * http://twinknation.org/
  * DESC   : Manages boss timer records.
  * AUTHOR : Sundays
  * UPDATED: 27th Oct 2016
--]]

local Timers = {};

function Timers.DeleteTimer(instanceId, guidLow)
  local key     = instanceId .. guidLow;
  local Current = SharedData.BossTimers.Ongoing[key];
  if Current then
    Current = {};
    PrintError("Successfully deleted boss timer with key " .. key);
  end
end

function Timers.BossStarted(instanceId, creatureName, group, time, guidLow)
  if group then
    local GroupGUID = group:GetGUID();
    local key       = instanceId .. guidLow;
    SharedData.BossTimers.Ongoing[key] = {};
    table.insert(SharedData.BossTimers.Ongoing[key], GroupGUID);    -- [1]
    table.insert(SharedData.BossTimers.Ongoing[key], creatureName); -- [2]
    table.insert(SharedData.BossTimers.Ongoing[key], time);         -- [3]
  end
end

function Timers.BossEnded(instanceId, mapId, creatureName, group, time, guidLow)
  if group then
    local key          = instanceId .. guidLow;
    local GroupMembers = group:GetMembers();
    local MemberCount  = group:GetMembersCount();
    local GroupNames   = {};
    local MemberGuilds = {};
    local Current      = SharedData.BossTimers.Ongoing[key];
    local next = next;
    if next(Current) then
      for _, v in pairs(GroupMembers) do
        table.insert(GroupNames, v:GetName());
        table.insert(MemberGuilds, v:GetGuildId());
      end
      local BossName    = Current[2];
      local NamesString = table.concat(GroupNames, ", ");
      local TimeFinal   = time - Current[3];
      local GuildId     = 0;
      local GuildName   = "PUG";
      local TimeStamp   = os.time();
      if (TimeFinal < 10) then -- GM kill or cheater.
        Current = {};
        return;
      end
      if table.concat(MemberGuilds) == string.rep(MemberGuilds[1], MemberCount) then
        -- All the members are in the same guild.
        GuildId   = tonumber(MemberGuilds[1]);
        GuildName = GroupMembers[1]:GetGuildName();
      end
      CharDBExecute(string.format("INSERT INTO `characters`.`tn_boss_timers` (`mapId`, `boss_name`, `time_seconds`, `party_names`, `guildId`, `guild_name`, `timestamp`) VALUES ('%d', '%s', '%d', '%s', '%d', '%s', '%d');",
                                                                               mapId, BossName, TimeFinal, NamesString, GuildId, GuildName, TimeStamp));
      Current = {};
    else
      PrintError(string.format("GroupID %d killed a boss, but there is no existing ongoing bosstimer record."), group:GetGUID());
    end
  end
end

return Timers;
