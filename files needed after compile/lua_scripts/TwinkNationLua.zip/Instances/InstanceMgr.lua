--[[
  * http://twinknation.org/
  * DESC   : Sets up tables holding data for custom instances.
  * AUTHOR : Sundays
  * UPDATED: 21st Oct 2016
--]]

-- Constants
local MAP_ID_DEADMINES  = 36;
local MAP_ID_SHADOWFANG = 33;

function OnEnterDeadmines(event, instance_data, map, player)
  local InstanceId = map:GetInstanceId();
  if not SharedData.Deadmines[InstanceId] then
    PrintError(string.format("Creating new instance data for Deadmines, instance id %d", InstanceId));
    SharedData.Deadmines[InstanceId] = {};
    SharedData.Deadmines[InstanceId].BossesKilled = {false, false, false, false};
  end
end

function OnEnterShadowfang(event, instance_data, map, player)
  local InstanceId = map:GetInstanceId();
  if not SharedData.ShadowfangKeep[InstanceId] then
    PrintError(string.format("Creating new instance data for Shadowfang Keep, instance id %d", InstanceId));
    SharedData.ShadowfangKeep[InstanceId] = {};
    SharedData.ShadowfangKeep[InstanceId].BossesKilled = {false, false, false, false, false};
  end
end

RegisterMapEvent(MAP_ID_DEADMINES, 4, OnEnterDeadmines);   -- INSTANCE_EVENT_ON_PLAYER_ENTER
RegisterMapEvent(MAP_ID_SHADOWFANG, 4, OnEnterShadowfang); -- INSTANCE_EVENT_ON_PLAYER_ENTER
