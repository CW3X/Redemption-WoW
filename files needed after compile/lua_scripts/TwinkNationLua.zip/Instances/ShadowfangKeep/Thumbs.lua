--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Thumbs -- 2nd boss in SFK.
 * AUTHOR : sundays
 * UPDATED: 7th November 2016
--]]

local BossTimers = require("../BossTimerMgr");

-- Constants
local ENTRY_THUMBS           = 90064;
local ENTRY_SPORE            = 90065;
local ENTRY_GUEST            = 90066;
local SPELL_ENTANGLING_ROOTS = 24648; -- Visual used on spectral guests.
local SPELL_INSECT_SWARM     = 24977;
-- local SPELL_THUNDERCLAP      = 26554;
local SPELL_THORN_VOLLEY     = 21749;
local SPELL_SPORE_CLOUD      = 21547; -- Used by spores
local SPELL_FUNGAL_BLOOM     = 29232; -- Used by spores

local Thumbs = {
  Strings = {
    -- On combat
    "Looks like dinner's over.",
    -- Spore spawn
    "Thumbs releases a spore.",
  };
};

function Thumbs.Spore(event, delay, repeats, creature)
  local randomTarget = creature:GetAITarget(0, true, 0, 50);
  if randomTarget then
    local id         = creature:GetInstanceId();
    local x, y, z, o = randomTarget:GetLocation();
    local SpawnedSpore = PerformIngameSpawn(1, ENTRY_SPORE, 33, id, x, y, z, o, false);
    SpawnedSpore:SetRespawnDelay(696969);
    creature:CastSpell(randomTarget, SPELL_SPORE_CLOUD, true);
    creature:SendUnitEmote(Thumbs.Strings[2], nil, true);
  end
end

function Thumbs.InsectSwarm(event, delay, repeats, creature)
  local randomTarget = creature:GetAITarget(0, true, 0, 50);
  if randomTarget and not randomTarget:HasAura(SPELL_INSECT_SWARM) then
    creature:CastSpell(randomTarget, SPELL_INSECT_SWARM, true);
  end
end

function Thumbs.ThornVolley(event, delay, repeats, creature)
  if creature:GetHealthPct() <= 25 then
    local Victim = creature:GetVictim();
    creature:CastSpell(creature, SPELL_THORN_VOLLEY, true);
    -- creature:CastSpell(Victim, SPELL_THUNDERCLAP, true);
  end
end

-- Main
function Thumbs.OnEnterCombat(event, creature, target)
  local InstanceId = creature:GetInstanceId();
  creature:CastSpell(target, SPELL_INSECT_SWARM, true);
  creature:RegisterEvent(Thumbs.Spore, 18000, 0);
  creature:RegisterEvent(Thumbs.InsectSwarm, 9000, 0);
  creature:RegisterEvent(Thumbs.ThornVolley, 12000, 0);
  -- Kill Ghastly Guests
  local GuestsInRange = creature:GetCreaturesInRange(533, ENTRY_GUEST, 0, 1);
  local next = next;
  if next(GuestsInRange) then
    for _, v in pairs(GuestsInRange) do
      v:CastSpell(v, SPELL_ENTANGLING_ROOTS, true);
    end
    creature:SendUnitSay(Thumbs.Strings[1], 0);
  end
  BossTimers.BossStarted(InstanceId, creature:GetName(), target:GetGroup(), os.time(), creature:GetGUIDLow());
end

function Thumbs.OnLeaveCombat(event, creature)
  local InstanceId = creature:GetInstanceId();
  local SporesInRange = creature:GetCreaturesInRange(533, ENTRY_SPORE, 0, 0);
  local next = next;
  if next(SporesInRange) then
    for _, v in pairs(SporesInRange) do
      v:DespawnOrUnsummon(0);
    end
  end
  BossTimers.DeleteTimer(InstanceId, creature:GetGUIDLow());
  creature:RemoveEvents();
end

function Thumbs.OnDied(event, creature, killer)
  local InstanceId = creature:GetInstanceId();
  BossTimers.BossEnded(InstanceId, creature:GetMapId(), creature:GetName(), killer:GetGroup(), os.time(), creature:GetGUIDLow());
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_THUMBS, 1, Thumbs.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_THUMBS, 2, Thumbs.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_THUMBS, 4, Thumbs.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Fungal Growth
local Spore = {};

function Spore.OnDied(event, creature, killer)
  if killer then
    creature:AddAura(SPELL_FUNGAL_BLOOM, killer);
    local SporeAura = killer:GetAura(SPELL_FUNGAL_BLOOM);
    SporeAura:SetDuration(7000);
  end
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_SPORE, 4, Spore.OnDied);        -- CREATURE_EVENT_ON_DIED
