--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Runic Golem - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_GOLEM  = 90047;
local SPELL_STOMP  = 12612;
local SPELL_ARCANE = 10202; -- Arcane explosion

local Golem = {};

function Golem.Stomp(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_STOMP, true);
end

function Golem.Explosion(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_ARCANE, true);
end

-- Main
function Golem.OnEnterCombat(event, creature)
  local randomInterval = math.random(6000, 12000);
  creature:RegisterEvent(Golem.Stomp, 7500, 0);
  creature:RegisterEvent(Golem.Explosion, randomInterval, 2);
end

function Golem.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Golem.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_GOLEM, 1, Golem.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_GOLEM, 2, Golem.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_GOLEM, 4, Golem.OnDied);        -- CREATURE_EVENT_ON_DIED
