--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Ike the Frigid -- SFK boss.
 * AUTHOR : sundays
 * UPDATED: 7th November 2016
--]]

local BossTimers = require("../BossTimerMgr");

-- Constants
local ENTRY_IKE           = 90076;
local ENTRY_DOOR          = 18972;
local SPELL_FOUL_CHILL    =  6873; -- 50 extra frost damage
local SPELL_WINTERS_CHILL = 12579; -- 2% crit chance per stack
local SPELL_CHILL_NOVA    = 18099; -- bp0: damage, bp1: slow, bp2: knock back
local SPELL_ICE_TOMB      = 16869; -- 10 sec
local SPELL_ICICLE        = 11131; -- bp0: slow, bp1: damage
local SPELL_BLIZZARD      = 10185; -- 720dmg over 8s

local Ike = {
  Strings = {
    -- Ice tomb
    "%s begins to feel overcome with an unbearable cold.",
    -- On cast spell
    "How I'd love to shatter your frozen bones.",
    "Do you feel the cold?",
    "Your brittle bones will break.",
    "A cold, dark winter approaches.",
    "More bones for my collection.",
    "You're shaking in your little boots. Cute.",
    -- On death
    "Woe is me!",
    "What a pity.",
    "We were only getting started!",
  };
};

local function UnlockDoor(creature)
  local Door = creature:GetNearestGameObject(533, ENTRY_DOOR, 0);
  if Door then
    Door:SetGoState(0);
  end
end

local function SayOnCast(creature)
  if math.random(1, 100) >= 75 then
    local RandomText = math.random(2, 7);
    creature:SendUnitSay(Ike.Strings[RandomText], 0);
  end
end

function Ike.IceTomb(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0, 100, SPELL_WINTERS_CHILL);
  if Target and Target:HasAura(SPELL_WINTERS_CHILL) then
    local ChillAura = Target:GetAura(SPELL_WINTERS_CHILL);
    if ChillAura:GetStackAmount() >= 10 then
      creature:CastSpell(Target, SPELL_ICE_TOMB);
      creature:SendUnitEmote(string.format(Ike.Strings[1], Target:GetName()), nil, true);
    end
  end
end

function Ike.ChillNova(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim and Victim:HasAura(SPELL_WINTERS_CHILL) then
    local ChillAura = Victim:GetAura(SPELL_WINTERS_CHILL);
    if ChillAura:GetStackAmount() >= 25 then
      creature:CastSpell(creature, SPELL_CHILL_NOVA, true);
      SayOnCast(creature);
    else
      local RandomKnockback = math.random(33, 75);
      creature:CastCustomSpell(creature, SPELL_CHILL_NOVA, true, nil, nil, RandomKnockback, nil, 0);
    end
  end
end

function Ike.Blizzard(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_BLIZZARD, false);
  end
end

function Ike.Icicle(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0, 20, SPELL_WINTERS_CHILL);
  if Target and Target:HasAura(SPELL_WINTERS_CHILL) then
    local ChillAura = Target:GetAura(SPELL_WINTERS_CHILL);
    if ChillAura:GetStackAmount() >= 20 then
      local RandomDamage = math.random(300, 450);
      creature:CastCustomSpell(Target, SPELL_ICICLE, true, RandomDamage, nil, nil, nil, 0);
      SayOnCast(creature);
    else
      local RandomDamage = math.random(200, 325);
      creature:CastCustomSpell(Target, SPELL_ICICLE, true, RandomDamage, nil, nil, nil, 0);
    end
  end
end

function Ike.FoulChill(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0); -- Random
  if Target then
    creature:CastSpell(Target, SPELL_FOUL_CHILL, true);
    local FoulChillAura = Target:GetAura(SPELL_FOUL_CHILL);
    if FoulChillAura then
      FoulChillAura:SetDuration(45000); -- 45s
    end
  end
end

function Ike.WintersChill(event, delay, repeats, creature)
  local Targets = creature:GetAITargets();
  for _, v in pairs(Targets) do
    if v:HasAura(SPELL_WINTERS_CHILL) then
      local ChillAura = v:GetAura(SPELL_WINTERS_CHILL);
      if ChillAura:GetStackAmount() < 50 then
        ChillAura:SetStackAmount(ChillAura:GetStackAmount() + 1);
        -- creature:AddAura(SPELL_WINTERS_CHILL, v);
      else
        ChillAura:SetStackAmount(50);
      end
    else
      creature:AddAura(SPELL_WINTERS_CHILL, v);
    end
  end
end

-- Main
function Ike.OnEnterCombat(event, creature, target)
  local InstanceId = creature:GetInstanceId();
  creature:RegisterEvent(Ike.WintersChill, 2000, 0);
  creature:RegisterEvent(Ike.FoulChill, 12500, 0);
  creature:RegisterEvent(Ike.IceTomb, 18000, 0);
  creature:RegisterEvent(Ike.Blizzard, 45000, 0);
  creature:RegisterEvent(Ike.ChillNova, 30000, 0);
  creature:RegisterEvent(Ike.Icicle, 23500, 0);
  BossTimers.BossStarted(InstanceId, creature:GetName(), target:GetGroup(), os.time(), creature:GetGUIDLow());
end

function Ike.OnLeaveCombat(event, creature)
  local InstanceId = creature:GetInstanceId();
  BossTimers.DeleteTimer(InstanceId, creature:GetGUIDLow());
  creature:RemoveEvents();
end

function Ike.OnDied(event, creature, killer)
  local InstanceId = creature:GetInstanceId();
  UnlockDoor(creature);
  if math.random(1, 100) >= 75 then
    creature:SendUnitSay(Ike.Strings[math.random(8, 10)], 0);
  end
  BossTimers.BossEnded(InstanceId, creature:GetMapId(), creature:GetName(), killer:GetGroup(), os.time(), creature:GetGUIDLow());
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_IKE, 1, Ike.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_IKE, 2, Ike.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_IKE, 4, Ike.OnDied);        -- CREATURE_EVENT_ON_DIED
