--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Shadowfang Shade - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 19th October 2016
--]]

-- Constants
local ENTRY_SHADE  = 90049;
local SPELL_VOLLEY = 22665; -- shadowbolt volley

local Shade = {};

function Shade.Shadowbolt(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_VOLLEY);
end

-- Main
function Shade.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Shade.Shadowbolt, 5000, 0);
end

function Shade.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Shade.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_SHADE, 1, Shade.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_SHADE, 2, Shade.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_SHADE, 4, Shade.OnDied);        -- CREATURE_EVENT_ON_DIED
