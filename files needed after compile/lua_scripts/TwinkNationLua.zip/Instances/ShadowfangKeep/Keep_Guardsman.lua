--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Shadowfang Keep Guardsman - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_GUARD      = 90041;
local SPELL_SHIELDWALL = 29061; -- 75% DR
local SPELL_CLEAVE     = 20569;

local Guard = {};

function Guard.Cleave(event, delay, repeats, creature)
  if math.random(1, 100) >= 40 then
    local Victim = creature:GetVictim();
    creature:CastSpell(Victim, SPELL_CLEAVE);
  end
end

function Guard.Shieldwall(event, delay, repeats, creature)
  if creature:GetHealthPct() <= 50 then
    creature:CastSpell(creature, SPELL_SHIELDWALL);
    creature:RemoveEventById(event);
  end
end

-- Main
function Guard.OnEnterCombat(event, creature)
  creature:RegisterEvent(Guard.Cleave, 6000, 0);
  creature:RegisterEvent(Guard.Shieldwall, 2500, 0);
end

function Guard.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Guard.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_GUARD, 1, Guard.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_GUARD, 2, Guard.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_GUARD, 4, Guard.OnDied);        -- CREATURE_EVENT_ON_DIED
