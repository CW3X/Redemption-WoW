--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Disfigured Homunculus - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_HOMUNCULUS = 90040;
local SPELL_FIREBOLT   = 15592;

local Homunculus = {};

function Homunculus.Firebolt(event, delay, repeats, creature)
  if math.random(1, 100) >= 40 then
    local Victim = creature:GetVictim();
    creature:CastSpell(Victim, SPELL_FIREBOLT);
  end
end

-- Main
function Homunculus.OnEnterCombat(event, creature)
  creature:RegisterEvent(Homunculus.Firebolt, 5000, 0);
end

function Homunculus.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Homunculus.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_HOMUNCULUS, 1, Homunculus.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_HOMUNCULUS, 2, Homunculus.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_HOMUNCULUS, 4, Homunculus.OnDied);        -- CREATURE_EVENT_ON_DIED
