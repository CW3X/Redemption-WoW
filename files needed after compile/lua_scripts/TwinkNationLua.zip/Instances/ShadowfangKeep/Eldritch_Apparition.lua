--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Eldritch Apparition - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 19th October 2016
--]]

-- Constants
local ENTRY_APPARITION = 90049;
local SPELL_VEIL       = 28440; -- Veil of Shadow, 75% heal reduction

local Apparition = {};

function Apparition.VeilOfShadow(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_VEIL);
end

-- Main
function Apparition.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Apparition.VeilOfShadow, 8000, 0);
end

function Apparition.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Apparition.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_APPARITION, 1, Apparition.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_APPARITION, 2, Apparition.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_APPARITION, 4, Apparition.OnDied);        -- CREATURE_EVENT_ON_DIED
