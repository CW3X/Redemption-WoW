--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Spectral Anchorite - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 26th October 2016
--]]

-- Constants
local ENTRY_ANCHORITE = 90058;
local SPELL_SMITE     = 10934;
local SPELL_HOLY_FIRE = 15265;

local Anchorite = {};

function Anchorite.Holyfire(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim and math.random(1, 100) >= 65 then
    creature:CastSpell(Victim, SPELL_HOLY_FIRE);
  end
  RemoveEventById(event);
end

function Anchorite.Smite(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(creature, SPELL_SMITE);
  end
end

-- Main
function Anchorite.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Anchorite.Holyfire, 2000, 1);
  creature:RegisterEvent(Anchorite.Smite, 6000, 0);
end

function Anchorite.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Anchorite.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_ANCHORITE, 1, Anchorite.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_ANCHORITE, 2, Anchorite.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_ANCHORITE, 4, Anchorite.OnDied);        -- CREATURE_EVENT_ON_DIED
