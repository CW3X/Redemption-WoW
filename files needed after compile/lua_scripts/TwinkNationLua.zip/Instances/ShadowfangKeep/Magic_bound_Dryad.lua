--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Magic-bound Dryad - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 19th October 2016
--]]

-- Constants
local ENTRY_DRYAD    = 90056;
local SPELL_MOONFIRE =  8929;
local SPELL_REGROWTH =  9750;

local Dryad = {};

function Dryad.Moonfire(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_MOONFIRE);
end

function Dryad.Regrowth(event, delay, repeats, creature)
  if creature:GetHealthPct() <= 65 then
    creature:CastSpell(creature, SPELL_REGROWTH);
    RemoveEventById(event);
  end
end

-- Main
function Dryad.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Dryad.Moonfire, 7000, 1);
  creature:RegisterEvent(Dryad.Regrowth, 2500, 0);
end

function Dryad.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Dryad.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_DRYAD, 1, Dryad.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_DRYAD, 2, Dryad.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_DRYAD, 4, Dryad.OnDied);        -- CREATURE_EVENT_ON_DIED
