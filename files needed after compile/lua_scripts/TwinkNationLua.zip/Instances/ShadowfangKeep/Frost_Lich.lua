--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Frost Lich - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_LICH         = 90053;
local SPELL_FROST_BREATH = 16099;

local Lich = {};

function Lich.FrostBreath(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_FROST_BREATH, true);
end

-- Main
function Lich.OnEnterCombat(event, creature)
  local randomCasts = math.random(1, 4);
  creature:RegisterEvent(Lich.FrostBreath, 9000, randomCasts);
end

function Lich.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Lich.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_LICH, 1, Lich.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_LICH, 2, Lich.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_LICH, 4, Lich.OnDied);        -- CREATURE_EVENT_ON_DIED
