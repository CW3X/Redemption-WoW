--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Flame Imp - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_FLAME_IMP     = 90055;
local SPELL_GOUT_OF_FLAME = 15538;

local Imp = {};

function Imp.Firebolt(event, delay, repeats, creature)
  if math.random(1, 100) >= 50 then
    creature:CastSpell(creature, SPELL_GOUT_OF_FLAME, true);
  end
end

-- Main
function Imp.OnEnterCombat(event, creature)
  creature:RegisterEvent(Imp.Firebolt, 5000, 0);
end

function Imp.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Imp.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_FLAME_IMP, 1, Imp.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_FLAME_IMP, 2, Imp.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_FLAME_IMP, 4, Imp.OnDied);        -- CREATURE_EVENT_ON_DIED
