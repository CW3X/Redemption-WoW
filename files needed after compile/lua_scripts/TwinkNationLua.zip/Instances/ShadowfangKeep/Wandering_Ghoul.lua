--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Wandering Ghoul - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 19th October 2016
--]]

-- Constants
local ENTRY_GHOUL  = 90050;
local SPELL_PLAGUE = 19278; -- Devouring plague

local Ghoul = {};

function Ghoul.Plague(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_PLAGUE);
end

-- Main
function Ghoul.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Ghoul.Plague, 3000, 1);
end

function Ghoul.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Ghoul.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_GHOUL, 1, Ghoul.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_GHOUL, 2, Ghoul.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_GHOUL, 4, Ghoul.OnDied);        -- CREATURE_EVENT_ON_DIED
