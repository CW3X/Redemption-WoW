--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Stable Guard - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 19th October 2016
--]]

-- Constants
local ENTRY_GUARD           = 90046;
local SPELL_SHADOW_SHOCK    = 17234;
local SPELL_SINISTER_STRIKE = 15667;

local Guard = {};

function Guard.Shock(event, delay, repeats, creature)
  if math.random(1, 100) >= 70 then
    local Victim = creature:GetVictim();
    creature:CastSpell(Victim, SPELL_SHADOW_SHOCK);
  end
end

function Guard.SinisterStrike(event, delay, repeats, creature)
  if creature:GetHealthPct() <= 50 then
    local Victim = creature:GetVictim();
    creature:CastSpell(Victim, SPELL_SINISTER_STRIKE);
  end
end

-- Main
function Guard.OnEnterCombat(event, creature)
  creature:RegisterEvent(Guard.Shock, 8000, 3);
  creature:RegisterEvent(Guard.SinisterStrike, 3000, 0);
end

function Guard.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Guard.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_GUARD, 1, Guard.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_GUARD, 2, Guard.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_GUARD, 4, Guard.OnDied);        -- CREATURE_EVENT_ON_DIED
