--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Runic Golem - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_KEEPER  = 90048;

local Keeper = {
  Strings = {
    -- Spell cast
    "What shall it be today?",
    "So many to choose from.",
    "This will tear you apart.",
    -- Death
    "A secret's a secret.",
    "I can't hold this secret any longer.",
    "My lips are sealed.",
    "Cross my heart and hope to die.",
  },
  Spells = {
    [1] = 17286, -- Crusader's hammer (paladin)
    [2] = 21553, -- Mortal strike     (warrior)
    [3] = 7641,  -- Shadow bolt       (warlock)
    [4] = 8402,  -- Fireball          (mage)
    [5] = 13553, -- Serpent sting     (hunter)
    [6] = 8929,  -- Moonfire          (druid)
    [7] = 15267, -- Holy fire         (priest)
    [8] = 8633,  -- Garrote           (rogue)
    [9] = 930,   -- Chain lightning   (shaman)
  };
};

function Keeper.RandomSpell(event, delay, repeats, creature)
  local randomSpell = math.random(1, 9);
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, Keeper.Spells[randomSpell], true);
  if math.random(1, 100) >= 96 then
    creature:SendUnitSay(Keeper.Strings[math.random(1, 3)], 0);
  end
end

-- Main
function Keeper.OnEnterCombat(event, creature)
  creature:RegisterEvent(Keeper.RandomSpell, 7500, 0);
end

function Keeper.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Keeper.OnDied(event, creature, killer)
  if math.random(1, 100) >= 75 then
    creature:SendUnitSay(Keeper.Strings[math.random(4, 7)], 0);
  end
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_KEEPER, 1, Keeper.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_KEEPER, 2, Keeper.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_KEEPER, 4, Keeper.OnDied);        -- CREATURE_EVENT_ON_DIED
