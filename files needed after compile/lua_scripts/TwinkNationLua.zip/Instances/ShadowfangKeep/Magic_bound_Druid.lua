--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Magic-bound Druid - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_DRUID = 90057;
local SPELL_RAKE  = 22639;
local SPELL_TOXIN = 11469;
local SPELL_BASH  = 8983;

local Druid = {
  Forms = {
    [1] = 7965, -- Seprent
    [2] = 9634, -- Bear
    [3] = 768, -- Cat
  };
};

function Druid.Toxin(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_TOXIN, true);
  end
end

function Druid.Bash(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_BASH, true);
  end
end

function Druid.Rake(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_RAKE, true);
  end
end

function Druid.Shapeshift(event, delay, repeats, creature)
  local randomForm = math.random(1, 3);
  if randomForm == 1 then
    creature:CastSpell(creature, Druid.Forms[1], true);
    creature:RegisterEvent(Druid.Toxin, 4000, 1);
  elseif randomForm == 2 then
    creature:CastSpell(creature, Druid.Forms[2], true);
    creature:RegisterEvent(Druid.Bash, 4000, 1);
  else
    creature:CastSpell(creature, Druid.Forms[3], true);
    creature:RegisterEvent(Druid.Rake, 4000, 1);
  end
end

-- Main
function Druid.OnEnterCombat(event, creature)
  creature:RegisterEvent(Druid.Shapeshift, 2000, 1);
end

function Druid.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Druid.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_DRUID, 1, Druid.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_DRUID, 2, Druid.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_DRUID, 4, Druid.OnDied);        -- CREATURE_EVENT_ON_DIED
