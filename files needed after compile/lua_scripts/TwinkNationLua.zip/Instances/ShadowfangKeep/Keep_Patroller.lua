--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Keep Patroller - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_PATROLLER  = 90043;
local SPELL_TORCH_TOSS = 6257;

local Patroller = {};

function Patroller.TorchToss(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  creature:CastSpell(Victim, SPELL_TORCH_TOSS, true);
end

-- Main
function Patroller.OnEnterCombat(event, creature)
  creature:RegisterEvent(Patroller.TorchToss, 8500, 0);
end

function Patroller.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Patroller.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_PATROLLER, 1, Patroller.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_PATROLLER, 2, Patroller.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_PATROLLER, 4, Patroller.OnDied);        -- CREATURE_EVENT_ON_DIED
