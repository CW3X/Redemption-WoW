--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Wognir the Gatekeeper - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 27th October 2016
--]]

-- Constants
local ENTRY_WOGNIR = 90078;
local ENTRY_DOOR   = 18971;
local SPELL_ENRAGE = 28468; -- 150 bonus damage

local Wognir = {};

local function UnlockDoor(creature)
  local Door = creature:GetNearestGameObject(533, ENTRY_DOOR, 0);
  if Door then
    Door:SetGoState(0);
  end
end

function Wognir.CheckHealth(event, delay, repeats, creature)
  if creature:GetHealthPct() <= 50 then
    creature:CastSpell(creature, SPELL_ENRAGE, true);
    RemoveEventById(event);
  end
end

-- Main
function Wognir.OnEnterCombat(event, creature)
  creature:RegisterEvent(Wognir.CheckHealth, 1500, 0);
end

function Wognir.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Wognir.OnDied(event, creature, killer)
  UnlockDoor(creature);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_WOGNIR, 1, Wognir.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_WOGNIR, 2, Wognir.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_WOGNIR, 4, Wognir.OnDied);        -- CREATURE_EVENT_ON_DIED
