--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Grand Crusader Tobias - First boss in SFK.
 * AUTHOR : sundays
 * UPDATED: 7th November 2016
--]]

local BossTimers = require("../BossTimerMgr");

-- Constants
local ENTRY_CRUSADER        = 90063;
local ENTRY_DOOR            = 18895;
local SPELL_CRUSADER_STRIKE = 14518; -- crusader strike applies stacks
local SPELL_HAMMER          = 13005; -- HoJ
local SPELL_HOLY_STRIKE     = 13953; -- holy strike
local SPELL_HOLY_LIGHT      = 25292;
local SPELL_CONSECRATION    = 20924; -- 48/s 8 sec

local Crusader = {
  Strings = {
    -- On combat
    "Light grant me strenght!",
    -- Heal
    "I won't falter!",
    "The light favours an opportunist!",
    "The light heals even the goriest of wounds.",
    -- Death
    "'Tis but a flesh wound!",
    "A mere scratch, I say!",
    "Argh, a hit, I do confess... a very palpable... hit.",
  };
};

local function OpenDoor(creature)
  local Door = creature:GetNearestGameObject(533, ENTRY_DOOR, 0);
  if Door then
    Door:SetGoState(0);
  end
end

function Crusader.HolyLight(event, delay, repeats, creature)
  local randomSay = math.random(2, 4);
  creature:SendUnitSay(Crusader.Strings[randomSay], 0);
  creature:CastSpell(creature, SPELL_HOLY_LIGHT, false);
end

function Crusader.CrusaderStrike(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_CRUSADER_STRIKE, true);
  end
end

function Crusader.StunHeal(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_HAMMER);
    creature:RegisterEvent(Crusader.HolyLight, 1000, 1);
  end
end

function Crusader.HolyStrike(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    if Victim:GetHealthPct() >= 50 then
      creature:CastSpell(Victim, SPELL_HOLY_STRIKE);
    end
  end
end

function Crusader.Consecration(event, delay, repeats, creature)
  if creature:GetHealthPct() <= 75 then
    creature:CastSpell(creature, SPELL_CONSECRATION);
  end
end

-- Main
function Crusader.OnEnterCombat(event, creature, target)
  local InstanceId = creature:GetInstanceId();
  creature:RegisterEvent(Crusader.CrusaderStrike, 5000, 0);
  creature:RegisterEvent(Crusader.StunHeal, 30000, 0);
  creature:RegisterEvent(Crusader.HolyStrike, 9000, 0);
  creature:RegisterEvent(Crusader.Consecration, 15000, 0);
  BossTimers.BossStarted(InstanceId, creature:GetName(), target:GetGroup(), os.time(), creature:GetGUIDLow());
end

function Crusader.OnLeaveCombat(event, creature)
  local InstanceId = creature:GetInstanceId();
  BossTimers.DeleteTimer(InstanceId, creature:GetGUIDLow());
  creature:RemoveEvents();
end

function Crusader.OnDied(event, creature, killer)
  local InstanceId  = creature:GetInstanceId();
  local randomSay = math.random(5, 7);
  BossTimers.BossEnded(InstanceId, creature:GetMapId(), creature:GetName(), killer:GetGroup(), os.time(), creature:GetGUIDLow());
  OpenDoor(creature);
  creature:SendUnitSay(Crusader.Strings[randomSay], 0);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_CRUSADER, 1, Crusader.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_CRUSADER, 2, Crusader.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_CRUSADER, 4, Crusader.OnDied);        -- CREATURE_EVENT_ON_DIED
