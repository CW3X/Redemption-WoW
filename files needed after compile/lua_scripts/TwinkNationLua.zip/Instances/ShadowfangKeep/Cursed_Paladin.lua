--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Cursed Paladin - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 29th October 2016
--]]

-- Constants
local ENTRY_PALADIN = 90059;
local SPELL_SLAM    = 11604;
local SPELL_SHIELD  = 15655; -- Shield bash

local Paladin = {};

function Paladin.Slam(event, delay, repeats, creature)
  if math.random(1, 100) >= 60 then
    local Victim = creature:GetVictim();
    if Victim then
      creature:CastSpell(Victim, SPELL_SLAM, false);
    end
  end
end

function Paladin.Bash(event, delay, repeats, creature)
  if math.random(1, 100) >= 50 then
    local Victim = creature:GetVictim();
    if Victim then
      creature:CastSpell(Victim, SPELL_SHIELD, false);
      RemoveEventById(event);
    end
  end
end

-- Main
function Paladin.OnEnterCombat(event, creature)
  creature:RegisterEvent(Paladin.Slam, 8000, 0);
  creature:RegisterEvent(Paladin.Bash, 4000, 1);
end

function Paladin.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Paladin.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_PALADIN, 1, Paladin.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_PALADIN, 2, Paladin.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_PALADIN, 4, Paladin.OnDied);        -- CREATURE_EVENT_ON_DIED
