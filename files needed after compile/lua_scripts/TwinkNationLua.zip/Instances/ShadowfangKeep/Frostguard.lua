--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Frostguard - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_FROSTGUARD = 90052;
local SPELL_ICE_ARMOR  = 10220;
local SPELL_ICICLE     = 11131;

local Frostguard = {};

function Frostguard.Icicle(event, delay, repeats, creature)
  if math.random(1, 100) >= 50 then
    local Victim = creature:GetVictim();
    creature:CastSpell(Victim, SPELL_ICICLE, true);
  end
end

-- Main
function Frostguard.OnEnterCombat(event, creature)
  creature:CastSpell(creature, SPELL_ICE_ARMOR, true);
  creature:RegisterEvent(Frostguard.Icicle, 8000, 2);
end

function Frostguard.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Frostguard.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_FROSTGUARD, 1, Frostguard.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_FROSTGUARD, 2, Frostguard.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_FROSTGUARD, 4, Frostguard.OnDied);        -- CREATURE_EVENT_ON_DIED
