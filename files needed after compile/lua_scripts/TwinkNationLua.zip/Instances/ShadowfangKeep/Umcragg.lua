 --[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Umcragg - SFK boss.
 * AUTHOR : sundays
 * UPDATED: 7th November 2016
--]]

local BossTimers = require("../BossTimerMgr");

-- Constants
local ENTRY_UMCRAGG        = 90075;
local ENTRY_FORCEFIELD     = 180497;
local SPELL_SHADOW_BOLT    = 17483; -- instant, has dot. bp0: damage bp1: periodic damage
-- local SPELL_PLAGUE         = 19279; -- Devouring plague 712dmg bp0: leech value
local SPELL_VEIL_OF_SHADOW =  7068; -- 75% reduced healing
local SPELL_SHADOW_VULN    = 15258; -- Shadow vulnerability 3%
local SPELL_SHADOW_VOLLEY  = 20741; -- Shadow bolt volley

local Umcragg = {
  Strings = {
    -- Enter Combat
    "Umcragg begins casting a powerful spell on those who are not moving.",
     -- Shadow vulnerability
    "Umcragg stirs the shadows, stop moving!",
    "Umcragg weaves the shadows, stop moving!",
    "Umcragg conjures shadow magic, stop moving!",
    "Umcragg stirs a thick mist of shadow, stop moving!",
  };
};

local function OpenForcefield(creature)
  local Forcefield = creature:GetNearestGameObject(533, ENTRY_FORCEFIELD, 0);
  if Forcefield then
    Forcefield:SetGoState(0);
  end
end

--[[
local function IsPlayerFacingAway(player, creature)
  local OrientationCreature = creature:GetO();
  local OrientationTarget   = player:GetO() + math.pi;
  local Angles   = {};
  Angles[1] = OrientationCreature - (math.pi / 2); -- MIN: angle - 90deg
  Angles[2] = OrientationCreature + (math.pi / 2); -- MAX: angle + 90deg
  if OrientationTarget > (math.pi * 2) then
    OrientationTarget = OrientationTarget - (math.pi * 2);
  end
  if Angles[1] < 0 then
    Angles[1] = (math.pi * 2) + Angles[1];
  end
  if Angles[2] > (math.pi * 2) then
    Angles[2] = Angles[2] - (math.pi * 2);
  end
  table.sort(Angles);
  if OrientationTarget >= Angles[1] and OrientationTarget <= Angles[2] then
    return true;
  else
    return false;
  end
end
--]]

function Umcragg.Vulnerability(event, delay, repeats, creature)
  local Targets = creature:GetAITargets();
  local next    = next;
  if next(Targets) then
    for _, v in pairs(Targets) do
      if not v:IsMoving() then
        if v:HasAura(SPELL_SHADOW_VULN) then
          local ShadowAura = v:GetAura(SPELL_SHADOW_VULN);
          local StackAmnt  = ShadowAura:GetStackAmount();
          if StackAmnt < 100 then
            ShadowAura:SetStackAmount(StackAmnt + 1);
            ShadowAura:SetDuration(9000);
          else
            ShadowAura:SetStackAmount(100);
            ShadowAura:SetDuration(9000);
          end
        else
          creature:AddAura(SPELL_SHADOW_VULN, v);
          local ShadowAura = v:GetAura(SPELL_SHADOW_VULN);
          ShadowAura:SetDuration(9000);
        end
      end
    end
  end
end

function Umcragg.Veil(event, delay, repeats, creature)
  local Targets = creature:GetAITargets();
  local next    = next;
  if next(Targets) then
    for _, v in pairs(Targets) do
      if v:IsMoving() then
        creature:CastSpell(v, SPELL_VEIL_OF_SHADOW, true);
      end
    end
  end
  RemoveEventById(event);
end

function Umcragg.AnnounceVeil(event, delay, repeats, creature)
  local RandomText = math.random(2, 5);
  creature:SendUnitEmote(Umcragg.Strings[RandomText], nil, true);
  creature:RegisterEvent(Umcragg.Veil, 1000, 1);
end

function Umcragg.Volley(event, delay, repeats, creature)
  if creature:IsInCombat() then
    creature:CastSpell(creature, SPELL_SHADOW_VOLLEY, true);
  end
end

function Umcragg.Shadowbolt(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0); -- Random
  if Target then
    creature:CastSpell(Target, SPELL_SHADOW_BOLT, true);
  end
end

-- Main
function Umcragg.OnEnterCombat(event, creature, target)
  local InstanceId = creature:GetInstanceId();
  creature:SendUnitEmote(Umcragg.Strings[1], nil, true);
  creature:RegisterEvent(Umcragg.Shadowbolt, 13000, 0);    -- Random target shadowbolt (dot)
  creature:RegisterEvent(Umcragg.Volley, 10000, 0);
  creature:RegisterEvent(Umcragg.Vulnerability, 2000, 0);
  creature:RegisterEvent(Umcragg.AnnounceVeil, 20000, 0);
  BossTimers.BossStarted(InstanceId, creature:GetName(), target:GetGroup(), os.time(), creature:GetGUIDLow());
end

function Umcragg.OnLeaveCombat(event, creature)
  local InstanceId = creature:GetInstanceId();
  BossTimers.DeleteTimer(InstanceId, creature:GetGUIDLow());
  creature:RemoveEvents();
end

function Umcragg.OnDied(event, creature, killer)
  local InstanceId = creature:GetInstanceId();
  BossTimers.BossEnded(InstanceId, creature:GetMapId(), creature:GetName(), killer:GetGroup(), os.time(), creature:GetGUIDLow());
  OpenForcefield(creature);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_UMCRAGG, 1, Umcragg.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_UMCRAGG, 2, Umcragg.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_UMCRAGG, 4, Umcragg.OnDied);        -- CREATURE_EVENT_ON_DIED
