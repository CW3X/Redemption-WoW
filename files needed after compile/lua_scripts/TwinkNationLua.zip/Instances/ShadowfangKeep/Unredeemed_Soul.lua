 --[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Unredeemed Soul - SFK - Summons the last boss when required item is handed in.
 * AUTHOR : sundays
 * UPDATED: 26th October 2016
--]]

-- Constants
local ENTRY_SOUL  = 90077;
local ENTRY_BOSS  = 90061;
local ENTRY_DUST  = 74303;
local TEXTID_SOUL = 60001;
local SPELL_SHAKE = 12816; -- Shakes the camera

local Soul = {
  Strings = {
    -- hand in item
    "Strange. I feel a certain... power...",
    "Oh no... that's not right.",
    "Oh no, you've gone and made a mess.",
    "Where did you get that? What have you done?!",
    "No! Get that thing away from here!",
    "Get that thing away from here! What've you done?",
  };
};

function Soul.SummonBoss(event, delay, repeats, creature)
  local InstanceId = creature:GetInstanceId();
  local x, y, z, o = -101.48, 2127.19, 144.922, 1.21;
  local Boss = PerformIngameSpawn(1, ENTRY_BOSS, 33, InstanceId, x, y, z, o, false);
  Boss:SetRespawnDelay(604800); -- 7 days
  RemoveEventById(event);
end

function Soul.OnHello(event, player, object)
  player:GossipClearMenu();
  if player:HasItem(ENTRY_DUST, 1, false) then
    player:RemoveItem(ENTRY_DUST, 1);
    player:GossipMenuAddItem(0, "I found this strange dust while crawling through the Keep. Perhaps you've seen something similar in your time on earth, spirit?", 2, 1);
  end
  player:GossipSendMenu(TEXTID_SOUL, object);
end

function Soul.OnSelect(event, player, object, sender, intid, code, menu_id)
  local id = object:GetInstanceId();
  if intid == 1 then
    player:GossipComplete();
    local RandomText = math.random(1, 6);
    object:SendUnitSay(Soul.Strings[RandomText], 0);
    object:CastSpell(object, SPELL_SHAKE, true);
    object:RegisterEvent(Soul.SummonBoss, 1500, 1);
    object:DespawnOrUnsummon(2500);
  end
end

RegisterCreatureGossipEvent(ENTRY_SOUL, 1, Soul.OnHello);  -- GOSSIP_EVENT_ON_HELLO
RegisterCreatureGossipEvent(ENTRY_SOUL, 2, Soul.OnSelect); -- GOSSIP_EVENT_ON_SELECT
