--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Shadowfang Captain - SFK trash.
 * AUTHOR : sundays
 * UPDATED: 15th October 2016
--]]

-- Constants
local ENTRY_CAPTAIN = 90042;
local SPELL_SHOUT   = 6190; -- -55 atk power
local SPELL_SLAP    = 6754;

local Captain = {
  Strings = {
    "Rally the troops!",
    "Stand ready, soldiers!",
    "The quick and the dead both bear arms against you.",
    "Ready your weapons, soldiers!",
    "Charge!",
  };
};

function Captain.Shout(event, delay, repeats, creature)
  if math.random(1, 100) >= 60 then
    creature:CastSpell(creature, SPELL_SHOUT);
  end
end

function Captain.Slap(event, delay, repeats, creature)
  if creature:GetHealthPct() <= 45 then
    local Victim = creature:GetVictim();
    creature:CastSpell(Victim, SPELL_SLAP);
    RemoveEventById(event);
  end
end

-- Main
function Captain.OnEnterCombat(event, creature)
  creature:RegisterEvent(Captain.Shout, 5000, 1);
  creature:RegisterEvent(Captain.Slap, 5000, 0);
  if math.random(1, 100) >= 75 then
    creature:SendUnitSay(Captain.Strings[math.random(1, 5)], 0);
  end
end

function Captain.OnLeaveCombat(event, creature, target)
  creature:RemoveEvents();
end

function Captain.OnDied(event, creature, killer)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_CAPTAIN, 1, Captain.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_CAPTAIN, 2, Captain.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_CAPTAIN, 4, Captain.OnDied);        -- CREATURE_EVENT_ON_DIED
