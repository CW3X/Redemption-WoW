--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Ohm -- Last boss in SFK
 * AUTHOR : sundays
 * UPDATED: 7th November 2016
--]]

local BossTimers = require("../BossTimerMgr");

-- Constants
local ENTRY_OHM              = 90061;
local ENTRY_PORTAL           = 90074;
local ENTRY_UNCHAINED        = 90062;
local POWER_MANA             =     0;
local SPELL_ARCANE_BURST     =   568; -- bp0: damage, bp1: knockback, bp2: slow
local SPELL_ARCANE_BLAST     = 16067;
local SPELL_ARCANE_BOLT      = 15451;
local SPELL_ARCANE_EXPLOSION =  8439;

local Ohm = {
  ManaBarrier = {},
  MaxHealth,
  MaxPower,
  Strings = {
    -- Mana reaches 0.
    "Ohm's mana barrier fades away.",
    -- Mana gain
    "Ohm's mana barrier grows in strength.",
    -- Raid wiped
    "We'll see each other... soon...",
    "Entropy rises, life escapes your grasp... you fade.",
    "Next time...",
  };
};

local function ResetMana(creature)
  local InstanceId = creature:GetInstanceId();
  creature:SetPower(POWER_MANA, creature:GetMaxPower());
  Ohm.ManaBarrier[InstanceId] = true;
end

-- Despawn existing portals and adds.
local function CleanUp(creature)
  local Portals = creature:GetCreaturesInRange(533, ENTRY_PORTAL, 0, 0);
  local Adds    = creature:GetCreaturesInRange(533, ENTRY_UNCHAINED, 0, 0);
  for _, v in pairs(Portals) do
    v:DespawnOrUnsummon(0);
  end
  for _, v in pairs(Adds) do
    v:DespawnOrUnsummon(0);
  end
end

function Ohm.SpawnPortal(event, delay, repeats, creature)
  local Target = creature:GetAITarget(0, true, 0, 50);
  if Target then
    local InstanceId    = creature:GetInstanceId();
    local x, y, z, o    = Target:GetLocation();
    local SpawnedPortal = PerformIngameSpawn(1, ENTRY_PORTAL, 33, InstanceId, x, y, z, o, false);
    SpawnedPortal:SetRespawnDelay(696969);
    SpawnedPortal:Attack(Target);
  end
end

function Ohm.ArcaneBolt(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_ARCANE_BOLT, false);
  end
end

-- Main
function Ohm.OnEnterCombat(event, creature, target)
  local InstanceId = creature:GetInstanceId();
  Ohm.MaxHealth = creature:GetMaxHealth();
  Ohm.ManaBarrier[InstanceId] = true;
  creature:RegisterEvent(Ohm.SpawnPortal, 20000, 0);
  creature:RegisterEvent(Ohm.ArcaneBolt, 13000, 0);
  BossTimers.BossStarted(InstanceId, creature:GetName(), target:GetGroup(), os.time(), creature:GetGUIDLow());
end

function Ohm.OnDamageTaken(event, creature, attacker, damage)
  local ManaAmount = creature:GetPower(POWER_MANA);
  if ManaAmount > 0 and Ohm.ManaBarrier[InstanceId] then
    local InstanceId = creature:GetInstanceId();
    if damage >= ManaAmount and Ohm.ManaBarrier[InstanceId] then
      -- Shield Depleted
      ManaAmount = 0;
      creature:SendUnitEmote(Ohm.Strings[1], nil, true);
      Ohm.ManaBarrier[InstanceId] = false;
      return;
    else
      -- Take damage away from current mana.
      creature:SetPower(POWER_MANA, ManaAmount - damage);
      creature:SetHealth(Ohm.MaxHealth);
    end
  end
end

function Ohm.OnLeaveCombat(event, creature)
  local InstanceId = creature:GetInstanceId();
  local RandomText = math.random(3, 5);
  BossTimers.DeleteTimer(InstanceId, creature:GetGUIDLow());
  creature:SendUnitYell(Ohm.Strings[RandomText], 0);
  ResetMana(creature);
  CleanUp(creature);
  creature:DespawnOrUnsummon(0); -- Better luck next time :)
  creature:RemoveEvents();
end

function Ohm.OnDied(event, creature, killer)
  local InstanceId = creature:GetInstanceId();
  BossTimers.BossEnded(InstanceId, creature:GetMapId(), creature:GetName(), killer:GetGroup(), os.time(), creature:GetGUIDLow());
  CleanUp(creature);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_OHM, 1, Ohm.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_OHM, 2, Ohm.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_OHM, 4, Ohm.OnDied);        -- CREATURE_EVENT_ON_DIED
RegisterCreatureEvent(ENTRY_OHM, 9, Ohm.OnDamageTaken); -- CREATURE_EVENT_ON_DAMAGE_TAKEN

-- Portals
local Portal = {};

function Portal.SpawnCreature(event, delay, repeats, creature)
  local x, y, z, o = creature:GetLocation();
  local InstanceId = creature:GetInstanceId();
  local next       = next;
  local TargetsInRange  = creature:GetPlayersInRange(50, 1, 1);
  if next(TargetsInRange) then
    local SpawnedCreature = PerformIngameSpawn(1, ENTRY_UNCHAINED, 33, InstanceId, x, y, z, o, false);
    SpawnedCreature:SetRespawnDelay(696969);
    SpawnedCreature:AttackStart(TargetsInRange[math.random(1, #TargetsInRange)]); -- Random target
  end
end

-- Main
function Portal.OnEnterCombat(event, creature, target)
  creature:RegisterEvent(Portal.SpawnCreature, 9000, 0);
end

function Portal.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Portal.OnDied(event, creature, killer)
  local RandomDamage = math.random(150, 250);
  local RandomKnockback = math.random(150, 200);
  local RandomSlow = math.random(60, 80);
  creature:CastCustomSpell(creature, SPELL_ARCANE_BURST, true, RandomDamage, RandomKnockback, RandomSlow, nil, 0);
  creature:DespawnOrUnsummon(0);
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_PORTAL, 1, Portal.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_PORTAL, 2, Portal.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_PORTAL, 4, Portal.OnDied);        -- CREATURE_EVENT_ON_DIED

-- Unchained Being
local Unchained = {};

function Unchained.Blast(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_ARCANE_BLAST, false);
  end
end

function Unchained.Bolt(event, delay, repeats, creature)
  local Victim = creature:GetVictim();
  if Victim then
    creature:CastSpell(Victim, SPELL_ARCANE_BOLT, false);
  end
end

function Unchained.Explosion(event, delay, repeats, creature)
  creature:CastSpell(creature, SPELL_ARCANE_EXPLOSION);
end

-- Main
function Unchained.OnEnterCombat(event, creature, target)
  local RandomSpell = math.random(1, 3);
  if RandomSpell == 1 then
    creature:RegisterEvent(Unchained.Blast, 3000, 0);
  elseif RandomSpell == 2 then
    creature:RegisterEvent(Unchained.Bolt, 3000, 0);
  else
    creature:RegisterEvent(Unchained.Explosion, 3000, 0);
  end
end

function Unchained.OnLeaveCombat(event, creature)
  creature:RemoveEvents();
end

function Unchained.OnDied(event, creature, killer)
  creature:RemoveEvents();
end


RegisterCreatureEvent(ENTRY_UNCHAINED, 1, Unchained.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_UNCHAINED, 2, Unchained.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_UNCHAINED, 4, Unchained.OnDied);        -- CREATURE_EVENT_ON_DIED
