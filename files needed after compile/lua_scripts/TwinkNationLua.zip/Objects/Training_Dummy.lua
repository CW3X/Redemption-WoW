--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Training Dummy
 * AUTHOR : sundays
 * UPDATED: 25th November 2016
 * NOTE   : Has errors due to nil index lookups. Needs metatables to fix it.
--]]

-- Constants
local ENTRY_DUMMY = 90093;

local Dummy = {};

function Dummy.CheckTargets(event, delay, repeats, creature)
  local uid = creature:GetGUIDLow() .. creature:GetInstanceId();

  for i, _ in pairs(Dummy[uid]) do
    creature:SendUnitSay("DEBUG: Checking " .. i, 0);
    local player = GetPlayerByGUID(i);
    if player then
      if not creature:IsWithinLoS(player) or creature:GetDistance(player) > 35 then
        creature:SendUnitSay("DEBUG: Removing " .. i, 0);
        Dummy[uid][i] = nil;
        player:ClearInCombat();
        creature:ClearThreatList();
      end
    end
  end
end

-- Main
function Dummy.OnEnterCombat(event, creature, target)
  local uid = creature:GetGUIDLow() .. creature:GetInstanceId(); -- GUIDLow isn't unique on CMaNGOS.
  local targetId = target:GetGUIDLow();

  Dummy[uid] = Dummy[uid] or {};
  Dummy[uid][targetId] = true;
  creature:SendUnitSay(string.format("DEBUG: Adding %d to uid: %d.", targetId, uid), 0);
  creature:RegisterEvent(Dummy.CheckTargets, 3000, 0);
end

function Dummy.OnLeaveCombat(event, creature)
  local uid = creature:GetGUIDLow() .. creature:GetInstanceId();
  Dummy[uid] = nil;
  creature:SendUnitSay("DEBUG: Reset.", 0);
  creature:RemoveEvents();
end

function Dummy.OnDamaged(event, creature, attacker, damage)
  local uid = creature:GetGUIDLow() .. creature:GetInstanceId();
  local targetId = attacker:GetGUIDLow();
  
  if (Dummy[uid][targetId]) then
    creature:SendUnitSay("DEBUG: Old target.", 0);
  else
    Dummy[uid][targetId] = true;
    creature:SendUnitSay("DEBUG: New index " .. attacker:GetGUIDLow(), 0);
  end
  
  creature:SetHealth(449 * 2);
end

RegisterCreatureEvent(ENTRY_DUMMY, 1, Dummy.OnEnterCombat); -- CREATURE_EVENT_ON_ENTER_COMBAT
RegisterCreatureEvent(ENTRY_DUMMY, 2, Dummy.OnLeaveCombat); -- CREATURE_EVENT_ON_LEAVE_COMBAT
RegisterCreatureEvent(ENTRY_DUMMY, 9, Dummy.OnDamaged); -- CREATURE_EVENT_ON_DAMAGE_TAKEN
