--[[
 * TwinkNation 2016 http://twinknation.org/
 * DESC   : Script for the Explosive Sheep engineering item.
 * AUTHOR : sundays
 * UPDATED: 31st October 2016
--]]

-- Constants
local ENTRY_SHEEP   = 2675;
local SPELL_EXPLODE = 4050;

local Sheep = {};

function Sheep.CheckDistance(event, delay, repeats, creature)
  local NearestTarget = creature:GetNearestPlayer(50, 1, 1); -- 50yd, hostile, alive
  if NearestTarget then
    if creature:GetDistance(NearestTarget) <= 5 then
      creature:CastSpell(creature, SPELL_EXPLODE, true);
      RemoveEventById(event);
    end
  end
end

function Sheep.CheckTarget(event, delay, repeats, creature)
  local NearestTarget = creature:GetNearestPlayer(50, 1, 1); -- 50yd, hostile, alive
  if NearestTarget then
    creature:MoveFollow(NearestTarget);
    creature:RegisterEvent(Sheep.CheckDistance, 1000, 0);
    RemoveEventById(event);
  end
end

function Sheep.OnReset(event, creature)
  local NearestTarget = creature:GetNearestPlayer(50, 1, 1); -- 50yd, hostile, alive
  if NearestTarget then
    creature:MoveFollow(NearestTarget);
    creature:RegisterEvent(Sheep.CheckDistance, 1000, 0);
  else
    creature:RegisterEvent(Sheep.CheckTarget, 1000, 0);
  end
end

function Sheep.OnDied(event, creature)
  creature:RemoveEvents();
end

RegisterCreatureEvent(ENTRY_SHEEP, 23, Sheep.OnReset); -- CREATURE_EVENT_ON_RESET
RegisterCreatureEvent(ENTRY_SHEEP, 4, Sheep.OnDied);   -- CREATURE_EVENT_ON_DIED
