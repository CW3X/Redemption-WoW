--[[
  * http://twinknation.org/
  * DESC   : Disallow concurrent connections from the same IP address.
  * AUTHOR : Sundays
  * UPDATED: 15th October 2016
--]]

local function OnPlayerLogin(event, player)
  local next = next;
  local worldPlayers  = GetPlayersInWorld();
  local PlayerIp      = player:GetPlayerIP();
  local PlayerGUIDLow = player:GetGUIDLow();
  if next(worldPlayers) and not player:IsGM() then
	local count = 0;
    for _, v in pairs(worldPlayers) do
      if v:GetPlayerIP() == PlayerIp and v:GetGUIDLow() ~= PlayerGUIDLow and not v:IsGM() then
        count = count + 1;
        if count >= 2 then
          PrintError("Kicking for matching ip: ", v:GetName());
          Kick(v);
          return;
        end
      end
    end
  end
end

RegisterPlayerEvent(3, OnPlayerLogin); -- PLAYER_EVENT_ON_LOGIN
